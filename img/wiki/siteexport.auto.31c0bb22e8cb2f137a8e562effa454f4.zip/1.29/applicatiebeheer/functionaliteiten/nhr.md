# NHR

Op deze pagina bevinden zich de doorverwijzingen naar de pagina’s met informatie over de NHR/KvK functionaliteiten in OpenWave.

  * [Sectie KoppelingNHR](/openwave/1.29/applicatiebeheer/instellen_inrichten/configuratie/sectie_koppelingnhr). Benodigde **Instellingen in de Configuratie**.
  * [NHR bevraging](/openwave/1.29/applicatiebeheer/probleemoplossing/programmablokken/nhr_bevraging). Toelichting op de benodigde instellingen en hoe de koppeling ingericht kan worden, waaronder het gemeente beheer, de StUF bevraging en de logging van de berichten.

