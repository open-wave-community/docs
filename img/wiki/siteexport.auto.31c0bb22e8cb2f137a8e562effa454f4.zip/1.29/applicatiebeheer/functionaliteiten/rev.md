# REV

Op deze pagina bevinden zich de doorverwijzingen naar de pagina’s met informatie over de Register Externe Veiligheid functionaliteiten in OpenWave.

  * [Sectie REV](/openwave/1.29/applicatiebeheer/instellen_inrichten/configuratie/sectie_rev). Benodigde **Instellingen in de Configuratie**.
  * [Register Externe Veiligheid](/openwave/1.29/applicatiebeheer/instellen_inrichten/register_exrterne_veiligheid). Op deze pagina wordt toegelicht **hoe de REV functioneert binnen OpenWave**, wat verhoudingen zijn tussen de verschillende tabellen en hoe geëxporteerd kan worden naar het register.
  * [REV-synchroniseren](/openwave/1.29/applicatiebeheer/probleemoplossing/programmablokken/rev_synchroniseren). Op deze pagina wordt stapsgewijs uitgelegd hoe **synchronisatie met de REV** tot stand kan komen.
  * [Opslagtabel bij inrichtingen](/openwave/1.29/applicatiebeheer/instellen_inrichten/opslag_bij_inrichtingen). Deze pagina licht toe welke **opslagmogelijkheden** er zijn voor de inrichtingen.

