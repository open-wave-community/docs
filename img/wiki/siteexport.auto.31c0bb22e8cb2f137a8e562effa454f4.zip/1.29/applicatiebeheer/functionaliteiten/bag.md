# BAG

Op deze pagina bevinden zich doorverwijzingen naar de pagina's met informatie over de BAG-functionaliteiten.

  * [BAG bevraging via StUF BG vraagbericht](/openwave/1.29/applicatiebeheer/probleemoplossing/programmablokken/bag_bevraging). De instellingen voor de BAG koppelingen en de Configuratie items staan hier samengevat: [Sectie KoppelingBAG](/openwave/1.29/applicatiebeheer/instellen_inrichten/configuratie/sectie_koppelingbag)
  * [Email naar BAG beheerder](/openwave/1.29/applicatiebeheer/probleemoplossing/programmablokken/email_bag-beheerder). De vereiste instellingen voor deze optie vanuit een activiteit zijn hier te vinden plus de Configuratie items: [Sectie EmailNaarBagBeheerder](/openwave/1.29/applicatiebeheer/instellen_inrichten/configuratie/sectie_emailnaarbagbeheerder)
  * [Inlezen BAG Extract en/of BAG-mutaties](/openwave/1.29/applicatiebeheer/probleemoplossing/programmablokken/inlezen_bag-extract_en_bag-mutaties). Uitleg over het inlezen van BAG gegevens en van periodieke BAG mutaties
  * [Automatisch inlezen BAG- mutaties](/openwave/1.29/applicatiebeheer/probleemoplossing/programmablokken/automatisch_inlezen_bag_-mutaties). Gescheduled inlezen van BAG-mutaties per gemeente.

