# Bezwaar en beroep

Tabel van [bezwaar/beroep](/openwave/1.29/applicatiebeheer/probleemoplossing/module_overstijgende_schermen/bezwaar_beroep) registraties per zaak

  * [Detailscherm Bezwaar/beroep](/openwave/1.29/applicatiebeheer/probleemoplossing/module_overstijgende_schermen/bezwaar_beroep/detailpagina_bezwaar_beroep)
  * [Lijst bezwaar/beroep bij een zaak](/openwave/1.29/applicatiebeheer/probleemoplossing/module_overstijgende_schermen/bezwaar_beroep/lijst_bezwaar_beroep_bij_zaak)

