# Inspecties

Hier wordt dieper ingegaan op het detailscherm van een inspectie plus de bijbehorende bezoeken en issues.
Ook wordt het lijstscherm van inspectietrajecten bij een zaak/inrichting behandeld.

Onderwerpen [Inspecties](/openwave/1.29/applicatiebeheer/probleemoplossing/module_overstijgende_schermen/inspecties):

  * [Detailscherm Inspectie overtreding](/openwave/1.29/applicatiebeheer/probleemoplossing/module_overstijgende_schermen/inspecties/detailscherm_inspectie-issues)
  * [Detailscherm Inspectie bezoek](/openwave/1.29/applicatiebeheer/probleemoplossing/module_overstijgende_schermen/inspecties/detailscherm_inspectiebezoeken)
  * [Detailscherm Inspectietrajecten](/openwave/1.29/applicatiebeheer/probleemoplossing/module_overstijgende_schermen/inspecties/detailscherm_inspectietrajecten)
  * [Lijst Inspectie-overtredingen](/openwave/1.29/applicatiebeheer/probleemoplossing/module_overstijgende_schermen/inspecties/lijst_inspectie-issues)
  * [Lijst Inspectiebezoeken](/openwave/1.29/applicatiebeheer/probleemoplossing/module_overstijgende_schermen/inspecties/lijst_inspectiebezoeken)
  * [Lijst Inspecties bij een Zaak](/openwave/1.29/applicatiebeheer/probleemoplossing/module_overstijgende_schermen/inspecties/lijst_inspectietrajecten_bij_een_zaak)

