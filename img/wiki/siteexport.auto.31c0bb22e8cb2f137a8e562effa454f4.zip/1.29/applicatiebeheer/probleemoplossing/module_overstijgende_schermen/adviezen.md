# Adviezen

Hier worden de werking van het [lijst- en detailscherm van adviezen](/openwave/1.29/applicatiebeheer/probleemoplossing/module_overstijgende_schermen/adviezen) bij een zaak behandeld:

  * [Detailscherm Adviezen](/openwave/1.29/applicatiebeheer/probleemoplossing/module_overstijgende_schermen/adviezen/detailscherm_adviezen)
  * [Lijst Adviezen bij een zaak](/openwave/1.29/applicatiebeheer/probleemoplossing/module_overstijgende_schermen/adviezen/lijst_adviezen_bij_een_zaak)

