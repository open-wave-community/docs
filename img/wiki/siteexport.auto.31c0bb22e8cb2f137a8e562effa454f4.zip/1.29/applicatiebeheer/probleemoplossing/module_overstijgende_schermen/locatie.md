# Locatie detailscherm

Screenidentifier: MDDC_geefLokatieAdres.xml.

Detailpagina van Locatie op basis van vwfrmlokaties.

Kan worden aangeroepen vanuit de tegel *Locaties* op het openingsportaal en met de knoppen *Locatie* op de zaakportalen, het archiefportaal en het inrichtingsportaal en bijbehorende detailschermen.

### Error

Het scherm geeft een foutmelding indien:

  * er is mogelijk een zelf gedefinieerde schermindeling gebruikt (zie [Scherm(kolom)definitie](/openwave/1.29/applicatiebeheer/instellen_inrichten/schermdefinitie)) die niet valide is
  * de inlogger behoort tot een rechtengroep die geen kijkrechten heeft op locaties (locatieadressen zichtbaar bij hoofdrechtengroep). 

### Muteren

De kolommen van de view afkomstig van de tabel tbperceeladressen kunnen gemuteerd worden indien:

  * de inlogger behoort tot een rechtengroep die wijzigrechten heeft op locaties (locatieadressen zichtbaar bij hoofdrechtengroep)
  * EN de editschuif aan staat
  * EN - indien de inlogger lid is van een [compartiment](/openwave/1.29/applicatiebeheer/instellen_inrichten/compartimenten) - dan moet de betreffende gemeente in dat compartiment vallen. Let op: een gemeente kan in meerdere compartimenten voorkomen.

Uitzondering is de kolom **Verificatiedatum BAG** die automatisch gevuld/leeggemaakt wordt door de trigger *synchroniseer met BAG* of vanuit de operations (portaal Operations) Import BAG-extract en Import BAG-mutaties.

De kolommen *straat, woonplaats en gemeente* zijn afkomstig van andere tabellen en kunnen hier niet worden gemuteerd.

### Triggers knoppen linksonder

  * Toon kaart: 
    * is altijd zichtbaar
    * is disabled indien de puntcoördinaten op het locatiescherm leeg zijn.
  * Synchroniseer met BAG (zie [BAG bevraging](/openwave/1.29/applicatiebeheer/probleemoplossing/programmablokken/bag_bevraging)):
    * is zichtbaar en enabled indien: 
      * de instelling *Sectie: KoppelingBAG* en *Item: Methode* en *Tekst = StUF-310* bestaat en is aangevinkt 
      * EN de inlogger behoort tot een rechtengroep die BAG-rechten heeft op locaties (locatieadressen BAG bij hoofdrechtengroep: tbrechten.dldpclbag)
      * EN de instelling *Sectie: KoppelingBAG* en *Item: Ontvangstadres* bestaat en kolom *Tekst* is gevuld met het endpoint voor beantwoordensynchronevraag
      * EN de instelling *Sectie: KoppelingBAG* en *Item: HTTPSoapAction_tgoLv01* bestaat en kolom *Tekst* is gevuld met `[http://www.egem.nl/StUF/sector/bg/0310/tgoLv01](http://www.egem.nl/StUF/sector/bg/0310/tgoLv01)`
      * EN de stuurgegevens (kolom *Tekst*) bij *Sectie: KoppelingBAG op Items: ontvanger_applicatie en ontvanger_organisatie en zender_applicatie en zender_organisatie* zijn gevuld
      * EN - indien de inlogger lid is van een compartiment - dan moet de betreffende gemeente in dat compartiment vallen.

### Triggers rechtsboven in menu opties

  * Teken vlak op kaart:
    * Zichtbaar en enabled indien: 
      * de inlogger behoort tot een rechtengroep die wijzigrechten heeft op locaties (locatieadressen zichtbaar bij hoofdrechtengroep)
      * EN indien de kolom waarin de polygoon coördinaten worden opgeslagen nog leeg is
      * EN - indien de inlogger lid is van een compartiment - dan moet de betreffende gemeente in dat compartiment vallen.
  * Wijs x- en y-coördinaat aan op kaart:
    * Zichtbaar en enabled indien: 
      * de inlogger behoort tot een rechtengroep die wijzigrechten heeft op locaties (locatieadressen zichtbaar bij hoofdrechtengroep)
      * EN indien de kolommen x- en y-coördinaat beide nog leeg zijn
      * EN - indien de inlogger lid is van een compartiment - dan moet de betreffende gemeente in dat compartiment vallen.

### Triggers in scherm

  * Knop **Ga naar ruimtelijke plannen** ([http://www.ruimtelijkeplannen.nl](http://www.ruimtelijkeplannen.nl)) op grond van adresgegevens (dus niet op grond van het bestemmingsplannummer of naam):
    * Altijd zichtbaar en enabled.  

### De betekenis van de belangrijkste kolommen

  * **identificatiecode** (dvidentificatiecode): Deze kolom wordt zowel gebruikt voor de (BAG) verblijfsobject-identificatie als voor ligplaats- en standplaatsidentificatie. Deze identificatiecode bestaat uit de viercijferige gemeentecode volgens GBA tabel 33, gevolgd door een tweecijferige objecttypering en een voor de registrerende gemeente 10-cijferig uniek volgnummer (met voorloopnullen). De objecttypering kan zijn:
    * 01 - verblijfsobject (LET OP: Bij BAG-verificatie wordt altijd gevraagd naar verblijfsobject!!!)
    * 02 - ligplaats 
    * 03 - standplaats 
    * 10 - pand
    * 20 - nummeraanduiding
    * 30 - openbare ruimte 
  * **Pand-identificatie** (dvbagidentcode_2). Kan worden gevuld bij Operations (portaal Operations) *Import BAG-Extract* en *Import BAGmutaties* indien het gaat om een verblijfsobject.
  * **Nummeraanduiding-identificatie** (dvbagidentcode_3). Wordt gevuld bij Operations (portaal Operations) *Import BAG-Extract* en *Import BAGmutaties* 
  * **BAG-verificatiedatum** (ddcontrolebag): Wordt gevuld met de datum van handeling wanneer een BAG-verificatie gelukt is. Wordt leeggemaakt wanneer een BAG-verificatie mislukt   
  * **Vervaldatum** (ddvervaldatum). Indien gevuld dan kan het adres niet meer als locatie worden gekozen bij het aanmaken van een nieuwe zaak of inrichting. Kan worden gevuld bij Operations (portaal Operations) *Import BAG-Extract* en *Import BAGmutaties* 
  * ** X- en Y-coördinaat**. Invoer in rijksdriehoekcoördinaten in gehele getallen
  * ** Polygoon**. Wordt op twee manieren ondersteund:
    * invoer als multipoint in paren van x-y coördinaten (rijksdriehoek), waarbij x en y worden gescheiden door een komma. Het scheidingsteken tussen twee paren is een spatie (bijvoorbeeld: *145601,424980 145594,424975 145601,424980)*
    * invoer als PosList van LineairRing x-y-z coördinaten (rijksdriehoek). Alle waarden gescheiden door spatie (bijv. *145601.935 424980.489 0.0 145594.922 424975.594 0.0 145601.935 424980.489 0.0*)
  * **Bestemmingplan**. De dropdownlist toont een lijst uit tbbestemmingsplannen (portaal Zaakbeheer) die niet vervallen zijn en waarbij de gemeente-id leeg is OF overeenkomt met die van het het locatieadres. Bij geldend worden alleen die bestemmingsplannen getoond met de eigenschap dlinvoorbereiding = 'F'
  * **Onbekend adres? (Aangevinkt dan wordt adres gebruikt voor zaken op onbekend BAG-adres)**. Het veld geeft aan of de locatie als een onbekend adres moet worden gezien. Daarmee wordt bedoelt het perceeladres/locatie die (vaak per openbareruimte/straat) gezien wordt als het adres om zaken/inrichtingen op aan te maken die niet op een specifiek huisnummer plaatsvinden. Voor de aangemaakte omgevings- en handhavingszaken EN inrichtingen op deze locatie kan er in het betreffende portaal een hoofdprojectlocatie worden aangemaakt via de tegel *Projectlocaties\ Kadastrale percelen* om de locatie nader te duiden met coördinaten of adresbeschrijving. In de koptekst van het zaak/inrichtingportaal zal dan de omschrijving van de hoofdprojectlocatie te zien zijn (kopregel 3) in plaats van de reguliere adresgegevens. 

