# Zaken/Inrichtingen/Locaties

Er zijn drie nieuwe tegels in OpenWave aangemaakt: [Alle zaken](/openwave/1.29/applicatiebeheer/probleemoplossing/module_overstijgende_schermen/zaken_inrichtingen_locaties/zaken), [Alle inrichtingen](/openwave/1.29/applicatiebeheer/probleemoplossing/module_overstijgende_schermen/zaken_inrichtingen_locaties/inrichtingen) en [Alle locaties](/openwave/1.29/applicatiebeheer/probleemoplossing/module_overstijgende_schermen/zaken_inrichtingen_locaties/locaties).
De drie tegels zijn een alternatief voor het huidige Z/I-scherm (deze zal langzaam uit gefaseerd gaan worden).

De lijsten achter deze tegels zijn nu opgebouwd volgens de standaard Openwave getFexlist methode, hetgeen tot gevolg heeft dat het zoeken en filteren een stuk makkelijker is geworden.

