# Processen

Tabel met termijnbewakings - en afvinkstappen bij een zaak.

Voor de algortitmes die ten grondslag liggen aan de termijnbewakingsberekeningen zie:[Processen/termijnbewaking](/openwave/1.29/applicatiebeheer/probleemoplossing/programmablokken/processen).

Pagina's binnen dit onderwerp:

  * [Detailscherm bewerk ja/nee stap](/openwave/1.29/applicatiebeheer/probleemoplossing/module_overstijgende_schermen/processen/detailscherm_bewerk_ja_nee_stap)
  * [Detailscherm Processtap](/openwave/1.29/applicatiebeheer/probleemoplossing/module_overstijgende_schermen/processen/detailscherm_processtap)
  * [Lijst bewerk ja/nee stappen](/openwave/1.29/applicatiebeheer/probleemoplossing/module_overstijgende_schermen/processen/lijst_bewerk_ja_nee_stappen)
  * [Lijst Processtappen](/openwave/1.29/applicatiebeheer/probleemoplossing/module_overstijgende_schermen/processen/lijst_processtappen)

