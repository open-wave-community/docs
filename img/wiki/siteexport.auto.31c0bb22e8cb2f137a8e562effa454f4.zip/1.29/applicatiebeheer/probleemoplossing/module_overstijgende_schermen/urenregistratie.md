# Urenregistratie

Hier wordt de lijst van uren bij een zaak behandeld en dieper ingegaan op het detailscherm van een urenregistratie.

Voor het exporteren/factureren van geschreven uren zie: 
[Tegel Te factureren uren](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/openingsportaal/tegel_te_factureren_uren).

## Gerelateerde Pagina's

  * [Detailscherm Urenregistratie](/openwave/1.29/applicatiebeheer/probleemoplossing/module_overstijgende_schermen/urenregistratie/detailscherm_urenregistratie)
  * [Lijst Uren bij een Zaak](/openwave/1.29/applicatiebeheer/probleemoplossing/module_overstijgende_schermen/urenregistratie/lijst_van_uren_bij_een_zaak)

