# Lijst bewerk ja/nee stappen

De schermidentifier is MDLC_geefAfvinkstappenOverzicht.xml.

Dit scherm kan worden aangeroepen vanuit Lijst *Processtappen* (de knop is zichtbaar indien de instelling *Sectie: Processen* en *Item: AfvinkstappenGeenEigenScherm* NIET is aangevinkt).

## Probleem

Het scherm geeft een foutmelding:

  * er is mogelijk een zelf gedefinieerde schermindeling gebruikt (zie [Scherm(kolom)definitie](/openwave/1.29/applicatiebeheer/instellen_inrichten/schermdefinitie)) die niet valide is
  * de inlogger moet kijkrechten hebben op de processtappen bij betreffende hoofdzaak.

### Muteren

Een kolom kan gemuteerd worden indien:

  * de inlogger wijzigrechten heeft op de processtappen bij betreffende hoofdzaak (bijvoorbeeld wijzigrechten op proces/checklijst bij omgeving) 
  * EN die bovenliggende hoofdzaak niet is geblokkeerd
  * EN in de schermkolomdefinitie (beheer) is de eigenschap *lijst_automatisch in editmode* aangevinkt  
  * EN de kolom heeft de tag <edit> op true staan in de schermkolomdefinitie
  * EN - indien de inlogger lid is van een compartiment - dan moet het betreffende compartiment het zaaktype van de bovenliggende zaak bevatten en de gemeente waar die zaak speelt
  * EN - indien de inlogger GEEN lid is van een compartiment, dan mag de combinatie van het zaaktype van de bovenliggende zaak en de gemeente waar die zaak speelt in geen enkel compartiment voorkomen
  * EN de editschuif aan staat.

### Triggers

  * Dubbel klikken op een regel (buiten het aanvinkvakje) opent het detailscherm van een procesafvinkstap. Altijd enabled.

