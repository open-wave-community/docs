# Tabellen Standaardapi

De tegel is een trigger voor een lijst met metadata over een andere view of tabel ten behoeve van flexlist en flexdetail (zie: [Scherminformatie voor detailschermen](/openwave/1.29/applicatiebeheer/instellen_inrichten/schermdefinitie/scherminformatie_voor_detailschermen)).

  * De tegel is alleen zichtbaar voor inlogger wanneer: 
    * deze aan hem/haar is toegekend 
    * de evaluatie van het *SQL statement onzichtbaar* bij de tegeldefinitie een waarde ongelijk aan 0 oplevert
  * Een tegel is disabled indien zo aangevinkt bij de tegeldefinitie.

## Probleem

Het dynamische opschrift op tegels is niet zichtbaar:

  * indien foutieve queryverwijzing 
  * indien query zelf niet correct (zie [Queries](/openwave/1.29/applicatiebeheer/instellen_inrichten/queries))
  * indien inlogger geen recht heeft om query uit te voeren 
  * indien de kolom *altijd verversen* (tbportaltiles.dlaltijdrefreshen) op de tegeldefinitie uitgevinkt is.

## Tegeldefinitie

De tegel is standaard als volgt gedefinieerd ([Portal Tegeldefinitie](/openwave/1.29/applicatiebeheer/instellen_inrichten/portaldefinitie/portal_tegel)):

  * Portaal: *[beheerportaal-NIEUW](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal_nieuw)*
  * Kolom: *[Scherm- en Tegelbeheer](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal_nieuw/tegels_kolom_schermbeheer)*
  * Kopregel: *Tabellen Standaardapi*
  * Dynamisch tegelopschrift: 
  * Actie: *getFlexList(tbsysstandardtable)*

