# Tegels onder kolom Overige beheerportalen

Onder deze kolom vindt men tegels om te navigeren naar de overige beheerportalen.

## Tegels

  * [Servicecentrum](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal_nieuw/tegels_kolom_overige_portalen/servicecentrum)
  * [Operations](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal_nieuw/tegels_kolom_overige_portalen/operations)
  * [Zaakbeheer](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal_nieuw/tegels_kolom_overige_portalen/zaakbeheer)
  * [Inrichtingenbeheer](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal_nieuw/tegels_kolom_overige_portalen/inrichtingenbeheer)

