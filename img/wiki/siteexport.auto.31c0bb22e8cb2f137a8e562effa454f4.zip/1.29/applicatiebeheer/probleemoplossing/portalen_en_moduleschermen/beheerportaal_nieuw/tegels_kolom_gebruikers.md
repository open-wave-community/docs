# Tegels onder kolom Gebruikers

Onder deze kolom vindt men de tegels waaronder men de instellingen van de gebruikers van de OpenWave omgeving kan beheren.

Dit hoofdstuk is onderdeel van [Beheerportaal - NIEUW](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal_nieuw)

## Tegels

  * [Functionele rechten](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal_nieuw/tegels_kolom_gebruikers/rechten)
  * [Medewerkers (alle)](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal_nieuw/tegels_kolom_gebruikers/medewerkers_alle)
  * [Medewerkers (actief)](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal_nieuw/tegels_kolom_gebruikers/medewerkers_actief)
  * [Adviesinstanties](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal_nieuw/tegels_kolom_gebruikers/adviesinstanties)
  * [Teams](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal_nieuw/tegels_kolom_gebruikers/teams)
  * [Afdelingen](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal_nieuw/tegels_kolom_gebruikers/afdelingen)
  * [Loginverklaringen](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal_nieuw/tegels_kolom_gebruikers/loginverklaringen)
  * [IP-ranges](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal_nieuw/tegels_kolom_gebruikers/ipranges)
  * [Compartimentsrechten](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal_nieuw/tegels_kolom_gebruikers/compartimentsrechten)

