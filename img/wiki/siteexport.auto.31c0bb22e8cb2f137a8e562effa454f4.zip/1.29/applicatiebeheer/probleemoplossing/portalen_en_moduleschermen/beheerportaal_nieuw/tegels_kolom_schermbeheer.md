# Tegels onder kolom Scherm- en Tegelbeheer

Onder deze kolom vindt men de tegels die vallen onder het zogenaamde Scherm- en Tegelbeheer: de schermkolomdefinities, standaard tabellen en portaal-/tegelbeheer.

## Tegels

  * [Portal](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal_nieuw/tegels_kolom_schermbeheer/portal)
  * [Schermkolomdefinitie tabellen OW-API](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal_nieuw/tegels_kolom_schermbeheer/schermdef_tabellen_ow-api)
  * [Schermkolomdefinitie tabellen standaard-api](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal_nieuw/tegels_kolom_schermbeheer/schermdef_tabellen_standaardapi)
  * [Schermkolomdefinitie Rapportages](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal_nieuw/tegels_kolom_schermbeheer/schermdef_rapportages)
  * [Tabellen Standaardapi](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal_nieuw/tegels_kolom_schermbeheer/tabellen_standaardapi)
  * [Sysstandaard Categorieen](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal_nieuw/tegels_kolom_schermbeheer/standaard_categorien)

