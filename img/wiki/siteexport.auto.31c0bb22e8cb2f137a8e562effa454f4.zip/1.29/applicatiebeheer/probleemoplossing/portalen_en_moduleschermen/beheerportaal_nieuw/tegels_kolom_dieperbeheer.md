# Tegels onder kolom Dieper Beheer

Onder deze kolom vindt men de tegels die vallen onder het zogenaamde Dieper beheer: de configuratie instellingen, messagelog, audit bekijken etc.

Dit hoofdstuk is onderdeel van [Beheerportaal - NIEUW](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal_nieuw)

## Tegels

  * [Configuratie](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal_nieuw/tegels_kolom_dieperbeheer/configuratie)
  * [Ontbrekende configuratie items](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal_nieuw/tegels_kolom_dieperbeheer/ontbrekende_configitems)
  * [Queries](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal_nieuw/tegels_kolom_dieperbeheer/queries)
  * [Messagelog](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal_nieuw/tegels_kolom_dieperbeheer/messagelog)
  * [Audit](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal_nieuw/tegels_kolom_dieperbeheer/audit)
  * [Mislukte OLO-Bijlages](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal_nieuw/tegels_kolom_dieperbeheer/mislukte_bijlages)
  * [Rest Flexfuncties](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal_nieuw/tegels_kolom_dieperbeheer/restflex)
  * [Taskscheduler](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal_nieuw/tegels_kolom_dieperbeheer/taskscheduler)

