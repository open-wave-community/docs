# Tegels onder kolom Administratie

Onder deze kolom vindt men de tegels waaronder men de administratieve algemene beheerinstellingen kan vinden zoals contactpersoon rollen, vertrouwelijkheidsniveaus en gemeentes.

Dit hoofdstuk is onderdeel van [Beheerportaal - NIEUW](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal_nieuw)

## Tegels

  * [Gemeentes](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal_nieuw/tegels_kolom_administratie/gemeentes)
  * [Kadastrale Gemeentes](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal_nieuw/tegels_kolom_administratie/kadastrale_gemeentes)
  * [OIN-nummers](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal_nieuw/tegels_kolom_administratie/oinnummers)
  * [Adressoorten](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal_nieuw/tegels_kolom_administratie/adressoorten)
  * [Zaakgroepen](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal_nieuw/tegels_kolom_administratie/zaakgroepen)
  * [Dossierverblijf](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal_nieuw/tegels_kolom_administratie/dossierverblijf)
  * [Vertrouwelijkheidsindicatie](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal_nieuw/tegels_kolom_administratie/vertrouwelijkheid)
  * [DSO Projecten](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal_nieuw/tegels_kolom_administratie/dsoprojecten)
  * [Advies categorieën](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal_nieuw/tegels_kolom_administratie/advies_categorien)
  * [Urensoorten](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal_nieuw/tegels_kolom_administratie/urensoorten)

