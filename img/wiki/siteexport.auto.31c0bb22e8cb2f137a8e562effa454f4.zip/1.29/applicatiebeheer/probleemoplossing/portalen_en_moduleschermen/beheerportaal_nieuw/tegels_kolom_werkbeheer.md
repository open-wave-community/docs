# Tegels onder kolom Werkbeheer

Onder deze kolom vindt men de tegels die vallen onder het zogenaamde Werkbeheer: het inrichten van de processen, rapportages en documenten/e-mails. Zie [Beheerportaal Nieuw](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal_nieuw)

## Tegels

  * [Processen](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal_nieuw/tegels_kolom_werkbeheer/processen)
  * [Checklijsten](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal_nieuw/tegels_kolom_werkbeheer/checklijsten)
  * [Alle Rapportage-Definities](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal_nieuw/tegels_kolom_werkbeheer/alle_rapportage-_definities)
  * [Rapportage-definitie](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal_nieuw/tegels_kolom_werkbeheer/rapportages)
  * [Documentsjablonen](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal_nieuw/tegels_kolom_werkbeheer/docsjablonen)
  * [Sjabloongroepen](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal_nieuw/tegels_kolom_werkbeheer/sjabloongroepen)
  * [Emailsjablonen](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal_nieuw/tegels_kolom_werkbeheer/mailsjablonen)
  * [Documenttypen](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal_nieuw/tegels_kolom_werkbeheer/documenttypen)
  * [Tekstblokken](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal_nieuw/tegels_kolom_werkbeheer/tekstblokken)
  * [Images](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal_nieuw/tegels_kolom_werkbeheer/images)
  * [Geo kaartlagen](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal_nieuw/tegels_kolom_werkbeheer/geokaartlagen)
  * [Container Exportrapportages](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal_nieuw/tegels_kolom_werkbeheer/containerapportages)

