# Tegel Energie

[<img src="../../../../../applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/inrichtingen_portaal/energie.w.200_tok.e03f41.png?w=200&tok=e03f41" class="media" loading="lazy" alt="" width="200" />](/_detail/openwave/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/inrichtingen_portaal/energie.png?id=openwave%3A1.29%3Aapplicatiebeheer%3Aprobleemoplossing%3Aportalen_en_moduleschermen%3Ainrichtingen_portaal%3Ategel_energie)

## Trigger

De tegel is een trigger voor een tabel om *Energieverbruik* van een inrichting per jaar en soort te noteren.

  * De tegel is alleen zichtbaar voor inlogger wanneer: 
    * deze aan hem/haar is toegekend 
    * de evaluatie van het *SQL statement onzichtbaar* bij de tegeldefinitie een waarde ongelijk aan 0 oplevert. 
  * Een tegel is disabled indien zo aangevinkt bij de tegeldefinitie.
  * Indien gewenst kan het opschrift van de tegel aangepast worden zodat voor iedere energieregistratie ook het exact verbruik, formaat van de aansluiting en grootverbruiker indicatie getoond worden. Zoek de query inrichting_energie op via beheertegel Queries en vervang het SQL-statement door: 

```sql
select 'Jaar: ' || coalesce(dnjaar,0) || ', Soort: ' || coalesce(dvomschrijving,'') || '<br>Verbruikcat: ' || 
coalesce(dvverbruikcat,'') || ', Exact verbruik: ' || coalesce(dnexactverbruik,0) || '<br>Grootverbruiker: ' || 
(select case when dlgrootverbruiker = 'T' then 'J' else 'N' end) || '<br>Formaataansluiting: ' || 
coalesce(dvformaataansluiting,'') from vwfrmmilenergie where dnkeymilinrichtingen = {id} order by dnjaar DESC LIMIT 4
```

## Probleem

Het dynamische opschrift op tegels is niet zichtbaar:

  * indien foutieve queryverwijzing (codering *inrichting_energie*) 
  * indien query zelf niet correct (zie [Queries](/openwave/1.29/applicatiebeheer/instellen_inrichten/queries))
  * indien inlogger geen recht heeft om query uit te voeren. 

## Tegeldefinitie

De tegel is standaard als volgt gedefinieerd ([Portal Tegeldefinitie](/openwave/1.29/applicatiebeheer/instellen_inrichten/portaldefinitie/portal_tegel)):

  * Portaal: *inrichtingdetail*
  * Kolom: *Duurzaamheid*
  * Kopregel: *Energie*
  * Dynamisch tegelopschrift: *getTileContent(inrichting_energie,{id})*
  * Actie: *getFlexList(tbmilenergie,tbmilinrichtingen,{id},nil,V)*

