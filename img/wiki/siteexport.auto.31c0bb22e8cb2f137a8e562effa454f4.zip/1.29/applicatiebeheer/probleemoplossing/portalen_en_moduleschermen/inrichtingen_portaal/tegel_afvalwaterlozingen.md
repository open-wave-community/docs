# Tegel Afvalwater Lozingen

[<img src="../../../../../applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/inrichtingen_portaal/afvalwaterlozingen.w.200_tok.62a2ef.png?w=200&tok=62a2ef" class="media" loading="lazy" alt="" width="200" />](/_detail/openwave/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/inrichtingen_portaal/afvalwaterlozingen.png?id=openwave%3A1.29%3Aapplicatiebeheer%3Aprobleemoplossing%3Aportalen_en_moduleschermen%3Ainrichtingen_portaal%3Ategel_afvalwaterlozingen)

## Trigger

De tegel is een trigger voor een tabel met Waterlozingspunten per inrichting.

  * De tegel is alleen zichtbaar voor inlogger wanneer: 
    * deze aan hem/haar is toegekend 
    * de evaluatie van het *SQL statement onzichtbaar* bij de tegeldefinitie een waarde ongelijk aan 0 oplevert. 
  * Een tegel is disabled indien zo aangevinkt bij de tegeldefinitie.

## Probleem

Het dynamische opschrift op tegels is niet zichtbaar:

  * indien foutieve queryverwijzing (codering *inrichting_waterloz*) 
  * indien query zelf niet correct (zie [Queries](/openwave/1.29/applicatiebeheer/instellen_inrichten/queries))
  * indien inlogger geen recht heeft om query uit te voeren. 

## Tegeldefinitie

De tegel is standaard als volgt gedefinieerd ([Portal Tegeldefinitie](/openwave/1.29/applicatiebeheer/instellen_inrichten/portaldefinitie/portal_tegel)):

  * Portaal: *inrichtingdetail*
  * Kolom: *Water*
  * Kopregel: *Afvalwater lozingen*
  * Dynamisch tegelopschrift: *getTileContent(inrichting_waterloz,{id}))*
  * Actie: *getFlexList(tbmilemwater,tbmilinrichtingen,{id},nil,V)*

