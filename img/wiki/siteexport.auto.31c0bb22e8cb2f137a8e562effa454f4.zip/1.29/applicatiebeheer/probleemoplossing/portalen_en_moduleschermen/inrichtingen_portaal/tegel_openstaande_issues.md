# Tegel Openstaande Overtredingen

[<img src="../../../../../applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/inrichtingen_portaal/dokuwiki_openstaande_overtredingen.w.200_tok.5b9530.png?w=200&tok=5b9530" class="media" loading="lazy" alt="" width="200" />](/_detail/openwave/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/inrichtingen_portaal/dokuwiki_openstaande_overtredingen.png?id=openwave%3A1.29%3Aapplicatiebeheer%3Aprobleemoplossing%3Aportalen_en_moduleschermen%3Ainrichtingen_portaal%3Ategel_openstaande_issues)

## Trigger

De tegel is een trigger voor het lijstscherm met *Openstaande overtredingen* bij een inrichting([Inspecties](/openwave/1.29/applicatiebeheer/probleemoplossing/module_overstijgende_schermen/inspecties)).

  * De tegel is alleen zichtbaar voor inlogger wanneer: 
    * deze aan hem/haar is toegekend 
    * de evaluatie van het *SQL statement onzichtbaar* bij de tegeldefinitie een waarde ongelijk aan 0 oplevert. 
  * Een tegel is disabled indien zo aangevinkt bij de tegeldefinitie.

## Probleem

Het dynamische opschrift op tegels is niet zichtbaar:

  * indien foutieve queryverwijzing (codering *inrichting_opinspis*) 
  * indien query zelf niet correct (zie [Queries](/openwave/1.29/applicatiebeheer/instellen_inrichten/queries))
  * indien inlogger geen recht heeft om query uit te voeren.

## Tegeldefinitie

De tegel is standaard als volgt gedefinieerd ([Portal Tegeldefinitie](/openwave/1.29/applicatiebeheer/instellen_inrichten/portaldefinitie/portal_tegel)):

  * Portaal: *inrichtingdetail*
  * Kolom: *Welke controles*
  * Kopregel: *Openstaande overtredingen*
  * Dynamisch tegelopschrift: *getTileContent(inrichting_opinspis,{id})*
  * Actie: *getFlexList(tbinsponrechtm,tbmilinrichtingen,{id},O,V)*

