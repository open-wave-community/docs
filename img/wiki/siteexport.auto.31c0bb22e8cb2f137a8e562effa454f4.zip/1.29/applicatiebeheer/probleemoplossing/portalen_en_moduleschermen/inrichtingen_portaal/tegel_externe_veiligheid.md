# Tegel Externe Veiligheid

[<img src="../../../../../applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/inrichtingen_portaal/externe_veiligheid.w.200_tok.d0e79d.png?w=200&tok=d0e79d" class="media" loading="lazy" alt="" width="200" />](/_detail/openwave/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/inrichtingen_portaal/externe_veiligheid.png?id=openwave%3A1.29%3Aapplicatiebeheer%3Aprobleemoplossing%3Aportalen_en_moduleschermen%3Ainrichtingen_portaal%3Ategel_externe_veiligheid)

## Trigger

De tegel is een trigger voor een tabel met soorten opslagvoorzieningen die te maken hebben met de rubriek *Externe veiligheid* per inrichting.
Alle rijen uit tbmilopslag vallen hieronder waarvoor geldt dat ze gekoppeld zijn aan de rubriek met tbmilrubiek.dvcode = 9 (= externe veiligheid: zie tegel milieurubrieken op het inrichingsbeheerportaal onder kolom Kenmerken en Verplichtingen). Zie voor indeling, rubricering van de opslagkaarten [Opslagtabel bij inrichtingen](/openwave/1.29/applicatiebeheer/instellen_inrichten/opslag_bij_inrichtingen)

  * De tegel is alleen zichtbaar voor inlogger wanneer: 
    * deze aan hem/haar is toegekend 
    * de evaluatie van het *SQL statement onzichtbaar* bij de tegeldefinitie een waarde ongelijk aan 0 oplevert. 
  * Een tegel is disabled indien zo aangevinkt bij de tegeldefinitie.

## Probleem

Het dynamische opschrift op tegels is niet zichtbaar:

  * indien foutieve queryverwijzing (codering *inrichting_extveilopslag*) 
  * indien query zelf niet correct (zie [Queries](/openwave/1.29/applicatiebeheer/instellen_inrichten/queries))
  * indien inlogger geen recht heeft om query uit te voeren. 

## Tegeldefinitie

De tegel is standaard als volgt gedefinieerd ([Portal Tegeldefinitie](/openwave/1.29/applicatiebeheer/instellen_inrichten/portaldefinitie/portal_tegel)):

  * Portaal: *inrichtingdetail*
  * Kolom: *Veiligheid*
  * Kopregel: *Externe veiligheid*
  * Dynamisch tegelopschrift: *getTileContent(inrichting_extveilopslag,{id})*
  * Actie: *getFlexList(tbmilopslag,tbmilinrichtingen,{id},9,V)*

