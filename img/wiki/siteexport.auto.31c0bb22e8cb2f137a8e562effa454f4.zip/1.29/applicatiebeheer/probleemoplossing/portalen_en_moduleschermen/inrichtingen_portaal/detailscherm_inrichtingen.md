# Detailscherm Inrichting

Zie *API geefInrichtingDetail* [https://api.open-wave.nl/RemMethods/getRemMethod/111](https://api.open-wave.nl/RemMethods/getRemMethod/111).

De schermidentifier is MDDC_geefInrichtingDetail.xml.

## Probleem

Het scherm geeft een foutmelding:

  * er is mogelijk een zelf gedefinieerde schermindeling gebruikt die niet valide is. 

## Muteerrechten

De kolommen kunnen gemuteerd worden indien:

  * de inlogger lid is van een rechtengroep die wijzigrechten heeft op de Inrichting
  * EN de inrichting niet is geblokkeerd 
  * EN de editschuif aan staat
  * EN - indien de inlogger lid is van een [compartiment](/openwave/1.29/applicatiebeheer/instellen_inrichten/compartimenten) - dan moet het betreffende compartiment de bedrijfsoort van de inrichting bevatten en de gemeente waar deze zaak speelt
  * EN - indien de inlogger GEEN lid is van een compartiment -, dan mag de combinatie van de bedrijfsoort van de inrichting en de gemeente waar de zaak speelt in geen enkel compartiment voorkomen.

Hierop gelden de volgende uitzonderingen:

  *  de kolom *externe zaak/dms nummer* kan alleen ge-edit worden indien de inlogger lid is van een rechtengroep die bij de inrichtingsrechten het recht *wijzigen externe zaaknummers* aangevinkt heeft staan
  * er is een apart recht voor de categorie-velden beschikbaar: *Wijzigen van Categorie-velden zoals Ippc en Rud (dlbmilinrcatedt)*. In de standaard uitgeleverde schermdefinitie staat op de volgende kolommen de afweging dat dit categorierecht aangevinkt moet staan (men kan de afweging indien gewenst ook op andere kolommen zetten (of verwijderen) door middel van aanpassen van de schermdefinitie):
    * Ippc
    * Ippc-categorie
    * Mja
    * E-prtr
    * Eprtr-categorie
    * Rud
    * Bevi/revi
    * Brzo

  * als de inlogger op de medewerkerskaart *overrule compartiment* aangevinkt heeft staan, dan vervallen de compartimentsrestricties.

## Bijzondere kolommen

### Blok Wet- en regelgeving

Bevoegd gezag (rijk, provincie of gemeente).

De bevoegdgezag omschrijving (vwfrmmilinrichtingen.dvomsbevoegdgezag) wordt als volgt berekend: Indien:

  * de instelling *Sectie: Inrichtingen en Item: BevoegdgezagdoorBor* aangevinkt is, dan kijkt OpenWave enkel naar de gekoppelde BOR-coderingen. De codering met het hoogste bevoegd gezag (beheertegel *BOR-coderingen*) bepaalt de waarde (dus Gemeente, Provincie, Rijk). 
  * Indien deze instelling NIET is aangevinkt dan:
    * indien het hoogste gezag van de gekoppelde BOR-coderingen het Rijk betreft, dan blijft bevoegd gezag *Rijk*
    * anders, indien de kolom *IPPC* aangevinkt is EN de IPPC-codering begint met een '4' dan wordt - ongeacht de BOR-codering - de *Provincie* het bevoegd gezag
    * anders, indien de kolom *BRZO* aangevinkt is dan wordt - ongeacht de BOR-codering - ook de *Provincie* het bevoegd gezag
    * anders, indien het hoogste gezag van de gekoppelde BOR-coderingen de Provincie betreft, maar zowel de kolom *IPPC* en *BRZO* staan uitgevinkt, dan wordt de gemeente het bevoegd gezag
    * anders, indien het hoogste gezag van de gekoppelde BOR-coderingen de Provincie betreft, maar minimaal één van de kolommen *IPPC* en *BRZO* staan aangevinkt dan blijft de provincie het bevoegd gezag   
    * anders, indien het hoogste gezag van de gekoppelde BOR-coderingen de Gemeente betreft blijft de gemeente het bevoegd gezag.

#### Blok Duurzaamheid en vervoer

De indicatie of er meer dan 500 bezoekers per dag zijn (vwfrmmilinrichtingen.dlveelbezperdag) wordt als volgt aan-/uitgezet:

  * indien het veld *Aantal bezoekers* (vwfrmmilinrichtingen.dnaantalbezoekers) wordt gevuld met een getal groter dan 500, zal de indicatie aangezet worden 
  * andersom zal de indicatie uitgevinkt worden als het veld *Aantal bezoekers* gevuld wordt met een getal 500 of lager
  * als een gebruiker handmatig het veld aan- dan wel uitvinkt EN veld *Aantal bezoekers* is gevuld, dan zal bovenstaande controle worden uitgevoerd: 
    * voldoet inrichting aan de voorwaarde dan zal het veld gewijzigd worden
    * voldoet inrichting NIET aan de voorwaarde dan zal een foutmelding verschijnen en wordt de gemaakte wijziging niet opgeslagen.

### Blok Classificatie

  * De kolom **Hoofdmba** geeft de MBA code weer van de gekoppelde Milieu Belastende Activiteiten waarvoor geldt dat dlhoofdmba de waarde T heeft (OpenWave zorgt ervoor dat maar één MBA per inrichting een hoofdmba kan zijn).
  * De kolom **Hoofdsbi** geeft de SBI code weer van de gekoppelde SBI's waarvoor geldt dat dlhoofdsbi de waarde T heeft (OpenWave zorgt ervoor dat maar één SBI per inrichting een hoofdsbi kan zijn).
  * De kolom **Branche** laat de brancheomschrijving zien uit de beheertabel tbinspbesturingsmodel (beheertegel *LHS/Besturingsmodel*) die via de hoofdsbi code van de inrichting wordt opgehaald: (tbmilcodesbi op beheertegel *SBI-coderingen*).
  * De kolom **Contr.klasse**. Deze kolom vwfrmmilnrichting.dvbestmodcodecontrfreq laat de dvcode uit tabel tbmilurgentie (beheertegel *Urgentieklassen, controlefrequentie*) zien van de rij die in de beheertabel tbinspbesturingsmodel (beheertegel *LHS/Besturingsmodel*) is gekozen bij de branche die via de hoofdsbi code van de inrichting hier wordt opgehaald. Toepassing zie: [Cyclische Toezicht: controle frequentie](/openwave/1.29/applicatiebeheer/probleemoplossing/programmablokken/cyclische_inspecties).
  * De kolom **REV** (dlrggs) is niet muteerbaar, maar wordt in de view (vwfrmmilinrichtingen) automatisch gevuld (aangevinkt) indien de kolom dvidentificatie (de rev-identificatie van de locatie-evactiviteit) is gevuld.

### Blok REV (register externe veiligheid)

De inrichting is de locatie-evactiviteit van het REV. Aan de inrichting kunnen nul of meer ev-activiteiten zijn verbonden (zie op inrichtingenportaal tegel *REV-BKLactiviteiten*: tbmilbklactiviteiten). Aan een BKL-activiteit kunnen één of meer referentiecontouren zijn gekoppeld (tbmilopslag). Aan een referentiecontour één of meer ev-contouren (tbmilopslagevcontouren).

De locatie-evactiviteit (dus de inrichting) heeft zelf voor het REV relevante attributen: dvgmlpolyoon, dvinrichtingnaam, dvhandelsnaam, dvkvknr, ddbegingeldigheid en ddeindgeldigheid. Indien één van deze kolommen een andere waarde krijgt of wanneer de inrichting aan een ander perceeladres wordt gekoppeld, dan wordt de kolom dddatumlaatstewijziging vanzelf gevuld met een timestamp: een trigger om een update naar het REV te sturen.

De identificatie wordt automatisch gevuld bij het vullen van de ddbegingeldigheid met de waarde namespace/bronhoudercode + '.' + dvinrichtingnummer + '_' + dnkey. Indien de inlogger het recht *Wijzigen van REV-identificatiecode van tbmilinrichtingen* (tbmilrechten.dlbmilinrrevidedt) heeft, kan deze berekende identificatie worden overschreven.

De namespace/bronhoudercode wordt opgehaald uit de kolom *Tekst* van de instelling  *sectie: Inrichtingen en Item: REVNamespaceIdentificatie* (bijv. *NL.IMEV.00002*).
Ook de kolom *OW_Identificatie locatie-evactiviteit* (dvrevbronobjectid) wordt - indien leeg - automatisch gevuld bij het vullen van de beginGeldigheiddatum met een uniek UUID-code.

Voor de daadwerkelijke export moet de datumkolom *Klaargezet voor export* (ddmagexport) gevuld zijn. Dit is gekoppeld aan het recht: *Mag inrichting klaarzetten voor export REV* (tbmedewerkers.dlmagrevexportzetten) op de medewerkerskaart.

Bij het vullen of leeghalen van deze kolom wordt automatisch de medewerkerscode gevuld van de kolom *door:* (dvcodemwmagexport). Indien deze kolom Door ((dvcodemwmagexport) NIET is gevuld en de kolom ddmagexport is wel gevuld, dan betekent dat, dat de inrichtingskaart is bewerkt via het Synchroniseren REV.

Zie verder [Register Externe Veiligheid](/openwave/1.29/applicatiebeheer/instellen_inrichten/register_exrterne_veiligheid). 

### Blok Zwemgelegenheid

Dit blok is alleen zichtbaar wanneer de *dvbedrijfsrtcode* van de desbetreffende inrichting “ZWEM” is.

Deze *dvbedrijfsrtcode* is aan te maken vanuit het *inrichtingenbeheer-portaal* bij de tegel *Inrichting bedrijfssoort*. Wanneer er vanuit deze tegel een kaart bestaat die als code “ZWEM” heeft, is deze bij het inrichtingendetailscherm in te vullen bij het blok *Classificering*, onder de keuzelijst *Soort object/inrichting/bedrijf*. Zodoende wordt het blok *Zwemgelegenheid* zichtbaar in het inrichtingendetailscherm, waar gegevens van de zwemgelegenheid genoteerd kunnen worden.

Zie verder [Zwemwater bij inrichtingen](/openwave/1.29/applicatiebeheer/instellen_inrichten/zwemwater).

## Triggers

### Triggers achter kolommen in het scherm

  * **(ont)koppel inrichting aan moeder**:
    * de knop is altijd zichtbaar 
    * de knop is disabled indien de inrichting geblokkeerd is, of de inlogger heeft geen muteerrecht (zie boven) op inrichting.
  * **NHR-gegevens controleren**:
    * de knop is alleen zichtbaar als de ingelogde medewerker in een rechtengroep zit waaraan het BRP/NHR bevragen recht is toegekend.
  * **Blokkeer Inrichting**:
    * zichtbaar en enabled indien:
      * de inlogger lid is van een rechtengroep die bij de inrichting het recht blokkeren/deblokkeren heeft 
      * EN de inrichting nog niet geblokkeerd is.
  * **Open dossier in digitale Checklist** (vinkje achter dossier DC):
    * zichtbaar en enabled indien:
      * de instelling kolom *Tekst* bij *Sectie: KoppelingINSPTOETS* en *Item: Methode*, de waarde: digitalechecklisten heeft en aangevinkt is 
      * EN instelling kolom *Tekst* bij *Sectie: KoppelingINSPTOETS* en *Item: Navigeeradres*, is gevuld  (zie [Digitale checklijsten](/openwave/1.29/applicatiebeheer/probleemoplossing/programmablokken/digitale_checklijsten))
      * EN de externe DG-dossierid (tbmilinrichtingen.dvdgdossierid) is gevuld 
      * EN de instelling van *Sectie: KoppelingINSPTOETS en Item: BlokkeringNaarDossier* is NIET aangevinkt (of de instelling bestaat niet).
  * **Maak zaak in DMS/Zaaksysteem** (zie [Creëer Zaak DMS](/openwave/1.29/applicatiebeheer/probleemoplossing/programmablokken/creeer_zaak_zaak_dms)):
    * zichtbaar en enabled indien:
      * de inlogger editrechten heeft op de inrichting
      * EN de zaak/DMS codering een lege waarde heeft 
      * EN de inrichting niet is geblokkeerd 
      * EN de instelling *Sectie: Koppeling Zaak* en *Item: Methode* en *Tekst*: StUF-ZAKEN 310 staat aangevinkt 
      * EN de inlogger is lid van rechtengroep die bij de inrichtingsrechten *wijzigen externe zaaknummers* aangevinkt heeft staan
      * EN de kolom *Tekst* van de instelling *Sectie: Koppeling ZAAK* en *Item: ZaaktypeInrichting* heeft gevulde waarde (en de instelling moet aangevinkt zijn)
      * EN *Getal1* van instelling *Sectie: Koppeling Zaak* en *Item = Zender_Organisatie* is gevuld met een waarde  die verwijst naar een dnkey van een bestaand contactadres in tbcontactadressen (die van de zendende organisatie zelf).
  * Verplaats mappen/documenten (knop [<img src="../../../../../applicatiebeheer/icoon_map.w.20_tok.18d391.png?w=20&tok=18d391" class="media" loading="lazy" alt="" width="20" />](/_detail/openwave/applicatiebeheer/icoon_map.png?id=openwave%3A1.29%3Aapplicatiebeheer%3Aprobleemoplossing%3Aportalen_en_moduleschermen%3Ainrichtingen_portaal%3Adetailscherm_inrichtingen) achter veld *Map op fileshare*):
    * Zichtbaar en enabled indien:
      * verplaatsrecht documenten in documentTree (tbmilrechten.dlcmilinrcorverplaats) staat aan
      * compartimentsrechten ok.  

### Triggers rechtsboven in menu opties

  * **Creëer document** (zie ook bij programmablok [Creëer document](/openwave/1.29/applicatiebeheer/probleemoplossing/programmablokken/creeer_document))
    * zichtbaar indien de inlogger lid is van een rechtengroep die bij de inrichting het recht *creëren van documenten* heeft
    * de knop is disabled indien de zaak geblokkeerd is.
  * **Verplaats naar ander locatie-adres**: 
    * zichtbaar en enabled indien: 
      * de inlogger lid is van een rechtengroep die bij de inrichting het recht van *verplaatsen* heeft 
      * EN de zaak niet is geblokkeerd.
  * **Toon uploads bij deze zaak**:
    * zichtbaar en enabled indien: 
      * de instelling bij *Sectie: Documenten* en *Item: MultipleUpload* aangevinkt is 
      * EN de inlogger moet lid zijn van een rechtengroep die bij de inrichting het recht *uploaden van documenten* heeft.
  * **Teken vlak op kaart**:
    * zichtbaar en enabled indien: 
      * de inlogger editrechten heeft op de inrichting
      * EN indien de kolom waarin de polygoon coördinaten worden opgeslagen nog leeg is.
  * ** Controlezaak aanmaken**
    * zichtbaar indien:
      * De instelling bij *Sectie: Programma* en *Item: ControleZaakBijInrichting* aangevinkt is
      * EN de inlogger moet lid zijn van een rechtengroep die insertrechten heeft voor omgevingszaken
      * EN de inrichting mag niet geblokkeerd zijn 
      * enabled indien compartimentsrechten OK
    * Voor het aanmaken van controlezaken vanaf een inrichting geldt ook dat configuratie instelling *Sectie: Programma* en *Item: ControleZaakType* moet bestaan en er bij *Getal2* de dnkey van een geldig omgevingszaaktype opgegeven moet zijn. Op basis van dit zaaktype zal de controlezaak aangemaakt worden. Bij het zaaktype moet een default behandelaar gedefinieerd zijn en de verplichte adresrol moet *AVR* of *GEC*(gecontroleerde) zijn. Dit betekent dat er in het beheerportaal bij adresrollen, de rol AVR en GEC moeten bestaan en toegewezen aan tenminste module WE. Verder dient bij de inrichting zelf precies 1 contact met rol *AVR* aanwezig te zijn en 1 contact met rol *GEC*. Als aan deze condities wordt voldaan, dan pas zal de controlezaak aangemaakt kunnen worden waarbij de locatie, de twee contacten (AVR en GEC) overgenomen worden en eventuele projectlocaties/kadastrale percelen.

### Triggers linksonder in het scherm

  * **Toon kaart**: 
    * is altijd zichtbaar
    * is disabled indien de puntcoördinaten op het locatiescherm leeg zijn.
  * **Locatieadres**:
    * altijd zichtbaar en enabled.
  * **Memo**:
    * zichtbaar en enabled indien de inlogger lid is van een rechtengroep die Inrichtingen-memo mag zien. Voor het wijzigen van een memo moet de rechtengroep memo wijzigrechten aangevinkt hebben staan.
  * **Toon documenten** (Zie [Toon documenten en download](/openwave/1.29/applicatiebeheer/probleemoplossing/programmablokken/toon_documenten_en_download)): 
    * zichtbaar indien: 
      * rechten OK:
      * als de instelling *Sectie: Documenten Item: Documentregistratie* is aangevinkt (de knop geeft dan toegang tot de geregistreerde documenten), dan moet de gebruiker het recht *Inzien geregistreerde documenten (tbmilrechten.dlcmilinrcorregvsb)* hebben
      * anders, (deze instelling staat uit) dan wordt de (live-)lijst van opgeslagen documenten bij de zaak geopend: de gebruiker moet het het recht *Inzien documenten buiten registratie om (dlcmilinrcorvsb)* hebben
      * EN - wanneer de inrichting NIET wordt behandeld in een compartiment dan:
        * moet *Sectie: Documenten* en *Item: OphalenViaFileserver* OF *Sectie: Documenten* en *Item: OphalenViaDms* aangevinkt zijn
        * EN - indien OphalenViaDms - dan moet de kolom *Tekst* bij instelling *Sectie: KoppelingDocnaardms Item: Methode* de waarde StUF-ZAKEN 310 OF CMIS 1.0 hebben en aangevinkt staan
      * EN - wanneer de inrichting WEL wordt behandeld in een compartiment dan:
        * moet de kolom dlfileserver of dldms in het betreffende compartiment (beheerportaal-Nieuw) aangevinkt zijn
        * EN – indien dlDms aangevinkt dan moet de kolom tbcompartiment.dvdmsmethode de waarde StUF-ZAKEN 310 OF CMIS 1.0 hebben.
    * De knop is disabled indien: 
      * geen fileserver en wel DMS
      * EN methode is StUF-ZAKEN 310
      * EN de externe zaakcode (dvintzaakcode) is leeg.
  * **Upload documenten** (zie bij programmablok [Upload document](/openwave/1.29/applicatiebeheer/probleemoplossing/programmablokken/upload_document)):
    * zichtbaar indien: 
      * de instelling *Sectie: Documenten en Item: MultipleUpload* aangevinkt is
      * EN - wanneer de inrichting NIET wordt behandeld in een compartiment dan: 
        * moet *Sectie: Documenten en Item: OphalenViaFileserver* OF *Sectie: Documenten en Item: OphalenViaDms* aangevinkt zijn
        * EN - indien OphalenViaDms - dan moet de kolom *Tekst* bij instelling *Sectie: KoppelingDocnaardms Item: Methode* de waarde StUF-ZAKEN 310 OF CMIS 1.0 hebben en aangevinkt staan
      * EN - wanneer de horecazaak WEL wordt behandeld in een compartiment dan:
        * moet de kolom dlfileserver of dldms in het betreffende compartiment (beheerportaal-Nieuw) aangevinkt zijn
        * EN – indien dlDms aangevinkt dan moet de kolom tbcompartiment.dvdmsmethode de waarde StUF-ZAKEN 310 OF CMIS 1.0 hebben.
    * de knop is disabled indien: 
      * de inlogger lid is van een rechtengroep die NIET het recht *uploaden van documenten* heeft bij de inrichting
      * OF de inrichting geblokkeerd is
      * OF compartimentrecht is niet OK
      * OF - indien geen fileserver en wel DMS
        * EN methode is StUF-ZAKEN 310
        * EN de externe zaakcode (dvintzaakcode) is leeg.
  * **Urenregistratie**:
    * zichtbaar en enabled indien de inlogger: 
      * het recht Inzien uren heeft voor inrichtingen (Functionele rechten, inrichtingen)
      * OF het recht *mag uren van anderen muteren* aangevinkt heeft staan op de medewerkerskaart.
  * **Maak Nieuwe Zaak vanuit Inrichting:**
    * zichtbaar indien:
      * de instelling *Sectie: Programma *en* Item: NieuweZaakBijInrichting *bestaat en is aangevinkt
    * de knop is disabled indien 
      * de inrichting geblokkeerd is 
      * OF compartimentrecht niet OK is
    * de wizard is niet uitvoerbaar indien niet aan onderstaande 2 voorwaarden is voldaan - de wizard toont dan slechts een foutmelding:  
      * dat de inlogger lid is van een rechtengroep die nieuwe omgevingszaken kan aanmaken
      * net als bij een controlezaak dient bij de inrichting precies één contactpersoon met de rol van AVR (aanvrager) te bestaan. Ook in dit geval betekent dat de rol AVR in het beheerportaal bij adresrollen is toegewezen aan de module I(nrichtingen) en W(omgevingszaken)
    * Indien aan de voorwaarden is voldaan kan met de wizard een nieuwe, aan de inrichting gekoppelde omgevingszaak worden aangemaakt. Net als bij het aanmaken van een controlezaak vanuit een inrichting, zullen de locatiegegevens van de inrichting bij de nieuwe zaak worden overgenomen, evenals eventuele projectlocaties / kadastrale percelen. De wizard maaknieuwezaakvanuitinrichting bevat echter ook keuzemogelijkheden voor de zaak in kwestie. De inlogger kiest eerst een zaaktype voor de nieuwe zaak. Vervolgens kijkt de wizard naar de aanwezige instellingen voor het aanmaken van een nieuwe omgevingszaak (omschrijving, behandelaar, team). De zaak is, eenmaal aangemaakt, te vinden onder de tegel *Lopende Zaken* in het portaal van de inrichting.

