# Tegels onder kolom Overig

Onder deze kolom vindt men gebundeld de **Overige gegevens** van de DSO-zaken behorende bij het DSO project. Onder DSO-zaken behorende bij het DSO project wordt verstaan alle omgevingsvergunningen waarvoor geldt dat dnkeydsoproject gelijk is aan het portaalid (de dnkey van het DSO project waar men de gegevens van ziet).

De tegels van deze kolom zijn altijd zichtbaar voor de medewerker en aanklikbaar (mits deze kijkrechten heeft voor omgevingszaken, en de kijkrechten heeft voor bijvoorbeeld leges indien men klikt op tegel *Leges*).

## Tegels

  * [Onderdelen/Activiteiten](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/dsoprojectportaal/tegels_kolom_overig/onderdelen_activiteiten): toont de lijst met alle **Onderdelen/Activiteiten** vallende onder het DSO project. De gegevens uit de lijst worden gehaald uit vwfrmtoestemmingen
  * [Dossierbehandelaars](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/dsoprojectportaal/tegels_kolom_overig/dossierbehandelaars) : toont de lijst met alle actieve **Dossierbehandelaars** vallende onder het DSO project (distinct getoond). De gegevens uit de lijst worden gehaald uit vwfrmdsoprojectbehandelaars
  * [Contactadressen](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/dsoprojectportaal/tegels_kolom_overig/contactadressen) : toont de lijst met alle **Contactpersonen** vallende onder het DSO project (distinct getoond op combinatie Rol en dnkeycontactadres). De gegevens uit de lijst worden gehaald uit vwfrmdsoprojectcontacten
  * [Leges](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/dsoprojectportaal/tegels_kolom_overig/leges) : toont de lijst met alle **Leges** vallende onder het DSO project. De gegevens uit de lijst worden gehaald uit vwfrmlegesregels
  * [Geregistreerde  documenten](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/dsoprojectportaal/tegels_kolom_overig/geregistreerde_documenten) : toont de lijst met alle **Geregistreerde documenten** vallende onder het DSO project. De gegevens uit de lijst worden gehaald uit view vwfrmcorrespondentie
  * [Projectlocaties](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/dsoprojectportaal/tegels_kolom_overig/projectlocaties) : toont distinct de **Projectlocaties/kadastrale percelen** (geen dubbele regels voor gelijke combinatie kadaster, projectlocatie, wegdeel, vaardeel en coördinaten) vallende onder het DSO project. De gegevens uit de lijst worden gehaald uit vwfrmdsoprojectprojlocaties

