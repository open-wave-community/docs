# Tegels onder kolom Inrichtingen II

## Problemen

1) Het scherm ziet er raar uit (al of niet met een foutmelding) of reageert niet:

  * inlogger heeft geen kijkrechten
  * alle tegels zijn disabled of onzichtbaar op conditie (zie [Portaldefinitie](/openwave/1.29/applicatiebeheer/instellen_inrichten/portaldefinitie))
  * geen enkele tegel uit dit portal is toegekend aan inlogger.

2) Medewerker a ziet meer of minder tegels dan medewerker b:

kan alleen indien aan medewerkers a andere tegels zijn toegekend dan aan medewerker b.

### Triggers

Klikken op tegel opent een vervolgscherm.

Indien niet klikbaar dan is de tegel ingesteld als disabled (zie [Portaldefinitie](/openwave/1.29/applicatiebeheer/instellen_inrichten/portaldefinitie)).

## Index

  * [Tegels onder kolom Inrichtingen II](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_inrichtingen_ii)
    * [ADR-Indeling](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_inrichtingen_ii/adr_indeling)
    * [BWL coderingen](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_inrichtingen_ii/bwl-coderingen)
    * [Codering Dieren](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_inrichtingen_ii/codering_dieren)
    * [Codering Stallen](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_inrichtingen_ii/codering_stallen)
    * [Combinatie stal/dier](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_inrichtingen_ii/combinatie_stal_dier)
    * [Energieverbruik categorie](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_inrichtingen_ii/energieverbruikcat)
    * [Erkende Maatregelen;Bedrijfstakken,Soorten Maatregelen](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_inrichtingen_ii/erkende_maatregelen_bedrijfstakken_soorten_maatregelen)
    * [Erkende Maatregelen;Rubricering](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_inrichtingen_ii/erkende_maatregelen_rubricering)
    * [IPPC-categorieën](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_inrichtingen_ii/ippc-categorien)
    * [Milieu gegevenssoort](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_inrichtingen_ii/milieu_gegevenssoort)
    * [Nageschak. techniek bij stal](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_inrichtingen_ii/nageschak._techniek_bij_stal)
    * [Opslagstatus](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_inrichtingen_ii/opslagstatus)
    * [Opslagvoorziening](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_inrichtingen_ii/opslagvoorziening)
    * [Opslagwijze](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_inrichtingen_ii/opslagwijze)
    * [PAS coderingen](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_inrichtingen_ii/pascategorie)
    * [Projecten duurzaamheid](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_inrichtingen_ii/projecten_duurzaamheid)
    * [RAV/BWL-combinaties](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_inrichtingen_ii/rav_bwl-combinaties)
    * [Soort afvalstof](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_inrichtingen_ii/soort_afvalstof)
    * [Soort Waterlozing](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_inrichtingen_ii/soort_waterlozing)
    * [Vervoerders](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_inrichtingen_ii/vervoerders)
    * [ZZS-klasse](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_inrichtingen_ii/zzs_klasse)

