# Tegels onder kolom Instellingen II

## Problemen

1) Het scherm ziet er raar uit (al of niet met een foutmelding) of reageert niet:

  * inlogger heeft geen kijkrechten
  * alle tegels zijn disabled of onzichtbaar op conditie (zie [Portaldefinitie](/openwave/1.29/applicatiebeheer/instellen_inrichten/portaldefinitie))
  * geen enkele tegel uit dit portal is toegekend aan inlogger.

2) Medewerker a ziet meer of minder tegels dan medewerker b:

kan alleen indien aan medewerkers a andere tegels zijn toegekend dan aan medewerker b.

### Triggers

Klikken op tegel opent een vervolgscherm.

Indien niet klikbaar dan is de tegel ingesteld als disabled (zie [Portaldefinitie](/openwave/1.29/applicatiebeheer/instellen_inrichten/portaldefinitie)).

## Index

  * [Tegels onder kolom Instellingen II](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_instellingen_ii)
    * [Adviesinstanties](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_instellingen_ii/adviesinstanties)
    * [Combinatie product, klant, werkpakket](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_instellingen_ii/combinatie_product_klant_werkpakket)
    * [Container Export Rapportages](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_instellingen_ii/container_export_rapportages)
    * [Inspectietrajectsoorten](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_instellingen_ii/inspectietrajectsoorten)
    * [Leges-definitie](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_instellingen_ii/legesdefinitie)
    * [Prognose](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_instellingen_ii/prognose)
    * [Soorten bezwaar/beroep](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_instellingen_ii/soorten_bezwaar_beroep)
    * [Urgentieklassen/controlefrequentie](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_instellingen_ii/urgentieklassen)
    * [Zaaktypes APV/Overig](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_instellingen_ii/zaaktypes_apv_overig)
    * [Zaaktypes Bouw/Sloop](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_instellingen_ii/zaaktypes_bouw_sloop)
    * [Zaaktypes Handhaving](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_instellingen_ii/zaaktypes_handhaving)
    * [Zaaktypes Horeca](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_instellingen_ii/zaaktypes_horeca)
    * [Zaaktypes Infoaanvraag](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_instellingen_ii/zaaktypes_infoaanvraag)
    * [Zaaktypes Milieu/Gebruik](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_instellingen_ii/zaaktypes_milieu_gebruik)
    * [Zaaktypes Omgeving](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_instellingen_ii/zaaktypes_omgeving)

