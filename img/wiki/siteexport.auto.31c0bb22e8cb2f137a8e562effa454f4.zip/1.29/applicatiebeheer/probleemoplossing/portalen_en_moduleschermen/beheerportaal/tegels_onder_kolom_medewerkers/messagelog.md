# Messagelog

## Trigger

De tegel is een trigger voor een tabel waarin de de verzonden en ontvangen StUfZaken en StUfOLO berichten worden gelogd, zie bij Instellen/Inrichten: [MessageLog](/openwave/1.29/applicatiebeheer/instellen_inrichten/messagelog).

  * De tegel is alleen zichtbaar voor inlogger wanneer:
    * deze aan hem/haar is toegekend 
    * de evaluatie van het *SQL statement onzichtbaar* bij de tegeldefinitie een waarde ongelijk aan 0 oplevert. 
  * Een tegel is disabled indien zo aangevinkt bij de tegeldefinitie.

## Tegeldefinitie

De tegel is standaard als volgt gedefinieerd ([Portal Tegeldefinitie](/openwave/1.29/applicatiebeheer/instellen_inrichten/portaldefinitie/portal_tegel)):

  * Portaal: *[Beheer](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal)*
  * Kolom: *[Medewerkers](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_medewerkers)*
  * Kopregel: *Messagelog*
  * Actie: *getFlexList(tbmessagelog)*

