# BWL coderingen

## Trigger

De tegel is een trigger voor de view van mogelijke *BWL-coderingen* (Bodem Water Landelijk gebied) bij een inrichting.

  * De tegel is alleen zichtbaar voor inlogger wanneer: 
    * deze aan hem/haar is toegekend 
    * de evaluatie van het *SQL statement onzichtbaar* bij de tegeldefinitie een waarde ongelijk aan 0 oplevert. 
  * Een tegel is disabled indien zo aangevinkt bij de tegeldefinitie.

## Tegeldefinitie

De tegel is standaard als volgt gedefinieerd ([Portal Tegeldefinitie](/openwave/1.29/applicatiebeheer/instellen_inrichten/portaldefinitie/portal_tegel)):

  *  Portaal: *Beheer*
  *  Kolom: *Inrichtingen II* 
  *  Vast opschrift: *BWL-coderingen*
  *  Actie: *getFlexList(SysStandardList,,,,beheer_tbmilcodebwl)*

