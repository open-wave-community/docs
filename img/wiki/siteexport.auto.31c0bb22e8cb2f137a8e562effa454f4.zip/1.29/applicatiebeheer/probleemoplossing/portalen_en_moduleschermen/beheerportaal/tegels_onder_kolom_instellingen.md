# Tegels onder kolom Instellingen

## Problemen

1) Het scherm ziet er raar uit (al of niet met een foutmelding) of reageert niet:

  * inlogger heeft geen kijkrechten
  * alle tegels zijn disabled of onzichtbaar op conditie (zie [Portaldefinitie](/openwave/1.29/applicatiebeheer/instellen_inrichten/portaldefinitie))
  * geen enkele tegel uit dit portal is toegekend aan inlogger.

2) Medewerker a ziet meer of minder tegels dan medewerker b:

kan alleen indien aan medewerkers a andere tegels zijn toegekend dan aan medewerker b.

### Triggers

Klikken op tegel opent een vervolgscherm.

Indien niet klikbaar dan is de tegel ingesteld als disabled (zie [Portaldefinitie](/openwave/1.29/applicatiebeheer/instellen_inrichten/portaldefinitie)).

## Index

  * [Tegels onder kolom Instellingen](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_instellingen)
    * [Bestemmingsplannen](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_instellingen/bestemmingsplannen)
    * [Checklijsten](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_instellingen/checklijsten)
    * [Configuratie](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_instellingen/configuratie)
    * [Documentsjablonen](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_instellingen/documentsjablonen)
    * [Emailsjablonen](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_instellingen/emailsjablonen)
    * [Gemeentes](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_instellingen/gemeentes)
    * [Operations](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_instellingen/operations)
    * [Portal](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_instellingen/portal)
    * [Processen](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_instellingen/processen)
    * [Queries](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_instellingen/queries)
    * [Rapportage definitie](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_instellingen/rapportage_definitie)
    * [Rest Flexfuncties](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_instellingen/rest_flexfuncties)
    * [Schermkolomdefinitie rapportages](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_instellingen/schermkolomdefinitie_rapportages)
    * [Schermkolomdefinitie tabellen ow api](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_instellingen/schermkolomdefinitie_tabellen_ow-api)
    * [Schermkolomdefinitie tabellen standaard api](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_instellingen/schermkolomdefinitie_tabellen_standaardaardapi)
    * [Sjabloongroepen](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_instellingen/sjabloongroepen)
    * [Tabellen bij standaard API](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_instellingen/standaardtabellen)
    * [Wetten/Overtredingen](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_instellingen/wettelijke_basis_overtredingen)

