# Tegels onder kolom Brontabellen

## Problemen

1) Het scherm ziet er raar uit (al of niet met een foutmelding) of reageert niet:

  * inlogger heeft geen kijkrechten
  * alle tegels zijn disabled of onzichtbaar op conditie (zie [Portaldefinitie](/openwave/1.29/applicatiebeheer/instellen_inrichten/portaldefinitie))
  * geen enkele tegel uit dit portal is toegekend aan inlogger.

2) Medewerker a ziet meer of minder tegels dan medewerker b:

kan alleen indien aan medewerkers a andere tegels zijn toegekend dan aan medewerker b.

### Triggers

Klikken op tegel opent een vervolgscherm.

Indien niet klikbaar dan is de tegel ingesteld als disabled (zie [Portaldefinitie](/openwave/1.29/applicatiebeheer/instellen_inrichten/portaldefinitie)).

# Index

[Tegels onder kolom Brontabellen](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_brontabellen)

  * [Adressoorten](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_brontabellen/adressoorten)
  * [Adviescategorieën](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_brontabellen/adviescategorieen)
  * [Afhandeling/Besluit (omg/apv/bouw/milieu/gebruik)](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_brontabellen/afhandeling_besluit)
  * [Afhandeling handhaving](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_brontabellen/afhandeling_handhaving)
  * [Bestemtoetscriteria](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_brontabellen/bestemplantoetscriteria)
  * [Bezwaarcategorie](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_brontabellen/bezwaarcategorie)
  * [Documenttypen](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_brontabellen/documenttypen)
  * [Doelgroep](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_brontabellen/doelgroep)
  * [Eigendom &amp; Prijssegment](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_brontabellen/eigendom_prijssegment)
  * [GEO kaartlagen](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_brontabellen/geo-kaartlagen)
  * [Horeca aanvraagreden](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_brontabellen/horeca_aanvraagreden)
  * [Horeca aardbesluit](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_brontabellen/horeca_aard_besluit)
  * [Images](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_brontabellen/images)
  * [Inrichting/complexiteit](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_brontabellen/inrichting-complexiteit)
  * [Kadastrale gemeentes](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_brontabellen/kadastrale_gemeentes)
  * [Klanten (betalers)](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_brontabellen/klanten_betalers)
  * [LHS-matrix](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_brontabellen/lhs-matrix)
  * [Monumenten](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_brontabellen/monumenten)
  * [Nationaliteiten](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_brontabellen/nationaliteiten)
  * [PGS](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_brontabellen/pgs)
  * [Retour advies](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_brontabellen/retour_advies)
  * [Soort Bestuurlijke Maatregelen](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_brontabellen/soort_bestuurlijke_maatregelen)
  * [Type Bouwproductie](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_brontabellen/type_bouwproductie)
  * [Type Woningen](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_brontabellen/type_woningen)
  * [Uitspraak Bezwaar/Beroep](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_brontabellen/uitspraak_bezwaar_beroep)
  * [Urensoorten](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_brontabellen/urensoorten)
  * [Vertrouwelijkheidindicatie](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_brontabellen/vertrouwelijkheidindicatie)
  * [Welstandcommissies](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_brontabellen/welstandcommissies)
  * [Werkpaketten](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_brontabellen/werkpakketten)
  * [APV/Overig werkzaamheden](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_brontabellen/werkzaamheden_apv_overig)
  * [Milieu/gebruik werkz](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_brontabellen/werkzaamheden_milieu_gebruik)
  * [Zaakgroepen](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_brontabellen/zaakgroepen)
  * [Zaakstatussen](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_brontabellen/zaakstatussen)

