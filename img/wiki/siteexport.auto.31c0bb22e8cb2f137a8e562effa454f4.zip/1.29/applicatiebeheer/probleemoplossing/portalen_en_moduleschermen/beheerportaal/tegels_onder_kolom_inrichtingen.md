# Tegels onder kolom Inrichtingen

## Problemen

1) Het scherm ziet er raar uit (al of niet met een foutmelding) of reageert niet:

  * inlogger heeft geen kijkrechten
  * alle tegels zijn disabled of onzichtbaar op conditie (zie [Portaldefinitie](/openwave/1.29/applicatiebeheer/instellen_inrichten/portaldefinitie))
  * geen enkele tegel uit dit portal is toegekend aan inlogger.

2) Medewerker a ziet meer of minder tegels dan medewerker b:

kan alleen indien aan medewerkers a andere tegels zijn toegekend dan aan medewerker b.

### Triggers

Klikken op tegel opent een vervolgscherm.

Indien niet klikbaar dan is de tegel ingesteld als disabled (zie [Portaldefinitie](/openwave/1.29/applicatiebeheer/instellen_inrichten/portaldefinitie)).

## Index

  * [Tegels onder kolom Inrichtingen](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_inrichtingen)
    * [Asbesttoepassingen](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_inrichtingen/asbesttoepassingen)
    * [LHS / besturingsmodel](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_inrichtingen/besturingsmodel)
    * [BOR-coderingen](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_inrichtingen/bor-coderingen)
    * [Codering stoffen](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_inrichtingen/codering_stoffen)
    * [EBM-Type](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_inrichtingen/ebm_type)
    * [Emissiebeperkende voorz](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_inrichtingen/emissiebeperkende_voorz)
    * [Horecagebied](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_inrichtingen/horecagebied)
    * [Inrichting bedrijfeinde](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_inrichtingen/inrichting_bedrijfeinde)
    * [Inrichting bedrijfsoort](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_inrichtingen/inrichting_bedrijfsoort)
    * [Juridische indicatie](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_inrichtingen/juridische_indicatie)
    * [MBA-Activiteiten](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_inrichtingen/mba-activiteiten)
    * [Milieucirkels](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_inrichtingen/milieucirkels)
    * [Milieugebied](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_inrichtingen/milieugebied)
    * [Milieurubrieken](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_inrichtingen/milieurubrieken)
    * [Nalevingscoderingen; controle](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_inrichtingen/nalevingen)
    * [Rechtsvorm](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_inrichtingen/rechtsvorm)
    * [REV Afstanden](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_inrichtingen/rev_afstanden)
    * [REV BKL-activiteiten](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_inrichtingen/rev_bkl-activiteiten)
    * [REV EV contouren](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_inrichtingen/rev_ev_contouren)
    * [REV Json Mallen](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_inrichtingen/rev_json_mallen)
    * [REV Kwetsbare locaties gebouwen](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_inrichtingen/rev_kwetsbare_locaties_gebouwen)
    * [REV referentie EV contouren](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_inrichtingen/rev_referentie_ev_contouren)
    * [REV-waardenlijsten](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_inrichtingen/rev-waardenlijsten)
    * [SBI-coderingen](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_inrichtingen/sbi-coderingen)
    * [Sluitingstijden](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_inrichtingen/sluitingstijden)
    * [Soort certificaten](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_inrichtingen/soort_certificaten)
    * [Soort energieverbruik](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_inrichtingen/soort_energieverbruik)
    * [Typering act. besluit](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_inrichtingen/typering_act._besluit)

