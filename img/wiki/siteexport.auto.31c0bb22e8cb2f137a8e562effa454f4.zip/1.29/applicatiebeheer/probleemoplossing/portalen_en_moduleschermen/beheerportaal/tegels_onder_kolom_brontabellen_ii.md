# Tegels onder kolom Brontabellen II

## Problemen

1) Het scherm ziet er raar uit (al of niet met een foutmelding) of reageert niet:

  * inlogger heeft geen kijkrechten
  * alle tegels zijn disabled of onzichtbaar op conditie (zie [Portaldefinitie](/openwave/1.29/applicatiebeheer/instellen_inrichten/portaldefinitie))
  * geen enkele tegel uit dit portal is toegekend aan inlogger.

2) Medewerker a ziet meer of minder tegels dan medewerker b: 

kan alleen indien aan medewerkers a andere tegels zijn toegekend dan aan medewerker b.

### Triggers

Klikken op tegel opent een vervolgscherm. Indien niet klikbaar dan is de tegel ingesteld als disabled (zie [Portaldefinitie](/openwave/1.29/applicatiebeheer/instellen_inrichten/portaldefinitie)).

## Index

  * [Tegels onder kolom Brontabellen II](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_brontabellen_ii)
    * [Aanhoudingsgronden](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_brontabellen_ii/aanhoudingsgronden)
    * [Acties DSO Spec. Vraagid&#039;s](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_brontabellen_ii/acties_dso_spec_vraagid)
    * [Besluittypes](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_brontabellen_ii/besluittypes)
    * [Bestplancategorie](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_brontabellen_ii/bestemmingsplan_categorie)
    * [Documentfase](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_brontabellen_ii/documentfase)
    * [Dossierverblijf](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_brontabellen_ii/dossierverblijf)
    * [DSO Projecten](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_brontabellen_ii/dso_projecten)
    * [Gebouwdoelgebruik](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_brontabellen_ii/gebouwdoelgebruik)
    * [Gebouwgebruik](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_brontabellen_ii/gebouwgebruik)
    * [Gebouwtypes](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_brontabellen_ii/gebouwtypes)
    * [Horeca exploitatie](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_brontabellen_ii/horeca_exploitatie)
    * [Inspectie onderwerpen](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_brontabellen_ii/inspectie_onderwerpen)
    * [Inspectie resultaat](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_brontabellen_ii/inspectie_resultaat)
    * [Installaties](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_brontabellen_ii/installaties)
    * [Invorderingssoorten](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_brontabellen_ii/invorderingssoorten)
    * [Klachternst](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_brontabellen_ii/klacht_ernst)
    * [Klachtfrequentie](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_brontabellen_ii/klacht_frequentie)
    * [Klachtoverlast](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_brontabellen_ii/klacht_overlast)
    * [Klachtvorm](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_brontabellen_ii/klacht_vorm)
    * [OIN-nummers](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_brontabellen_ii/oin-nummers)
    * [Opschorten Verlengen](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_brontabellen_ii/opschorten_verlengen)
    * [Preparaties](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_brontabellen_ii/preparaties)
    * [Prognose categorieën](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_brontabellen_ii/prognose_categorie)
    * [ROEB BTW](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_brontabellen_ii/roeb_btw)
    * [ROEB Categorieën](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_brontabellen_ii/roeb_categoerieen)
    * [ROEB Staffel](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_brontabellen_ii/roeb_staffel)
    * [Soort Activiteit/Onderdeel](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_brontabellen_ii/soort_activiteit_onderdeel)
    * [Inspectie soort bezoek](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_brontabellen_ii/soort_bezoek)
    * [Soort Onderneming](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_brontabellen_ii/soort_onderneming)
    * [Speelautomaatcategorien](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_brontabellen_ii/speelautomaatcategorien)
    * [Tekstblokken](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_brontabellen_ii/tekstblokken)
    * [Welstandbeeldkwaliteitsplan](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_brontabellen_ii/welstandbeeldkwaliteitsplan)
    * [Welstandcriteria](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_brontabellen_ii/welstandcriteria)
    * [Wettelijke grondslagen](/openwave/1.29/applicatiebeheer/probleemoplossing/portalen_en_moduleschermen/beheerportaal/tegels_onder_kolom_brontabellen_ii/wettelijke_grondslagen)

