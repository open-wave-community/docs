# Rapportage als WMS-laag

[Rapportages](/openwave/1.29/applicatiebeheer/instellen_inrichten/rapportages) kunnen met behulp van een geïnstalleerde GeoServer ([http://geoserver.org/](http://geoserver.org/)) - voorzien van een REM-plugin - gepubliceerd worden als WMS_kaartlaag.

## Bijzonderheden van Rapportdefinitie

  * De kolom tbrapporten.dlwms moet de waarde T hebben.
  * De kolom tbrapporten.dvwms_epsg moet gevuld worden met het coördinatenstelselnummer waarin de coördinaten en vlakken worden doorgegeven. Vooralsnog alleen 28992 (rijksdriehoek).

In de resultset van een rapport worden de volgende kolomnamen als volgt geïnterpreteerd:

  * Kolomnaam: *dfwms_xcrd* = x-coördinaat van een punt (float)
  * Kolomnaam: *dfwms_ycrd* = y-coördinaat van een punt (float)
  * Kolomnaam: *dvwms_polygon* = multipoint dus polygoon (x1,y1 x2,y2 x3,y3 x1,y1)
  * kolomnaam: *dfwms_cirkel_xcrd* = x-coördinaat middelpunt van cirkel
  * kolomnaam: *dfwms_cirkel_ycrd* = y-coördinaat middelpunt van cirkel
  * Kolomnaam: *dfwms_radius* = straal van cirkel in METERS die om dfwms_cirkel_xcrd,dfwms_cirkel_ycrd wordt getrokken (float).

Een hyperlink naar een openwave deeplink-pagina kan bijvoorbeeld doorgeven worden als:

```sql
CAST('http://demo1.open-wave.nl/#inrichtingdetail/' | | dnkeymilinrichtingen as character varying(100)) AS dvurl
```

Doorklikken op die hyperlink opent het bijbehorende inrichtingsportal in OpenWave.

<adm warning>
In de rapportnaam mogen **geen spaties** voorkomen. Bij polygonen moet het eindpunt gelijk zijn aan het beginpunt. Een combinatie van polygonen, cirkels of punten in één rapportage wordt niet ondersteund: dus óf een rapport met punten, óf een rapport met vlakken, óf een rapport met cirkels. Bij combinaties gaat polygoon voor.
</adm>

### Voorbeeld

De volgende SQL geeft als resultaat de geurcirkels gebaseerd op - niet vervallen - SBI-coderingen (beheertegel *SBI-coderingen*) die een gevulde geurcirkelradius hebben EN als hoofdsbi gekoppeld zijn aan een niet-geblokkeerde inrichting, waarvan het locatie adres gevulde puntcoördinaten heeft.

```sql
select
    a.dvinrichtingnaam,
    a.dvobjadres,
    a.dvobjplaats,
    b.dnycoordinaat dfwms_cirkel_ycrd,
    b.dnxcoordinaat dfwms_cirkel_xcrd,
    d.dnafstgeur dfwms_radius,
    cast('http://demo1.open-wave.nl/#inrichtingdetail/' | | a.dnkeymilinrichtingen as character varying(100)) as dvurl 
    from vwfrmmilinrichtingen a
      inner join tbperceeladressen b
        on (a.dnkeyperceeladressen=b.dnkey and b.dnycoordinaat <> 0 and b.dnxcoordinaat > 0 and b.dnycoordinaat > 0)
      inner join vwfrmmilsbi c
        on(a.dnkeymilinrichtingen=c.dnkeymilinrichtingen and c.dlhoofdsbi = 'T')
      inner join tbmilcodesbi d
        on(d.dnkey=c.dnkeymilcodesbi and d.dnafstgeur is not null and d.dnafstgeur <> 0 and d.ddvervaldatum is null )
    where a.ddblokkering is null
```

### Publiceren als nieuwe laag in GeoServer

Open de startpagina van de geïnstalleerde GeoServer: 

```
http://IP_ADRES:POORT/geoserver/web
```

Log in met gebruikersnaam en wachtwoord

[<img src="../../../applicatiebeheer/instellen_inrichting/geoserver_kieslaag.w.400_tok.904ae9.png?w=400&tok=904ae9" class="media" loading="lazy" alt="" width="400" />](/_detail/openwave/applicatiebeheer/instellen_inrichting/geoserver_kieslaag.png?id=openwave%3A1.29%3Aapplicatiebeheer%3Ainstellen_inrichten%3Arapportage-publiceren_als_wms-laag)

Kies voor Lagen

[<img src="../../../applicatiebeheer/instellen_inrichting/geoserver_laagtoeveoegen.w.400_tok.f98b1a.png?w=400&tok=f98b1a" class="media" loading="lazy" alt="" width="400" />](/_detail/openwave/applicatiebeheer/instellen_inrichting/geoserver_laagtoeveoegen.png?id=openwave%3A1.29%3Aapplicatiebeheer%3Ainstellen_inrichten%3Arapportage-publiceren_als_wms-laag)

Kies voor Laag Toevoegen

[<img src="../../../applicatiebeheer/instellen_inrichting/geoserver_kiesbron.w.400_tok.55e41a.png?w=400&tok=55e41a" class="media" loading="lazy" alt="" width="400" />](/_detail/openwave/applicatiebeheer/instellen_inrichting/geoserver_kiesbron.png?id=openwave%3A1.29%3Aapplicatiebeheer%3Ainstellen_inrichten%3Arapportage-publiceren_als_wms-laag)

Kies de bron waaruit je de laag wilt toevoegen. Het is mogelijk dat hier maar 1 optie is. Bij de mogelijke bronnen moet een verwijzing zitten naar de OpenWave database waar de te publiceren rapportage in is gemaakt.

[<img src="../../../applicatiebeheer/instellen_inrichting/geoserver_publiceerlaag.w.500_tok.47351b.png?w=500&tok=47351b" class="media" loading="lazy" alt="" width="500" />](/_detail/openwave/applicatiebeheer/instellen_inrichting/geoserver_publiceerlaag.png?id=openwave%3A1.29%3Aapplicatiebeheer%3Ainstellen_inrichten%3Arapportage-publiceren_als_wms-laag)

Omdat voor *nieuwe laag* is gekozen gaat GeoServer uit de bron alle lagen opnieuw ophalen. In de getoonde lijst met lagen zijn dan weer alle rapportages uit OpenWave opgenomen (met hun OpenWave-rapportnaam) die aan alle bovenvermelde criteria voldoen. Het gaat om de nog niet gepubliceerde rapportages. Kies het gewenste rapport en kies de actie *publiceren* op de rechterkant van de betreffende regel.

In het formulier **Laag Wijzigen** dat nu getoond wordt hoeven alleen de begrenzingsparameters te worden gevuld.
Scroll naar beneden.

[<img src="../../../applicatiebeheer/instellen_inrichting/geoserver_begrenzingen.w.500_tok.b8afeb.png?w=500&tok=b8afeb" class="media" loading="lazy" alt="" width="500" />](/_detail/openwave/applicatiebeheer/instellen_inrichting/geoserver_begrenzingen.png?id=openwave%3A1.29%3Aapplicatiebeheer%3Ainstellen_inrichten%3Arapportage-publiceren_als_wms-laag)

De waarden van de begrenzingsrechthoeken vul je handmatig als volgt:
Begrenzingsrechthoek van de bron:

  * x-min: 0
  * y-min: 300
  * x-max: 300
  * y-max: 630

Begrenzingsrechthoek in WGS84:

  * x-min: 3.37
  * y-min: 50.75
  * x-max: 7.21
  * y-max: 53.47

N.B. Maak dus geen gebruik van de opties *Berekenen op basis van de gegevens* en *Berekenen op basis van de bronprojectie*. Klik onderaan de pagina op *Opslaan* en de rapportagelaag is gepubliceerd.

### Gewijzigd rapport opnieuw publiceren

De meest verstandige manier is om in GeoServer wederom voor lagen te kiezen en aldaar het bestaande rapport te verwijderen. Vervolgens de procedure als hierboven uitvoeren om het gewijzigde rapport opnieuw te publiceren.

### GeoServer gepubliceerde OpenWave rapportage als laag op interne kaarten

Daarvoor moeten de laag opgenomen worden in de beheertegel: *Geo kaartlagen* (tbgeowms).
De service-URL moet achterhaald worden en de kaartlaagnaam.

Open de startpagina van de geïnstalleerde GeoServer : 

```
http://IP_ADRES:POORT/geoserver/web
```

Neem de installatienaam over:

[<img src="../../../applicatiebeheer/instellen_inrichting/geoserver_installatienaam.w.400_tok.e905f6.png?w=400&tok=e905f6" class="media" loading="lazy" alt="" width="400" />](/_detail/openwave/applicatiebeheer/instellen_inrichting/geoserver_installatienaam.png?id=openwave%3A1.29%3Aapplicatiebeheer%3Ainstellen_inrichten%3Arapportage-publiceren_als_wms-laag)

In bovenstaand voorbeeld is dat dus *OpenWave*.

Om de juiste service-URL te krijgen moet de volgende string worden geconstrueerd: 

```
http://IP_ADRES:POORT/geoserver/INSTALLATIENAAM/ows?SERVICE=WMS
```

Nu nog de kaartlaagnaam

Construeer de volgende URL en plak deze in de browser adresbalk.

```
http://IP_ADRES:POORT/geoserver/INSTALLATIENAAM/ows?SERVICE=WMS&request=getCapabilities
```

Het resultaat is een xml met alle nodige kaartlaaginformatie.

Voor de kaartlaagnaam zoek je in deze xml naar <layer> met de eigenschap *queriable=1*, tag <Name>. In onderstaand voorbeeld: 
`<Name>SBIGeur</Name>`. Er kunnen meerdere lagen zijn, dus even zoeken naar de goede.

[<img src="../../../applicatiebeheer/instellen_inrichting/geoserver_kaartlaagnaam.w.600_tok.c866aa.png?w=600&tok=c866aa" class="media" loading="lazy" alt="" width="600" />](/_detail/openwave/applicatiebeheer/instellen_inrichting/geoserver_kaartlaagnaam.png?id=openwave%3A1.29%3Aapplicatiebeheer%3Ainstellen_inrichten%3Arapportage-publiceren_als_wms-laag)

