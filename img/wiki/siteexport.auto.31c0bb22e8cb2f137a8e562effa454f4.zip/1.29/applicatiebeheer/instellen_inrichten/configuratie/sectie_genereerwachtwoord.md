# Sectie GenereerWachtwoord

Hieronder de instellingen uit de [configuratietabel](/openwave/1.29/applicatiebeheer/instellen_inrichten/configuratie) (tbinitialisatie) van de *Sectie: GenereerWachtwoord* gerangschikt op item.

## Items Configuratietabel

| Item | Kolom | Omschrijving |
|---|---|---|
| Afzender | Tekst |Hier geeft u de afzender op van de activeringscode-email voor de wachtwoord vergeten functionaliteit. Dit moet een valide email zijn, bijvoorbeeld: *noreply@openwave.nl*. |

