# Sectie Koppeling OLO

Hieronder de instellingen uit de [configuratietabel](/openwave/1.29/applicatiebeheer/instellen_inrichten/configuratie) (tbinitialisatie) van de *Sectie: koppeling OLO* gerangschikt op item. Indien de itemnaam uit twee regels bestaat dan is dat vanwege de leesbaarheid. In de werkelijkheid in de databasetabel staan de twee regels aan elkaar in de kolom dvitem van tbinitialisatie.

## Items Configuratietabel

| Item | Kolom | Omschrijving |
|---|---|---|
| Aanmaakmappen | Aanvinkvakje |Indien aangevinkt zal de OLO-verwerkingservice proberen op de fileshare (!) mappen aan te maken conform de instellingen van kolom *Tekst* bij *Sectie: Aanmaakmappen* waarbij *Item* begint met *Omgeving_* of *MilGebr_*. De automatisch aan te maken mappen zullen in ieder geval gedefinieerd moeten zijn als UNC-paden en de OLO-service moet hiertoe rechten hebben. Het gaat om de mappen zonder de variabelen  `%inspnr%` ,  `%adviesnr%`  en `%bezwaarnr%`. Let op: indien gebruik gemaakt wordt van de AIM tool, dan kan deze instelling NIET aanstaan. |
|AanmakenZaak metZaak/dms| Aanvinkvakje |Indien aangevinkt zal de OLO-service ook een StUF Zaak/DMS creerZaakbericht sturen naar het externe zaaksysteem (mits aan een aantal voorwaarden is voldaan: zie lemma *OLO-verwerking*. |
| AltijdPostadres | Aanvinkvakje |Indien aangevinkt en het correspondentieadres van een initiator of gemachtigde bij natuurlijkpersoon of vestiging is NIET opgenomen in het bericht, dan worden de verblijfsadresgegevens uit het OLO-bericht - naast overname in het blok vestiging - ook overgenomen in het blok postadres van de contactpersoon. |
|BestaandContact NietOverschrijven| Aanvinkvakje |Indien aangevinkt heeft dat tot consequentie dat wanneer tijdens het inlezen van de aanvrager of gemachtigde het programma tot de conclusie komt dat deze reeds bestaat als contactadres in OpenWave, er alleen een koppeling plaatsvindt met de nieuwe vergunningsaanvraag zonder dat daarbij de bestaande contactadresgegevens worden overschreven. |
|BestaandeZaak NietOverschrijven| Aanvinkvakje |Indien aangevinkt heeft dat tot consequentie dan wanneer een OLO-bericht wordt verwerkt met een OLO-aanvraagnummer dat al bestaat in OpenWave de gegevens van die bestaande zaak NIET worden overschreven. De (verwijzingen naar) bijlages van het OLO-bericht worden wel opgenomen in de tabel nagekomen OLO-berichten in zoverre deze nog niet bestonden (er wordt gematched op de tag bestandsnaam). |
| BestandenNaarFileserver | Aanvinkvakje |Indien aangevinkt en in hybride situatie dat documenten zowel op fileserver als in een DMS kunnen staan, zullen OLO en DSO bijlages automatisch op de fileserver worden geplaatst. Indien deze instelling niet bestaat of is uitgevinkt dan dus in het DMS. |
| BerichtGoedVerwerktMap | Tekst |Deprecated. Het UNC-pad waarop de succesvol verwerkte OLO-berichten worden geplaatst. **Let op**: de OLO-service moet schrijfrechten hebben op deze map. Deze functie is door Messagelog overbodig geworden. |
|BerichtNiet GoedVerwerktMap| Tekst |Deprecated. Het UNC-pad waarop de NIET succesvol verwerkte OLO-berichten worden geplaatst. **Let op**: de OLO-service moet schrijfrechten hebben op deze map. Deze functie is door Messagelog overbodig geworden. |
| BerichtOnbekendMap | Tekst |Deprecated. Het UNC-pad waarop de onbekende -berichten die naar de OLO-service zijn gestuurd worden geplaatst. **Let op**: de OLO-service moet schrijfrechten hebben op deze map. Deze functie is door Messagelog overbodig geworden. |
|BerichtWordt NietOndersteundMap| Tekst |Deprecated. Het UNC-pad waarop de OLO-berichten die OpenWave niet ondersteund worden geplaatst. **Let op**: de OLO-service moet schrijfrechten hebben op deze map. Deze functie is door Messagelog overbodig geworden. |
| Charset | Tekst |De ingevuld waarde verschijnt bovenaan in de uitgaande xml van het koppelvraagaanzaak-bericht. Bijv. de waarde utf-8 is dan zichtbaar in *`<?xml version="1.0" encoding="utf-8"?>`*. |
| CheckOpDubbeleDocumentnaam | Aanvinkvakje |Indien aangevinkt zal OpenWave bij het plaatsen van OLO en of DSO-bijlages - indien deze automatisch worden geregistreerd - een extra check op het bestaat van de bijlagenaam in de kolom dvdocfilenaam van tbcorrespondentie. Bestaat deze al dan wordt de bijlage niet geplaatst, maar wordt wel een extra regel aangemaakt in tbbadextupload (mislukte OLO/DSO-bijlages). |
| |Getal1| Indien de waarde <> 1 dan gaat OpenWave er vanuit dat bij DSO documenten de eerste 20 posities worden ingenomen door het OIN-nummer. In verband met complexe vergunningen wordt dit OIN-nummer dan genegeerd bij de check op dubbele namen.|
| Dossierbehandelaar | Tekst |Hierin moet een valide medewerkerscode (tbmedewerkers.dvcode) staan, **Let op**: case-sensitive, waarop de service kan terugvallen indien bij het zaaktype geen default behandelaar is opgegeven. |
| DummyLokatiePerceelkey | Getal2 |verwijst naar een dnkey van tabel locaties (tbperceeladressen) met de betekenis onbekend adres (gevuld met bijvoorbeeld Onbekende Plaats, Onbekende Straat, Huisnummer 0 of 9999). |
| EndpointClassMedewerker | Tekst |Indien de OLO-service een zaak moet doorsturen naar het externe zaak/DMS wordt hier het endpoint van de autorisatie OpenWave API (getAuthorisation) verwacht: dit moet zijn: <WRAP prewrap 500px>
```
http://IP-ADRES:POORT/services/nl.rem.openwave.published.Medewerker.nl.rem.openwave.published.MedewerkerHttpSoap12Endpoint/
```

</WRAP> 
|
| EndpointClassWizard | Tekst |Indien de OLO-service een zaak moet doorsturen naar het externe zaak/DMS wordt hier het endpoint van de de betreffende OpenWave API (maakZaakinZaaksysteem) verwacht: dit moet zijn <WRAP prewrap 500px>
```
http://IP-ADRES:POORT/services/nl.rem.openwave.published.Wizard.nl.rem.openwave.published.WizardHttpSoap12Endpoint/
```

</WRAP> 
|
| ExtAdviesOnbekend | Getal1 |verwijst naar een een dnkey van tabel zaaktypes omgeving (TbSoortOmgverg) waaronder de OLO-berichten van type omvDu01LeverenAanvraag met de tag aanvraagprocedure anders dan regulier of uitgebreid moeten worden geplaatst. Indien de instelling niet bestaat dan worden deze adviesaanvragen onder de verplichte OW zaaktype voor geen-procedure-van-toepassing geplaatst. |
| ExtAdviesRegulier | Getal1 |verwijst naar een een dnkey van tabel zaaktypes omgeving TbSoortOmgverg waaronder de OLO-berichten van type omvDu01LeverenAanvraag met de tag aanvraagprocedure *Reguliere procedure* geplaatst moeten worden. Indien de instelling niet bestaat dan worden deze adviesaanvragen onder de verplichte OW zaaktype voor de reguliere procedure geplaatst. |
| ExtAdviesUitgebreid | Getal1 |verwijst naar een een dnkey van tabel zaaktypes omgeving (TbSoortOmgverg) waaronder de OLO-berichten van type omvDu01LeverenAanvraag met de tag aanvraagprocedure *Uitgebreide procedure* geplaatst moeten worden. Indien de instelling niet bestaat dan worden deze adviesaanvragen onder de verplichte OW zaaktype voor de uitgebreide procedure geplaatst. |
|FTP-messagelog| Aanvinkvakje |Indien aangevinkt worden de aanroepen naar de FTPS-site voor ophalen ontbrekende OLO-documenten EN aanroepen voor ophalen documenten uit DSO (verzoeken), gelogd in tbmessagelog (mits de algemene instelling *Sectie: OWB en Item: messagelog* ook is aangevinkt). |
|FTPS-site| Tekst |password (gecrypt) van toegang tot OLO-ftps-site. |
| | Info |Loginnaam voor toegang tot ftps-site. |
| | Toelichting |endpoint van ftps-site. OpenWave zal voor deze credentials overigens eerst kijken naar de ingestelde waarden in tabel tb33gemeente |
| | Getal1 |poortnummer. |
|GeregistreerdAlsNaar ZaaknrBevGezag| Aanvinkvakje |Indien aangevinkt, dan wordt de tag identificatie uit het OLO-bericht van blok *StaatGeregistreerdAls* opgeslagen in de OpenWave-kolom dvzaaknrbevgezag i.p.v. dvintzaakcode (zaaknr extern zaak/DMS). |
|HTTPSoapAction_vrgDi01 KoppelZaakAanAanvraag| Tekst |De soapaction nodig bij uitgaande bericht. Vullen met *vrgDi01KoppelZaakAanAanvraag*. |
|KoppelZaakAan AanvraagBericht| Aanvinkvakje |Indien aangevinkt dan zal OpenWave na ontvangst van een aanvraag, waarbij een nieuwe zak in OpenWave is aangemaakt, een zogenaamd vrgDi01KoppelZaakAanAanvraag bericht naar het endpoint genoemd in kolom *Tekst* van *Sectie: Koppeling OLO Item: Ontvangstadres_Asynchroon*. |
| LeverenAanvraagDatumReset | Aanvinkvakje | Indien aangevinkt en het gaat om de verwerking van de berichtsoorten *OmvDu01LeverenAanvraag en wwvDu01LeverenAanvraag*, dan zal de startdatum (tbomgvergunning.ddaanvraag) worden gevuld met de systeemdatum i.p.v. de aanvraagdatum uit het bericht. |
|LokatieHuisletter CaseSensitive| Aanvinkvakje |Indien NIET aangevinkt betekent dit dat bij het inlezen van het locatie adres uit het OLO-bericht de huisletter niet case-sensitive is. Dat wil zeggen dat een aanvraag voor bijvoorbeeld Acacialaan 1 b gekoppeld kan worden aan het locatie adres Acacialaan 1 b of aan 1 B. De default instelling is aangevinkt!!!! dus wel onderscheid. |
| MeerdereAdviesaanvragen | Aanvinkvakje |Indien aangevinkt ontstaan bij de berichtsoorten *omvDu01LeverenAanvraag of wwvDu01LeverenAanvraag* meerdere zaken in OpenWave wanneer de berichten doublure-waardes hebben in de tag <aanvraagnummer>(OLO/DSO nummer in OpenWave). Zaken in OpenWave worden in dat geval automatisch voorzien van een postfix (bijv. _1  of _2) om de waarde in de kolom dvlvoaanvraagnr uniek te houden. |
| MeldingenOpvangen | Aanvinkvakje |Indien aangevinkt dan worden OLO-berichten met de procedure *Geen procedure van toepassing* of *Onbekend* geplaatst op de OpenWave zaaktypes Sloopmelding of Gebruikmelding, Lozingsmelding of Activiteitenmelding. Indien deze instelling niet aangevinkt is dan worden deze OLO-berichten geplaatst op de onbekende OLO-vergunning. |
| MeldingOnderdeelActiviteit | Getal2 |verwijst naar een dnkey van tabel zaaktypes omgeving (TbSoortOmgverg) waaronder de activiteitenmeldingen geplaatst worden. OpenWave beschouwt een OLO-bericht als een activiteitenmelding indien *MeldingenOpvangen* aangevinkt is EN het bericht een onderdeel <onderdeelActiviteitenMelding> bevat. |
| MeldingOnderdeelGebruik | Getal2 |verwijst naar een dnkey van tabel zaaktypes omgeving (TbSoortOmgverg) waaronder de gebruiksmeldingen geplaatst worden. OpenWave beschouwt een OLO-bericht als een gebruiksmelding indien *MeldingenOpvangen* aangevinkt is EN het bericht een onderdeel <onderdeelGebruik> bevat. |
| MeldingOnderdeelLozing | Getal2 |verwijst naar een dnkey van tabel zaaktypes omgeving (TbSoortOmgverg) waaronder de lozingsmeldingen geplaatst worden. OpenWave beschouwt een OLO-bericht als een lozingsmelding indien *MeldingenOpvangen* aangevinkt is EN het bericht een onderdeel <onderdeelMeldingLozingOpDeBodemOfDeRioleringBuitenInrichtingen> bevat. |
|MeldingOnderdeel MeldingActiviteit| Getal2 |verwijst naar de dnkey van tabel zaaktypes milieu/gebruik (TbSoortMilverg) waaraan de activiteitenmelding AIM moet worden gekoppeld. Een van *MeldingOnderdeelMeldingActiviteit* of *MeldingOnderdeelMeldingActiviteit_O* moet bestaan. |
|MeldingOnderdeel MeldingActiviteit_O| Getal2 |verwijst naar de dnkey van tabel zaaktypes omgeving (TbSoortOmgverg) waaraan de activiteitenmelding AIM moet worden gekoppeld. |
| MeldingOnderdeelSlopen | Getal2 |verwijst naar een dnkey van tabel zaaktypes omgeving (TbSoortOmgverg) waaronder de sloopmeldingen geplaatst worden. OpenWave beschouwt een OLO-bericht als een sloopmelding indien *MeldingenOpvangen* aangevinkt is EN het bericht een onderdeel <onderdeelSlopen> bevat. |
| Methode | Tekst |de kolom *Tekst* moet de waarde *StUF-LVO 311* hebben en aangevinkt zijn. De service verwerkt met deze instelling zowel StUF-LVO 311 als StUF-LVO 312 berichten. |
| | Aanvinkvakje |Indien aangevinkt dan verwerkt de DUSK Open-Waveservice inkomende OLO-berichten. |
|Olonrdatumbij afsluitenextzaak| Aanvinkvakje |Indien aangevinkt en een gevulde einddatum wordt meegestuurd bij een Omgevingszaak met een OLO-nummer met een StUF zaak/DMS actualiseerStatus-bericht dan wordt aan het OLO-nummer (kolom dvlvoaanvraagnr van tbomgvergunning) een datum string met format '-jjjjmmdd' toegevoegd (dus als OLO-nummer is 123456 en de datum is 24 feb 2017 dan wordt dat 123456-20170224). Dit betekent dat een tweede adviesaanvraag (soms half jaar later) op hetzelfde OLO-nummer dan als nieuwe zaak wordt beschouwd door OpenWave. |
|Onbekende Activiteit| Getal2 |verwijst naar een dnkey van beheertabel activiteitsoorten (tbsrtToestemming) met de betekenis onbekende OLO-activiteit. |
| OnbekendeInrichting | Getal2 |verwijst naar de dnkey van de inrichting (tbmilinrichtingen) waaraan een AIM-milieuactiviteitenmelding moet worden gekoppeld wanneer het programma niet in staat is een bekende inrichting uit tbmilinrichtingen te kiezen op grond van de berichtgegevens. Deze instelling is alleen nodig indien de de AIM-meldingen in de tabel tbMilvergunningen moeten worden geplaatst. |
|Onbekende vergunning| Getal2 |verwijst naar een dnkey van beheertabel zaaktypes omgeving (TbSoortOmgverg). Deze verwijzing wordt gebruikt indien OLO-bericht een niet nader te plaatsen soort procedure geeft of facultatieve instellingen ontbreken. De OpenWave naam van dit zaaktype kan bijvoorbeeld Onbekende OLO_vergunning zijn. |
| Ontvanger_Applicatie | Tekst |Stuurgegeven voor uitgaande bericht vrgDi01KoppelZaakAanAanvraag. |
| Ontvanger_Organisatie | Tekst |Stuurgegeven voor uitgaande bericht vrgDi01KoppelZaakAanAanvraag. |
|Ontvangstadres_ Asynchroon| Tekst |Het endpoint waar het vrgDi01KoppelZaakAanAanvraag bericht naar toe moet inden de instelling *KoppelZaakAanAanvraagBericht* aangevinkt is. |
|Puntjesfunctie Voorletters| Aanvinkvakje |Indien aangevinkt is dan zal het programma alvorens de kolom voorletters bij een contactpersoon te vullen zo nodig de afzonderlijke tekens scheiden met een punt. |
| Versienummer | Tekst | De Dusk-service die inkomende OLO-berichten verwerkt zet hier zelf bij een databasecontact het versienummer neer van Wv_Olo_Document_311.dll. |
| savebericht | Aanvinkvakje |Indien aangevinkt dan worden de inkomende OLO-berichten als file gelogd op een map op de server waar de Dusk-OLO-service draait. Deze mapnaam staat in een configuratiefile naast de Berichtenservice (dusk.ini). Sectie: [Log] en Item: MapSaveBericht. De namen van de files die hier komen te staan worden door de service zelf gegenereerd (bijvoorbeeld Bericht_Van_Olo_Naar_Dusk_140602150536.xml.

 Voor het definiëren van de map zijn systeembeheerrechten op de server waar de OLO-service draait nodig. |
| Vooroverleg | Tekst |Indien gevuld met een tekst waarvan de lengte kleiner of gelijk 5 is zal het OLO-nummer bij een vooroverlegkaart in OpenWave (dvlvoaanvraagnr) worden opgeslagen met deze tekst als prefix. |
| | Getal1 |Indien de waarde 1 dan wordt de dvaanvraagnaam bij vooroverleg gevuld met de waarde van de tag toelichting (mits gevuld) en anders (dus geen toelichting of Getal1 <> 1) dan met de vaste tekst *Aanvragen Vooroverleg*. |
| | Getal2 |verwijst naar een dnkey van beheertabel zaaktypes omgeving (TbSoortOmgverg) die de betekenis vooroverleg heeft. |
| | Aanvinkvakje | Indien aangevinkt zullen documenten ook geplaatst kunnen worden bij een vooroverleg met prefixnummer. |
| Waterwet | Getal2 |Indien gevuld dan verwijst deze waarde naar een dnkey van tbsoortomgverg (zaaktypes omgeving) waar nieuwe zaken op grond van de OLO–berichtsoorten wwvDi01AanbiedenAanvraag en wwvDu01LeverenAanvraag aan gekoppeld worden. |
|Woonplaatsnaam *| Tekst |Op de plaats van de asterisk in de itemnaam de afwijkende schrijfwijze van de plaatsnaam  in het OLO bericht t.o.v. BAG. Bijvoorbeeld *Woonplaatsnaam Ede (GLD)*. In de kolom *Tekst* moet vervolgens de juiste schrijfwijze van de woonplaatsnaam komen te staan, zoals *Ede*, zoals deze staat in de Wave-tabel tbwoonplaats (zie Locatie), waarin de BAG-schrijfwijze zou moeten staan. |
| Zender_Organisatie | Tekst |Stuurgegeven voor uitgaande bericht vrgDi01KoppelZaakAanAanvraag. |

