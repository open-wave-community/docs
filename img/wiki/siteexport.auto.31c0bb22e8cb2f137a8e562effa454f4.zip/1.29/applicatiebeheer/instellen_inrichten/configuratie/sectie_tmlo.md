# Sectie TMLO

Hieronder de instellingen uit de [configuratietabel](/openwave/1.29/applicatiebeheer/instellen_inrichten/configuratie) (tbinitialisatie) van de *Sectie: TMLO* gerangschikt op item.

## Items Configuratietabel

| Item | Kolom | Omschrijving | |
|---|---|---|---|
| Handaving | Aanvinkvakje |Indien aangevinkt is het blok *TMLO* in het detailscherm van de Handhaving zichtbaar. | |
| Horeca | Aanvinkvakje |Indien aangevinkt is het blok *TMLO* in het detailscherm van de Horeca zichtbaar. | |
| Omgeving | Aanvinkvakje |Indien aangevinkt is het blok *TMLO* in het detailscherm van de Omgevingszaak zichtbaar. | |
|APV/Overig| Aanvinkvakje |Indien aangevinkt is het blok *TMLO* in het detailscherm van de APV-Overige zaak zichtbaar. | |
| Info | Aanvinkvakje |Indien aangevinkt is het blok *TMLO* in het detailscherm van de Info zaak zichtbaar. | |
| Bouwsloop | Aanvinkvakje |Indien aangevinkt is het blok *TMLO* in het detailscherm van de Bouw/sloop zaak zichtbaar. | |
| MilieuGebruik | Aanvinkvakje |Indien aangevinkt is het blok *TMLO* in het detailscherm van de Bouw/sloop zaak zichtbaar. | |

