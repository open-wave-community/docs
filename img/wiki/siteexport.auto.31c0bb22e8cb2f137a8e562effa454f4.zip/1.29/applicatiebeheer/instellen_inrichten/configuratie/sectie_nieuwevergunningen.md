# Sectie NieuweVergunningen

Hieronder de instellingen uit de [configuratietabel](/openwave/1.29/applicatiebeheer/instellen_inrichten/configuratie) (tbinitialisatie) van de *Sectie: NieuweVergunningen* gerangschikt op item.

## Items Configuratietabel

| Item | Kolom | Omschrijving |
|---|---|---|
|Milieu-inrichtingen| Getal2 | De lengte van het automatische ophoogdeel van een nieuw inrichtingnummer. |
| | Tekst| Het vaste deel van een nieuw inrichtingnummer. |

