# Sectie Gebruikersinformatie

Hieronder de instellingen uit de [configuratietabel](/openwave/1.29/applicatiebeheer/instellen_inrichten/configuratie) (tbinitialisatie) van de *Sectie: Gebruikersinformatie* gerangschikt op item.

## Items Configuratietabel

| Item | Kolom | Omschrijving |
|---|---|---|
| AantalDagenOpslaan | Getal1 |Indien *Sectie: preinlog en Item: GebruikersinformatieOpslaan* aangevinkt is, dan worden bij het inloggen device en browsergegevens van de inlogger opgeslagen in de tabel tbgebruikersinformatie (zie Service centrum onder tegel *Gebruikersstatistieken*). Deze informatie wordt default 90 dagen bewaard tenzij anders vermeld in deze instelling. |

