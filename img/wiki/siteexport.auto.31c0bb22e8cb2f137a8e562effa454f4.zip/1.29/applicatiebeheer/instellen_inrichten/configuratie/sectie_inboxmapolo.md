# Sectie InboxmapOLO

Hieronder de instellingen uit de [configuratietabel](/openwave/1.29/applicatiebeheer/instellen_inrichten/configuratie) (tbinitialisatie) van de *Sectie: InboxmapOLO* gerangschikt op item. Zie [MessageLog](/openwave/1.29/applicatiebeheer/instellen_inrichten/messagelog).

## Items Configuratietabel

| Item | Kolom | Omschrijving |
|---|---|---|
| Messagelog | Aanvinkvakje |Indien aangevinkt dan wordt het uploadfile bericht waarmee een OLO-bijlage van de fileserver naar de OpenWave server wordt verplaatst (en daarna via StUF voegzaakdocument naar het DMS) opgenomen in de beheertabel tbmessagelog mits de instelling *Sectie: OWB en Item: MessageLog* ook aangevinkt is. Zie ook instelling *Sectie: KoppelingDOCNAARDMS Item: inboxmapOLO* |

