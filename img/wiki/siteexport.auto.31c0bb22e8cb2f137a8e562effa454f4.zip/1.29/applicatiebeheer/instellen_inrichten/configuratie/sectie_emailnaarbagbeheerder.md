# Sectie EmailNaarBagBeheerder

Hieronder de instellingen uit de configuratietabel (tbinitialisatie) van de *Sectie: EmailNaarBagBeheerder* gerangschikt op item. Zie [Email naar BAG beheerder](/openwave/1.29/applicatiebeheer/probleemoplossing/programmablokken/email_bag-beheerder).

## Items Configuratietabel

| Item | Kolom | Omschrijving |
|---|---|---|
| Calamiteitenmelding | Getal2 |De dnkey van de soort omgevingszaak (portaal *Zaakbeheer*, tegel *Zaaktypes omgeving*) die staat voor een calamiteitenmelding, indien het de bedoeling is dat de inlogger de knop *emailnaarbagbeheerder* kan gebruiken bij een calamiteitenzaak (zie voor overige voorwaarden bij de triggers op het detailscherm van de omgevingszaak). |

