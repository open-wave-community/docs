# Sectie Leges

Hieronder de instellingen uit de [configuratietabel](/openwave/1.29/applicatiebeheer/instellen_inrichten/configuratie) (tbinitialisatie) van de *Sectie: Leges* gerangschikt op item. Zie [Leges](/openwave/1.29/applicatiebeheer/probleemoplossing/module_overstijgende_schermen/leges?s[]=leges).

## Items Configuratietabel

| Item | Kolom | Omschrijving |
|---|---|---|
| DagenTerug_OpenLegesLijst | Getal2 |Geeft aantal dagen terug dat de view vwfrmopenlegesregels maximaal terugkijkt naar de kolom ddlegesverzonden (mag verzonden worden vanaf). |
| OmgLegesHandmMetWizardRegels | Aanvinkvakje |Indien aangevinkt dan zal het programma bij een omgevingszaak de extra informatie bij de legessoort zoals *is legessoort bedoeld voor teruggave-bedrag bij intrekking* of *is legessoort voor korting vanwege digitale indiening*, gebruiken. Zie lemma *legesberekening*. |

