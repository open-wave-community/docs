# Sectie Vernietigen

Hieronder de instellingen uit de [configuratietabel](/openwave/1.29/applicatiebeheer/instellen_inrichten/configuratie) (tbinitialisatie) van de *Sectie: Vernietigen* gerangschikt op item.

## Items Configuratietabel

| Item | Kolom | Omschrijving |
|---|---|---|
| AlleenDocumentenGeenZaken | Aanvinkvakje |Indien aangevinkt dan worden bij de uitvoering van de vernietigingslijst alleen de documenten verwijderd en niet de zaken zelf. |
| AlleenGeblokkeerde | Aanvinkvakje |Indien aangevinkt worden bij het samenstellen van de vernietigingslijst alleen geblokkeerde zaken (dus zaken met een gevulde blokkeerdatum) meegenomen. |

