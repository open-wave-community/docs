# Sectie Koppeling BRP

Hieronder de instellingen uit de [configuratietabel](/openwave/1.29/applicatiebeheer/instellen_inrichten/configuratie) (tbinitialisatie) van de *Sectie: KoppelingBRP* gerangschikt op item.
Zie [BRP (GBA) bevraging](/openwave/1.29/applicatiebeheer/probleemoplossing/programmablokken/bpr_bevraging).

## Items Configuratietabel

| Item | Kolom | Omschrijving |
|---|---|---|
| AllowAllHostnameVerifier | Aanvinkvakje |Indien aangevinkt is zal de Openwave Cloud instemmen met een self-signed of verlopen (server)certificaat bij een verbinding onder https. |
| HTTPSoapActionStelGbavVraag | Tekst |Soapaction voor vraag-bericht Competent. Moet zijn: *stelGbavVraag*. |
| Messagelog | Aanvinkvakje |Indien aangevinkt worden de uitgaande Competent vraagberichten gelogd in de beheertabel tbmessagelog indien ook de algemene instelling *Sectie: OWB en Item: Messagelog* is aangevinkt. |

