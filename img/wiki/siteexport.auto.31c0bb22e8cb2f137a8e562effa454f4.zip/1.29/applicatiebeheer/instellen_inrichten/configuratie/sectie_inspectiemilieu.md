# Sectie InspectieMilieu

Hieronder de instellingen uit de [configuratietabel](/openwave/1.29/applicatiebeheer/instellen_inrichten/configuratie) (tbinitialisatie) van de *Sectie: InspectieMilieu* gerangschikt op item.

## Items Configuratietabel

| Item | Kolom | Omschrijving |
|---|---|---|
| NietBlokkerenMetHoofdzaak | Aanvinkvakje |Indien aangevinkt dan wordt de inspectietrajectkaart (en overtredingen en bezoeken) niet mee-geblokkeerd tegen wijzigingen indien de bovenliggende zaak of inrichting wel is geblokkeerd (ddblokkering). Echter indien aangevinkt maar de afgerond datum van de inspectietrajectkaart (ddcontrole) is gevuld, dan worden alsnog de onderliggende inspectiebezoeken en overtredingen geblokkeerd. |
| Rechtengroepen | Tekst |Hier kunnen - gescheiden door puntkomma's' de dnkeys van de rechtengroepen (tbrechten) opgesomd worden die bedoeld zijn voor de inspecteurs. Bijvoorbeeld 1;13;210;340; Is dit het geval dan laat de dropdownlist bij inspecties alleen medewerkers zien die lid zijn van deze groepen. |

