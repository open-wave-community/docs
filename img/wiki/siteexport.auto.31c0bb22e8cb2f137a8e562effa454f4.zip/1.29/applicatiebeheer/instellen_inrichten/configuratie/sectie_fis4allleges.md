# Sectie Fis4AllLeges

Hieronder de instellingen uit de configuratietabel (tbinitialisatie) van de *Sectie: Fis4AllLeges* gerangschikt op item. Voor al deze items geldt dat deze per gemeente aan te maken zijn door achter de *Sectie: Fis4AllLeges* het gemeenteid te zetten; Fis4AllLeges_gemeenteid. **Let op:** alleen van belang indien de export per gemeente wordt gedraaid. Zie voor meer uitleg: [ Fis export](/openwave/1.29/applicatiebeheer/probleemoplossing/programmablokken/financiele_export).

## Items Configuratietabel

| Item | Kolom | Omschrijving | |
|---|---|---|---|
| BTWcode | Tekst| De BTW code die in het exportbestand dient te worden opgenomen wordt hier ingevuld. Mag maximaal 2 karakters lang zijn. | |
| BedrijfsFCLcode | Tekst| De FCL bedrijfscode die in het exportbestand dient te worden doorgegeven kan hier worden ingevuld. Mag maximaal twee karakters lang zijn. | |
| BedrijfsIdInExport | Aanvinkvakje| Indien aangevinkt dan zal in het exportbestand het KvK-nummer en vestigingsnummer van de debiteur worden opgenomen (mits de debiteur een bedrijf is). | |
| Bedrijfscode | Tekst| De bedrijfscode die in het exportbestand dient te worden doorgegeven kan hier worden ingevuld. Mag maximaal twee karakters lang zijn. | |
| ContactId | Aanvinkvakje| Indien aangevinkt dan zal het unieke id van het debiteurencontact opgenomen worden in het exportbestand. | |
| Controle | Tekst| Verplicht gevuld en altijd waarde A of D. Waarde D: dan geen debiteurgegevens in het exportbestand (m.u.v. debiteurnummer). Waarde A: dan worden de volgende debiteurgegevens aan het exportbestand toegevoegd; debiteurnaam, debiteuradres, bedrijfsnaam, postcode, woonplaats en BSN-nummer. | |
| | Getal2 | Indien 1 EN *Tekst* is A dan worden 10 extra debiteurgegevens opgenomen in het exportbestand: debiteurstraat, debiteurhuisnummer, debiteurhuisletter, debiteurhuisnummertoevoeging, debiteurvoorletters, debiteurvoorvoegsel, debiteurachternaam, debiteurgeslacht, debiteurpostcodecijfer en debiteurpostcodeletter. | |
| DMSNummerInExport | Aanvinkvakje| Indien aangevinkt dan zal in het exportbestand het DMS zaaknummer van de bovenliggende zaak van de te exporteren legesregel worden opgenomen (mits deze gevuld is). | |
| DatumAcceptGiroVerzondenInExport | Aanvinkvakje| Geeft aan met welke waarde kolom *Datum* gevuld wordt in het exportbestand. AAN betekent verzenddatum acceptgiro (ddlegesverzonden) van de bovenliggende zaak van de legesregel, UIT betekent de ontvangstdatum. | |
| DatumFormaat | Tekst| Hier kan een alternatieve datumformaat worden opgegeven. Bijvoorbeeld jjjjmmdd: de waardes in kolom *Datum* in het exportbestand zullen dan het formaat jjjjmmdd aangevuld tot tien posities krijgen (bijvoorbeeld: '20210505  '). | |
| ECL | Tekst| Waarde van de kolom ECL in het exportbestand. Wordt met voorloopnullen aangevuld in het exportbestand tot lengte: zie *Getal2*. | |
| | Getal2 | Een alternatieve lengte voor de ECL code kan hier worden opgegeven. Default is de lengte 5. | |
| ExportDatumKeuze | Aanvinkvakje| Indien aangevinkt dan kan de gebruiker zelf de exportdatum datum bepalen bij het definitief exporteren van de legesregels. Deze datum is default gevuld met de datum van vandaag. | |
| ExportPerGemeente | Aanvinkvakje| Indien aangevinkt dan zal bij het opstellen van de legesexportlijst een gemeente gekozen moeten worden. De financiële export wordt dan dus per gemeente geregeld. | |
| Kredietbeheerder | Tekst| Waarde van de kolom *Kredietbeheerder* in het exportbestand. Lengte is altijd 5. | |
| LegesSoortInTabel | Aanvinkvakje| Indien aangevinkt dan zal het programma de te exporteren legesregels NIET samenvoegen. Indien LegesSoortInTabel UIT, dan worden de te exporteren legesregels WEL samengevoegd. | |
| | Tekst | Indien WEL samenvoegen (LegesSoortInTabel is uit) dan haalt het programma de waarde voor kolom *FCL nummer* en kolom *Taak* hier op. De waarde voor *FCL nummer* en *Taak* worden in kolom *Tekst* gescheiden met een '-' teken: stel waarde FCL is 87222234 en waarde Taak is 12345 dan zal de waarde van kolom *Tekst* zijn: 87222234-12345. | |
| LengteFCL | Getal2| Alternatieve lengte voor kolom *FCL nummer* kan hier worden opgegeven (default 8). Indien de waarde van FCL nummer qua lengte afwijkt aan de opgegeven lengte dan zal het programma het FCL nummer aanvullen met voorloopnullen, respectievelijk afkappen tot opgegeven lengte. | |
| LengteTaak | Getal2| Alternatieve lengte voor kolom *Taak* kan hier worden opgegeven (default 5). Indien de waarde van Taak qua lengte afwijkt aan de opgegeven lengte dan zal het programma Taak aanvullen met voorloopnullen, respectievelijk afkappen tot opgegeven lengte. | |
| NotaNummerisKey | Aanvinkvakje| Indien aangevinkt dan zal bij het opstellen van de legesexportlijst voor de legeregels waarvan het notanummer nog NIET gevuld is, het notanummer gevuld worden met de dnkey van de bovenliggende zaak. Staat de instelling UIT dan wordt het notanummer gevuld met de wavezaakcode. | |
| | Getal2 | Alternatieve lengte voor het notanummer in het exportbestand (default lengte  9). Moet minimaal 9 en maximaal 20 zijn. Indien hier vanaf geweken wordt dan zal het programma het notanummer aanvullen met voorloopnullen tot lengte 9, respectievelijk afkappen tot lengte 20. | |
| Notasoort | Tekst| De waarde voor kolom *Notasoort* in het exportbestand wordt hier opgegeven. Mag maximaal drie tekens lang zijn. Wordt eventueel aangevuld met voorloopnullen tot lengte 3. Geldt default voor alle modules en altijd voor omgevings- en bouw/sloop zaken. Indien 1 (of meer) van onderstaande overige notasoort-instellingen bestaat, zal het programma naar de notasoort-instelling kijken voor die aangegeven modules. | |
| Notasoort_horeca | Tekst| Hier kan een aparte notasoort voor horecavergunningen worden opgegeven. Mag maximaal drie tekens lang zijn. Wordt eventueel aangevuld met voorloopnullen tot lengte 3. Indien deze niet bestaat valt het programma terug op de reguliere notasoort instelling. | |
| Notasoort_apv | Tekst| Hier kan een aparte notasoort voor APV-vergunningen worden opgegeven. Mag maximaal drie tekens lang zijn. Wordt eventueel aangevuld met voorloopnullen tot lengte 3. Indien deze niet bestaat valt het programma terug op de reguliere notasoort instelling. | |
| Notasoort_info | Tekst| Hier kan een aparte notasoort voor infoaanvragen worden opgegeven. Mag maximaal drie tekens lang zijn. Wordt eventueel aangevuld met voorloopnullen tot lengte 3. Indien deze niet bestaat valt het programma terug op de reguliere notasoort instelling. | |
| NulBedragenNietInExport | Aanvinkvakje| Indien aangevinkt dan zullen de legesregels met bedrag is 0 niet opgenomen worden in het exportbestand. Indien definitieve export dan wel vullen van de exportdatum voor de legesregels met nul bedragen. | |
| VoorlettersZonderPuntjes | Aanvinkvakje| Indien aangevinkt dan zal in het exportbestand voor de waardes in kolom Debiteurvoorletter de punten tussen de voorletters weggelaten worden. Voorbeeld: stel dvdebiteurvoorl heeft waarde 'A.L.T' dan zal in het exportbestand komen te staan 'ALT'. | |

