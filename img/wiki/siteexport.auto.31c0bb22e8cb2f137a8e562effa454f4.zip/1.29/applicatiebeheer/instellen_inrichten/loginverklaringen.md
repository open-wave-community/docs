# Loginverklaringen

Portaal beheerportaal-Nieuw. Tegel *Loginverklaringen*.

API(s):

  * getStandardList: [https://api.open-wave.nl/RemMethods/getRemMethod/415/](https://api.open-wave.nl/RemMethods/getRemMethod/415/)
  * getStandardDetail: [https://api.open-wave.nl/RemMethods/getRemMethod/416](https://api.open-wave.nl/RemMethods/getRemMethod/416)

Screenidentifiers: MDLC_getTbLoginverklaringenList.xml en MDDC_getTbLoginverklaringenDetail.xml.

In deze tabel kunnen één of meer verklaringen worden opgenomen, die de gebruikers bij het inloggen zullen moeten aanvinken. Wanneer de gebruiker een verklaring heeft afgevinkt wordt de datum opgeslagen in de tabel tbmwloginverklaringen. In het detailscherm van de medewerkerstabel is vervolgens zichtbaar in de blokken *Afgevinkte (tbmwloginverklaringen)* en *Niet-afgevinkte loginverklaringen* welke verklaringen de gebruiker heeft aangevinkt en welke nog niet.

Een voorbeeld van zo'n verklaring:

[<img src="../../../applicatiebeheer/instellen_inrichten/configuratie/login_plain.w.600_tok.78f73c.png?w=600&tok=78f73c" class="media" loading="lazy" alt="" width="600" />](/_detail/openwave/applicatiebeheer/instellen_inrichten/configuratie/login_plain.png?id=openwave%3A1.29%3Aapplicatiebeheer%3Ainstellen_inrichten%3Aloginverklaringen)

U heeft de volgende kolommen om een verklaring op te stellen:

  * **Volgorde**. Indien er meerdere verklaringen actief zijn, dan kan hiermee de volgorde worden bepaald zoals de inlogger deze te zien krijgt.
  * **Ingangsdatum**. Indien gevuld, dan zal de verklaring pas na deze datum getoond worden aan de inloggers (in zoverre deze nog niet is afgevinkt).
  * **Vervaldatum**. Indien gevuld dan zal de verklaring tot aan deze datum getoond worden aan de inloggers (in zoverre deze nog niet is afgevinkt).
  * **Header van tekstvak**. In bovenstaand voorbeeld: AVG.
  * **Label bij aanvinkvakje**. In bovenstaand voorbeeld: Zal je de AVG respecteren.
  * **Aantal dagen waarna de verklaring opnieuw afgevinkt dient te worden**. Indien groter dan 0 dan zal de verklaring om het hier ingevoerde aantal dagen opnieuw moeten worden afgevinkt. In de tabel tbmwloginverklaringen wordt de laatste datum van afvinken elke keer overschreven.
  * **Tekst**. Hier kan de getoonde verklaring worden ingetikt in plain tekst al of niet verrijkt met html-opmaak. Indien dit laatste het geval is, kan bijvoorbeeld een hyperlink naar een browserpagina worden opgenomen. 
  * **Opmaak in html-codering**. Indien aangevinkt gaat het programma er van uit dat de tekst verrijkt kan zijn met html-coderingen. U kunt de opmaakcodes gebruiken die normaal alleen in het blok <body> van een HTML-pagina worden gebruikt. Dus de tekst moet NIET beginnen met type declaration <!DOCTYPE html> en hoeft ook NIET ingepakt te worden in `<html></html>` en <body></body>.

Hieronder een voorbeeld daarvan:

[<img src="../../../applicatiebeheer/instellen_inrichten/configuratie/login_html.w.600_tok.e9b955.png?w=600&tok=e9b955" class="media" loading="lazy" alt="" width="600" />](/_detail/openwave/applicatiebeheer/instellen_inrichten/configuratie/login_html.png?id=openwave%3A1.29%3Aapplicatiebeheer%3Ainstellen_inrichten%3Aloginverklaringen)

De html-tekst in het blok Tekst ziet er voor bovenstaand voorbeeld als volgt uit:

	<h1>Dit is een titel</h1><br>
	<br>
	Deze verklaring is in html opgemaakt,<br>
	U kunt de html-opmaak code gebruiken die u normaal alleen <b><a style="background-color:Yellow;">BINNEN</a></b> de body van een html-document gebruikt.<br>
	Dus deze tekst moet <a style="background-color:Yellow;">NIET</a> beginnen met type declaration:  <code class="w3-codespan">&lt;!DOCTYPE   html&gt;</code>   <br>
	en hoeft ook <a style="background-color:Yellow;">NIET</a> ingepakt te worden in <code class="w3-codespan">&lt;html&gt;</code> en <code class="w3-  codespan">&lt;body&gt;</code><br>
	<br>
	<b>dit is bijvoorbeeld vet</b> <br>
	<p style="color:DodgerBlue;">En deze paragraafregel is in blauw.</p><br>
	Dit is weer gewoon.<br>
	<a href="https://www.w3schools.com/html/" target="_blank">Als u op deze regel klikt kunt u verder lezen over html-opmaak</a><br>
	Zie zo.<br>
	<br>
	Dit is dit de op twee na voorlaatste regel en <br>
	en<br>
	dan<br>
	is dit is de voorlaatste<br>
	en dit dus de laatste.
In de medewerkerstabel kunt u per medewerker het aanvinkvakje: *Deze medewerker hoeft geen loginverklaringen af te vinken* aanvinken. Indien aangevinkt hoeft de medewerker geen loginverklaringen af te vinken. Handig indien de medewerker een robot is.

Wanneer een verklaring verwijderd wordt, dan wordt de historie van wanneer welke medewerker deze verklaring heeft afgevinkt (tbmwloginverklaringen) ook automatisch verwijderd.

Zie ook kopje *afvinken loginverklaringen* bij het lemma [Inloggen](/openwave/1.29/applicatiebeheer/probleemoplossing/programmablokken/inloggen).

