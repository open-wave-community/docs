# Scherminformatie voor lijstschermen en (dus ook) rapportages

De plaats en inhoud van de kolommen van een lijst worden geregeld in het text-veld dvscreenxml van tbscreencolumns met een xml-opmaak.

Of er in een lijst gemuteerd kan worden is naast het genoemde bij onderstaande tags ook afhankelijk van een eigenschap edit van het scherm zelf. Deze laatste eigenschap wordt enerzijds gebaseerd op de rechten en anderzijds op de noodzakelijkheid om in een lijst te muteren. Dat wordt geregeld in de API.

Binnen de root-tag `<document>` worden evenzoveel blokken <column> gedefinieerd als er kolommen moeten zijn in het lijstscherm.
Hieronder een voorbeeld van een lijst bestaande uit twee kolommen.
De volgorde waarop deze kolommen getoond worden van links naar rechts in de lijst is de volgorde van de blokken <column> van boven naar beneden (de tag <index> is nu nog betekenisloos, maar is op den duur bepalend voor de volgorde).

```xml
<?xml version="1.0" encoding="UTF-8"?>
  <document>
    <!--aangeroepen vanuit api getStandardList-->
    <!--tagnaam slaat op een kolom uit tbpreparaties-->
    <column tagnaam="dnkey">
        <label>Prim. key</label>
        <index>20</index>
        <length>100</length>
        <wavetype>integer</wavetype>
    </column>
    <column tagnaam="dvpreparatie">
        <label>Preparatie</label>
        <index>20</index>
        <length>300</length>
        <wavetype>string</wavetype>
    </column>
  </document>
```

## Verplichte tags/attributen

Hierboven staan precies de verplichte attributen en tags benoemd - en in de juiste volgorde - voor elk blok <column>.
De tag *wavetype* is eigenlijk bepalend voor hoe de overige tags worden geïnterpreteerd.

Elke <column> heeft een:

  * attribuut **tagnaam**. De waarde van de tagnaam is een kolomnaam uit de view of tabel of rapport dat aan het scherm ten grondslag ligt.
  * tag **<label>** geeft het label voor de betreffende kolom in de lijst. De waarde mag leeg zijn. Indien gevuld dan kan het uiteindelijke beeld van de lijst verstoord worden als de labeltekst langer is dan het aantal pixels van de tag <length>. Daarbij reserveert het programma zelf nog plusminus 15 pixels in de kolom om de sorteervolgorde aan te kunnen geven.
  * tag **<index>**. Wordt niet gebruikt, maar moet wel gevuld worden met een integer.
  * tag **<length>** geeft de breedte van de kolom in pixels. Moet groter dan 0 zijn. Let op dat de lengte in pixels van <label> kleiner is dan deze waarde.
  * tag **<wavetype>** zegt iets over de functie en type van de kolom in de view/tabel of rapport. De tag moet gevuld zijn met één van volgende waarden:
    * **string**. Betekent dat de kolom in de view/tabel/rapport een normaal karakterveld bevat. Indien het lijstscherm editable is EN de tag <fieldname> is gevuld en de tag <edit> heeft de waarde true, dan kan de kolom gewijzigd worden.
    * **integer**. Betekent dat de kolom een geheel getal bevat. Indien het lijstscherm editable is EN de tag <fieldname> is gevuld en de tag <edit> heeft de waarde true, dan kan de kolom gewijzigd worden.
    * **float**. Betekent dat de kolom een rationeel getal bevat. Indien het lijstscherm editable is EN de tag <fieldname> is gevuld en de tag <edit> heeft de waarde true, dan kan de kolom gewijzigd worden.
    * **datum**. Betekent dat de kolom een datum bevat die wordt getoond als dd-mm-yyyy. Indien het lijstscherm editable is EN de tag <fieldname> is gevuld en de tag <edit> heeft de waarde true, dan kan de datum gewijzigd worden met een datepicker. 
    * **icoon**. Er zijn drie mogelijkheden:
      * indien de kolom een lege waarde heeft, dan wordt er niets afgedrukt
      * indien gevulde waarde EN attribuut *tagnaam* begint met 'dl' (de waarde zou een boolean T of F moeten zijn) dan:
              * indien die waarde = F dan wordt er niets afgedrukt
              * indien die waarde <> F dan wordt het icoon afgedrukt met het nummer uit de [iconenlijst](/openwave/1.29/applicatiebeheer/instellen_inrichten/schermdefinitie/iconenlijst) dat vermeld staat in de tag `<icoon>` (zie ook hieronder bij facultatieve tags: icoon en source). Indien echter die tag `<icoon>` de waarde 999 heeft of leeg is, dan is het gewenste icoonnummer de waarde van de kolom zelf. 
      * indien gevulde waarde EN attribuut *tagnaam* begint NIET met 'dl' dan wordt het icoon afgedrukt met het nummer uit de iconenlijst dat vermeld staat in de tag `<icoon>` (zie hieronder bij niet verplichte tags). Ook hier geldt dat indien die tag `<icoon>` de waarde 999 heeft of leeg is, dan is het gewenste icoonnummer de waarde van de kolom zelf. 
    * **kleurbol**. Betekent dat de kolom een string bevat met één van de volgende waarden: rood, wit, groen of oranje. Het programma drukt deze af als kleine icoonbolletjes (respectievelijk: 33, 30, 31 en 32 uit de iconenlijst). Indien andere waarde dan wordt er niets in de kolom afgedrukt. 

De kleurbol kan ook als icoontje worden getoond indien de instelling *sectie: OWB en Item Waarschuwingsicoon* aangevinkt is en *Getal1* de waarde 1 of 2 heeft. 
    * **boolean**. Betekent dat de kolom een waarde T of F bevat. Indien T dan wordt de kolom getoond als ingevuld aanvinkvakje en anders als leeg aanvinkvakje. Indien de kolom een lege waarde bevat wordt GEEN aanvinkvakje getoond. Indien het lijstscherm editable is EN de tag <fieldname> is gevuld en de tag <edit> heeft de waarde true, dan kan de kolom gewijzigd worden.
    * **boolean+**. Betekent dat de kolom een waarde T of F of N bevat. Indien T dan wordt de kolom getoond als ingevuld aanvinkvakje en indien F als leeg aanvinkvakje en indien N als vraagteken.
    * **boolean10** Betekent dat de kolom een waarde 1 of 0 bevat (karakterveld). Gedraagt zich gelijk aan boolean.
    * **picture** Wordt niet gebruikt. Is voor speciale toepassingen. 
    * **keuzelijst**. Betekent dat de kolom een dropdownlijst bevat. Voor het gebruik van de dropdownlijst moet het lijstscherm zelf editable zijn. Verder moet de tag <fieldname> gevuld zijn en de tag <edit> moet de waarde true hebben. De tag <source> verwijst naar een vast geprogrammeerde dropdownlijst.
    * **radiobutton**. Werkt hetzelfde als keuzelijst behalve dat het dropdownlijstje als NAAST elkaar staande radiobuttons wordt getoond.
    * **schermknop**. Betekent dat het element wordt afgedrukt als een in te drukken knop waaraan een actie is verbonden. Er is geen verwijzing naar een tagnaam. Of de knop enabled is, is afhankelijk van de waarde van de tag <edit> en het editable zijn van het scherm, behalve indien de tag <filter> de waarde *enable* heeft, dan is de schermknop altijd enabled ook als het scherm zelf niet in de editmodus staat. De tag <source> is leeg of bevat een integer-waarde waarmee in de API een icoon en actie zijn toegekend aan de knop. Indien de tag <source> leeg is dan moet de tag `<icoon>` een waarde uit de [Iconenlijst](/openwave/1.29/applicatiebeheer/instellen_inrichten/schermdefinitie/iconenlijst) bevatten en moet de tag `<action>` gevuld zijn met een actie. Zie voorbeeld onderaan deze pagina.  
    * **timefloat**. Betekent dat de kolom een float bevat die door de programmatuur dan getoond wordt als tijd. Default - de float is kleiner dan 100 - worden de decimalen omgezet in minuten en het gedeelte voor de decimaal als uren (HH:MM). Voor gewenste afwijkingen hierop kijkt het programma naar de tag <pattern>.
    * **datetime**. Geeft een database timestamp-field weer als een string *dd-mm-yyyy hh:mm:ss*. Ook invoer moet exact volgens dit masker.
    * **amountfloat**. Geeft een database veld integer of float weer in bedragvorm, bijvoorbeeld float waarde *23444,99* wordt getoond als *23.444,99* en integer waarde *87345* word getoond als *87.345,00*. De invoer moet voor een integer veld nog steeds een waarde zijn **zonder** decimalen (het is immers een integer), invoer voor float velden blijft zoals men gewend is maar men kan ook een punt gebruiken om duizendtal aan te geven.

## Facultatieve tags

Naast bovenstaande verplichte tags per kolom is er ook nog een aantal niet verplichte tags mogelijk. Sommige daarvan zijn verbonden aan een wavetype (en dan worden zij natuurlijk wel geacht aanwezig te zijn). Hieronder de opsomming in de juiste volgorde.

```xml
<column tagnaam="dftimefloat">
        <label>Tijdstip</label>/
        <index>50</index> 
        <length>100</length>
        <wavetype>timefloat</wavetype>
        <icoon/>
        <showhint>false</showhint>
        <edit></edit>
        <refresh/>
        <fieldname></fieldname>
        <source></source>
        <filter></filter>
        <align>R</align>
        <sortable>false</sortable>
        <pattern>^(\d{1,2}(:|,|\.){1}\d{1,2})$</pattern>
        <textpattern>Alleen 1 of 2 cijfers dan een dubbele punt, komma of punt en dan wederom 1 of twee cijfers</pattern> 
        <visible>true</visible>
        <refreshregel>true</refreshregel>
    </column>
```

  * tag **`<icoon>`**. Als op de kolom een plaatje afgedrukt moet worden dan moet de bijbehorende wavetype de waarde 'icoon' hebben (zie hierboven). De waarde van de tag `<icoon>` verwijst - indien deze anders is dan 999 en niet leeg - rechtstreeks naar een icoonnummer uit de [iconenlijst](/openwave/1.29/applicatiebeheer/instellen_inrichten/schermdefinitie/iconenlijst). Alleen wanneer de tag `<icoon>` de waarde 999 heeft of leeg is  dan wordt het icoonlijstnummer uit de kolomwaarde zelf gehaald. Zie ook nog even de uitzondering indien tag <source> de waarde 'extern' heeft.
  * tag **<showhint>**. Kan de waarde true of false hebben. Indien dit attribuut niet bestaat dat is de defaultwaarde false. Indien true dan wordt bij een hover op de kolom de volledige inhoud als hint zichtbaar. Wordt gebruikt indien tag <length> van element met <wavetype> string te klein is om de hele inhoud weer te geven.
  * tag **<edit>**. Kan de waarde true of false (defaultwaarde is false) hebben. Of een kolom muteerbaar is in het lijstscherm hangt op de eerste plaats af van een scherm-eigenschap editable. Die moet true zijn (en kan daarnaast afhankelijk zijn van de rechten van de inlogger). Daarnaast moet deze tag <edit> op kolomniveau de waarde true hebben EN de tag <fieldname> moet gevuld zijn EN de tag <wavetype> mag alleen de waardes: boolean, keuzelijst, radiobutton, integer, float, string of datum bevatten.
  * tag **<refresh>**. Kan de waarde true of false (defaultwaarde is false) hebben. Indien true dan wordt de gehele lijst opnieuw uitgeschreven indien de kolom gemuteerd wordt.
  * tag **<fieldname>** kan gevuld worden met een kolomnaam uit de tabel die uiteindelijk ten grondslag ligt aan de lijst. Indien een view als basis voor de lijst wordt gebruikt, gaat het hier om de (hoofd)tabel die weer ten grondslag ligt aan die view. De tag <fieldname> hoeft alleen gevuld te worden indien de tag <edit> de waarde true heeft. Het programma weet zo in welke database-veld de gewijzigde waarde opgeslagen moet worden.
  * tag **<source>**. Kan op vier manieren worden gebruikt in een lijst:
    * Indien <wavetype> de waarde *keuzelijst of radiobutton* heeft dan verwijst de waarde van de tag <source>:
      * naar een vast geprogrammeerde dropdownlijst
      * of naar een dropdownlijst op basis van zelf gedefinieerde query in tag <filter>. In dit laatste geval heeft de tag <source>: 
              * ofwel de waarde 'GeneralWithoutEmptyLine'
              * dan wel de waarde 'GeneralWithEmptyLine'. In dit geval zal het programma zelf een lege regel aan de result set van de query in <filter> toevoegen, zodat de gebruiker een waarde leeg kan maken. De breedte van het native dropdown-element wordt bepaald door het breedste item..
    * Indien wavetype de waarde *icoon* heeft dan kan de waarde van de tag gevuld worden met 'extern'. Dat heeft als betekenis dat het icoonnummer uit de tag `<icoon>` niet uit de interne iconenlijst komt, maar uit een externe - maat gesneden - lijst van plaatjes. De waarde van de tag `<icoon>` verwijst in dat geval naar het naamdeel van een opgeslagen plaatje met extensie .jpg of .png op de webserver.
    * Indien <wavetype> = *schermknop* dan kan hier een getal staan die verwijst naar een stukje interne programmatuur. Normaal gesproken is de tag <source> leeg bij een schermknop. Indien <source> leeg is dan wordt de schermknop gedefinieerd door de tags `<action>`, `<hint>` en `<icoon>`.
  * tag **<filter>** kan een query bevatten indien <wavetype> = *keuzelijst of radiobutton* EN <source> = 'GeneralWithoutEmptyLine' of 'GeneralWithoutEmptyLine'. De eerste kolom van die result set moet 'id' heten en de tweede kolom 'omschrijving'. Bijvoorbeeld: select dnkey id, dvname omschrijving from tbportalcolumns where dnkeyportalnames = (select dnkeyportalnames from vwfrmportaltiles where dnkey = {id}). De id-waarde is de kolom die overgenomen wordt bij een keuze uit de dropdownlijst. De variabele {id} wordt door het programma vervangen met de primary key van de basistabel die aan de regel ten grondslag ligt. De variabele %module% - indien mogelijk - met de moduleletter.
  * tag **<align>**. Kan de waarde L of R hebben. Links (default) of Rechts. 
  * tag **<sortable>**. Kan de waarde true of false hebben. True is de default waarde en betekent dat de gebruiker op het kolomlabel kan klikken waarna de lijst ASC of DESC gesorteerd wordt op die kolom.
  * tag **<pattern>** kan gevuld zijn met een reguliere expressie om invoer in een editbox te reguleren. Van toepassing op wavetypes string en timefloat. Voorbeeld van een pattern = `^(\d{1,2}(:|,|\.){1}\d{1,2})$ ` om uren:minuten in te voeren (HH:MM). Voor mogelijkheden van pattern zie [http://www.w3schools.com/jsref/jsref_obj_regexp.asp](http://www.w3schools.com/jsref/jsref_obj_regexp.asp) en een prettige tester is [https://www.regextester.com/](https://www.regextester.com/). 
  * tag **`<action>`**. Vooralsnog alleen van toepassing indien <wavetype> = schermknop EN tag <source> is leeg. Een action kan opgebouwd worden met behulp van een query: zie kopje *Queries voor contextafhankelijke scherm-attributen* onder [Queries](/openwave/1.29/applicatiebeheer/instellen_inrichten/queries). Zie verder over het gebruik en mogelijkheden van actions: [Actions](/openwave/1.29/applicatiebeheer/instellen_inrichten/actions). Zie ook het voorbeeld onderaan deze pagina.
  * tag **<textpattern>** de boodschap die getoond moet worden bij een invoer die niet aan het pattern voldoet.
  * tag **<visible>**. True of false. Indien false wordt de kolom NIET opgenomen in het scherm. Kan ook gevuld zijn met een aanroep naar een evalueerbare query die true of false oplevert.
  * tag **<refreshregel>**. Kan de waarde true of false (default waarde is false) hebben. Indien true dan wordt alleen de regel opnieuw uitgeschreven indien de kolom gemuteerd wordt.
  * tag **<exceltype>** kan gebruikt worden om wavetype string toch als Getal in Excel te laten verschijnen. De waarde van Excel type moet dan float of integer zijn. De kolom moet dan wel een numerieke waarde hebben in OpenWave.  
  * tag **<excelformat>** kan gebruikt worden om een waarde in het gewenste formaat weer te geven in Excel. Welke waardes hier mogelijk zijn wordt dus door Excel gedicteerd. Bijvoorbeeld de waarde #,#0.00 zal ervoor zorgen dat een float met een komma als decimaalscheiding (met twee decimalen) en een punt voor duizendtallen wordt weergegeven.  
  * tag **<celvisible>**. Kan de waarde true of false hebben. Bij false wordt de kolom voor de betreffende cel NIET uitgeschreven. Kan via een query-aanroep deze waarde verkrijgen. De query wordt voor de betreffende kolom voor elke regel opnieuw geëvalueerd. Is dus vertragend. 

## Extra kopregel(s)

```xml
<?xml version="1.0" encoding="UTF-8"?>
  <document>
	<list_header_options>
		<extra_column_header>
			<!--extra_column_header kan 0 of meer keren voorkomen-->
			<column_header collspan="1" index="1"></column_header>
			<column_header collspan="3" index="2">maandag</column_header>
			<column_header collspan="3" index="3">dinsdag</column_header>
		</extra_column_header>
	</list_header_options>
	<column tagnaam="dvclientfullname" >
		<label>Cliënt</label>
		<index>1</index>
		<length>150</length>
		<wavetype>string</wavetype>
		<icoon/>
		<showhint>false</showhint>
	</column>
	<column tagnaam="dnma1">
		<label>O</label>
		<index>10</index>
		<length>22</length>
		<wavetype>boolean10</wavetype>
		<icoon/>
		<showhint>false</showhint>
		<edit>true</edit>
		<sortable>false</sortable>
	</column>
	<column tagnaam="dnma2">
		<label>M</label>
		<index>11</index>
		<length>22</length>
		<wavetype>boolean10</wavetype>
		<icoon/>
		<showhint>false</showhint>
		<edit>true</edit>
		<sortable>false</sortable>
	</column>
	<column tagnaam="dnma3" >
		<label>A</label>
		<index>12</index>
		<length>22</length>
		<wavetype>boolean10</wavetype>
		<icoon/>
		<showhint>false</showhint>
		<edit>true</edit>
		<sortable>false</sortable>
	</column>
	<column tagnaam="dndi1" >
		<label>O</label>
		<index>20</index>
		<length>22</length>
		<wavetype>boolean10</wavetype>
		<icoon/>
		<showhint>false</showhint>
		<edit>true</edit>
		<sortable>false</sortable>
	</column>
	<column tagnaam="dndi2">
		<label>M</label>
		<index>21</index>
		<length>22</length>
		<wavetype>boolean10</wavetype>
		<icoon/>
		<showhint>false</showhint>
		<edit>true</edit>
		<sortable>false</sortable>
	</column>
	<column tagnaam="dndi3" >
		<label>A</label>
		<index>22</index>
		<length>22</length>
		<wavetype>boolean10</wavetype>
		<icoon/>
		<showhint>false</showhint>
		<edit>true</edit>
		<sortable>false</sortable>
	</column>
  </document>
```

[<img src="../../../../applicatiebeheer/instellen_inrichten/schermdefinitie/extrakopregel.w.400_tok.a516ec.png?w=400&tok=a516ec" class="media" loading="lazy" alt="" width="400" />](/_detail/openwave/applicatiebeheer/instellen_inrichten/schermdefinitie/extrakopregel.png?id=openwave%3A1.29%3Aapplicatiebeheer%3Ainstellen_inrichten%3Aschermdefinitie%3Ascherminformatie_voor_lijstschermen_en_rapportages)

Een tweede of derde kopregel kan worden toegevoegd om, zoals in bovenstaand voorbeeld, de kolommen O, M en A te groeperen onder het label maandag en dinsdag. Aan het begin van de xml moet daartoe het blok <list_header_options> worden opgenomen en daarbinnen één of meer keer het blok <extra_column_header>.

Binnen het blok <extra_column_header> zijn er, naast de waarde met het labelopschrift, voor elk label twee attributen te vullen:

  * Attribuut collspan geeft het aantal columns van de normale header aan die het extra label gaat overspannen.
  * Attribuut index de volgorde.

### Regels met totalen in lijstschermen

In de lijstschermen  van de leges, de stallen en staldelen en die van de uren is onderaan een regel  opgenomen met totalen. 
Deze zijn gebaseerd op een flexibel gegevensblok <list_totals> in de schermkolomdefinities van deze lijstschermen. De API’s die het scherm van de legeslijst en de urenlijsten oproepen ondersteunen deze nieuwe functionaliteit.

In alle schermen die aangeroepen worden vanuit de standaardtabel-definities (beheertegel *Tabellen standaardapi*) wordt deze nieuwe functionaliteit ook ondersteund. Hieronder een aantal voorbeelden van de definitie van de totaalregel gebaseerd op de view vwfrmlegesregels.

Bovenaan de schermkolomdefinitie moet het blok <list_totals> worden opgenomen (maar onder het blok <list_header_options> indien van toepassing). Daarbinnen in het blok <rijen> worden vervolgens één of meer rijen opgesomd. Elke rij kan de volgende attributen bevatten:

  * index = deze bepaalt de volgorde van de rij indien er meerdere rijen aanwezig zijn. Bijvoorbeeld "1"of "2"
  * position = "bottom" of "top".  De totalen regel kan dus boven- of onderaan de pagina worden afgedrukt
  * font-weight = betreft de dikte van de tekst. Daarbij is er de keuze tussen “bold” en “normal”
  * color =  "red" of "black" et cetera.   

Binnen de rij kunnen één of meer tags worden opgenomen die verwijzen naar een kolom in de onderliggende view of tabel van het lijstscherm. Elke tag kan weer attributen bevatten:

  * functie: de manier waarop de optelling plaats moet vinden. Het resultaat wordt in dezelfde kolom getoond, maar dan in de optellingsrij
  * query: extra limitering van de optelling
  * hint: een hint bij de optelling 
  * wavetype: het type data van de optelling. 

Voorbeeld:

```xml
<list_totals>
        <rijen>
            <rij index="0" position="bottom" font-weight="bold">
                <dvlgrsoortleges functie="'aantal legesregels: ' | | count(*)" ></dvlgrsoortleges>
                <dvlegesbedrag functie="sum(vwfrmlegesregels.dnlgrbedrag)”></dvlegesbedrag>
            </rij>
        </rijen>
    </list_totals>
```

De regel *<dvlgrsoortleges functie="'aantal legesregels: ' | | count(*)" ></dvlgrsoortleges>* betekent dat in de totalenregel onder de kolom dvlgrsoortleges de vaste tekst 'aantal legesregels: ' wordt afgedrukt gevolgd door de uitkomst van de functie *count(*)*. Dus het aantal rijen van de lijst, zoals die zich voordoet aan de gebruiker waarbij eventuele paging wordt genegeerd, maar andere restricties zoals filter of zoek wel worden meegewogen.

De regel *<dvlegesbedrag functie="sum(vwfrmlegesregels.dnlgrbedrag)” > </dvlegesbedrag>* betekent dat in de totalenregel onder de kolom dvlegesbedrag de uitkomst van de functie sum(vwfrmlegesregels.dnlgrbedrag) wordt getoond. Dus een optelling van de legesbedragen die op het scherm te zien zijn waarbij paging genegeerd wordt. 

Het **attribuut functie** kan ingewikkelder worden gemaakt. Bijvoorbeeld dezelfde optelling van de legesbedragen, maar nu uitgedrukt als string, waarbij de uitkomst 0 als ‘0.00’ wordt afgedrukt:

	Voorbeeld:
	<dvlegesbedrag functie="coalesce(fn_bedrag(sum(vwfrmlegesregels.dnlgrbedrag)), '0.00')" > </dvlegesbedrag> 
De gebruikte kolommen moeten natuurlijk wel in de view of tabel aanwezig zijn die aan het scherm ten grondslag ligt.

Het **attribuut hint** spreekt voor zich:

	 Voorbeeld:
	<dvlegesbedrag functie="coalesce(fn_bedrag(sum(vwfrmlegesregels.dnlgrbedrag)), '0.00'::character varying)" hint="totaal alle legesbedragen"></dvlegesbedrag>  
Met het **attribuut query** kan een optellingsfunctie nader worden gelimiteerd: 

	 Voorbeeld:
	<dvlegesbedrag functie="sum(vwfrmlegesregels.dnlgrbedrag)”  query=”dnkeylegessoort <> 123 AND dnkeylegessoort <> 456”  > </dvlegesbedrag>  
Ook hier geldt dat de gebruikte kolommen in de view of tabel aanwezig moeten zijn die aan het scherm ten grondslag ligt.

	Voorbeeld waarbij twee optellingsregels worden getoond:
```xml
<list_totals>
        <rijen>
            <rij index="0" position="bottom" font-weight="bold">
                <dvlgrsoortleges functie="'aantal legesregels: ' | | count(*)" ></dvlgrsoortleges>
                <dvlegesbedrag functie="sum(vwfrmlegesregels.dnlgrbedrag) hint="totaal alle legesbedragen"”></dvlegesbedrag>
            </rij>
            <rij index="1" position="bottom" font-weight="bold">
                <dvlegesbedrag functie="sum(vwfrmlegesregels.dnlgrbedrag)" query="dnkeylegessoort <> 123 AND dnkeylegessoort <> 456" hint="totaal zonder x en zonder y" ></dvlegesbedrag>
            </rij>
        </rijen>
  </list_totals>
```

Met het **attribuut wavetype** kan het type data van de optelsom aangegeven worden. Indien er in Excel verder gerekend dient te worden met de totaalsom, zal het wavetype waarde integer of float moeten hebben. Excel zal dan de waarde van de optelsom zien als een getal. Als voor een kolom niet attribuut wavetype wordt gedefinieerd zal deze standaard als string worden gezien: 

	 Voorbeeld:
	 <dnkey wavetype="integer">1292</dnkey>
In onderstaand voorbeeld wordt 1 optellingsregel getoond waarvan de eerste kolom geen wavetype bepaling heeft (en dus als string zal worden gezien), twee kolommen als integer getal worden gezien in Excel, en 1 kolom als timefloat (geeft een nette urennotatie):

	Voorbeeld:
```xml
<list_totals>
	<rijen>
	    <rij index="0" position="bottom" font-weight="bold">
		<dnkey functie="'aantal regels: ' | | count(*)" ></dnkey>
		<dnkeyinspecties functie="count(*)" query="dnkeyinspecties is not null" wavetype="integer"></dnkeyinspecties>
		<dnkeyomgvergunningen functie="count(*)" query="dnkeyomgvergunningen is not null" wavetype="integer"></dnkeyomgvergunningen>
		<dfaantaluur functie="sum(dfaantaluur)" hint="totaal uren" wavetype="timefloat"/>
	    </rij>
	</rijen>
  </list_totals>
```

### Voorbeeld gebruik schermknop met gekoppelde action

Dit voorbeeld komt uit de lijst met processtappen bij een zaak (scherm MDLC_geefProcessenOverzicht.xml).
Daarin is opgenomen de kolom.

```xml
<column tagnaam="void">
        <label></label>
        <index>80</index>
        <length>60</length>
        <wavetype>schermknop</wavetype>
        <icoon>28</icoon>
        <showhint>false</showhint>
        <action>getFlexAction(termijnbewaking_toelichting,{id})</action>
        <visible>%query(termijnbewaking_toelichtingzichtbaar)%</visible>
        <celvisible>%query(termijnbewaking_celtoelichtingzichtbaar,{id})%</celvisible>
   </column>
```

De tagnaam van de kolom verwijst in dit geval NIET naar een kolom van de onderliggende view/tabel vwfrmtermijnbewstappen. Vandaar 'void' er had ook een willekeurige andere tekst kunnen staan. Deze kolom met het icoon 28 (een vraagteken) is zichtbaar indien de evaluatie van de query met code = *termijnbewaking_toelichtingzichtbaar* als uitkomst de waarde true heeft:
De query onderzoekt hiervoor of de instelling *Sectie: Termijnbewaking en Item toelichtingzichtbaar* aangevinkt is:

```sql
select case when d1logic = 'T' then 'true' else 'false' end from tbinitialisatie 
  where upper(dvsectie) = 'TERMIJNBEWAKING' and upper(dvitem) = 'TOELICHTINGZICHTBAAR'
```

De action die aan de knop is verbonden wordt opgehaald door het aanroepen van de functie *getFlexaction* met als parameter weer een queryverwijzing, namelijk de query met code = *termijnbewaking_toelichting*, en als tweede parameter de id (dnkey) van de actieve processtap. OpenWave substitueert namelijk bij afspraak de string {id} met de primary key van de actieve regel.

De aanroep naar getFlexAction veronderstelt dat het resultaat van de geëvalueerde query een action aanroep op zichzelf is. De query *termijnbewaking_toelichting* is als volgt gedefinieerd:

```sql
select 'startWizard(showtekst,' | | coalesce(replace(b.dvtoelichting,chr(44),chr(32)),'Sorry. Geen toelichting aanwezig')
   | | ',Toelichting op processtap,300)' from tbtermijnbewstappen a 
   left outer join tbprocitems b 
   on (a.dnkeyorgprocedure = b.dnkeyprocedures 
   and cast(replace(a.dnvolgnr::text,a.dninvoegnr::text,'') as integer) = b.dnvolgnr) where a.dnkey = {id}
```

De {id} wordt dus door OpenWave vervangen met de dnkey van de actieve termijnbewakingsregel. Het stukje 

```sql
cast(replace(a.dnvolgnr::text,a.dninvoegnr::text,'''') as integer)
```

 berekent het oorspronkelijke volgnummer van de processtapdefinitie van tbprocitems.

Om de programmatuur niet te laten struikelen worden de komma's uit de gevonden toelichting uit tbprocitems gehaald met *replace(b.dvtoelichting,chr(44),chr(32))*. Het resultaat van de geëvalueerde query is een action op zichzelf: bijv.:

`StartWizard(showtekst,Sorry. Geen toelichting aanwezig, Toelichting op processtap,300)`

De aanroep *getlexaction* heeft dus de uiteindelijke uit te voeren action opgehaald en gaat deze startwizard(showtekst, param2,param3,param4) uitvoeren die een scherm toont waarin de toelichting (param2) wordt getoond: zie startwizard showtekst bij [Actions](/openwave/1.29/applicatiebeheer/instellen_inrichten/actions).

Indien de kolom <visible> de waarde true oplevert dan wordt in ieder geval de kolom getoond. In principe staat dan op elke regel een vraagtekentje. Wanneer echter de aangeroepen query achter de tag <celvisible> de waarde False oplevert (en deze query wordt voor elke regel opnieuw geëvalueerd), dan wordt voor die specifieke regel de cel leeg gelaten. De aangeroepen query zorgt er in dit geval voor dat her resultaat false is, indien de toelichting uit tbprocitems leeg is.

