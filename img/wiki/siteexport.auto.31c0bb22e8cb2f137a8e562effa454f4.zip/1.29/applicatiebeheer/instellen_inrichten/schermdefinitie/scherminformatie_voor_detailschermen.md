# Scherminformatie voor detailschermen

De plaats en inhoud van de kolommen en schermknoppen van een detailscherm worden geregeld in text-veld met een xml-opmaak.  Of er in een detailscherm gemuteerd kan worden is naast het genoemde bij onderstaande tags van de blokken `<column>` afhankelijk van een eigenschap edit van het scherm zelf. Deze laatste eigenschap wordt voor 99% gebaseerd op de rechten en wordt geregeld door de API.

Binnen de root-tag `<document>` zijn twee elementen:

  * tag **screenwidth**. Hierin wordt in pixels de breedte van het scherm vastgelegd. Indien het apparaat een te klein beeldscherm heeft dan komt scrollbar in beeld (niet bij I-pad). 
  * het blok **`<columns>`**. Het blok `<columns>` verzamelt alle blokken met per blok de columndefinities.

Binnen het blok `<columns>` worden één of meer elementen `<blok>` gedefinieerd. Dat zijn de kaders waarbinnen de kolommen van het scherm gedefinieerd zijn met het blauwe paneel aan de linkerkant.

[<img src="../../../../applicatiebeheer/instellen_inrichten/schermdefinitie/sceencolumns_detail_controur.w.400_tok.093a0d.png?w=400&tok=093a0d" class="media" loading="lazy" alt="" width="400" />](/_detail/openwave/applicatiebeheer/instellen_inrichten/schermdefinitie/sceencolumns_detail_controur.png?id=openwave%3A1.29%3Aapplicatiebeheer%3Ainstellen_inrichten%3Aschermdefinitie%3Ascherminformatie_voor_detailschermen)

Een **<blok>** heeft de volgende elementen in de volgende volgorde:

  * tag **`<label>`**. Dit is het opschrift op het blauwe paneel. Een semicolon (;) wordt door het programma geïnterpreteerd als harde return met wagenterugloop.
  * tag **`<width>`**. Dit is de breedte van het blauwe paneel in pixels.
  * tag **`<height>`**. Dit is de hoogte van het blok in pixels. Standaardberekening is dat de hoogte van het blok 40 x het aantal regels van dat blok is bij <type> doorlopend. Hierbij is aangenomen dat een regel een `<divheight>` van 30 pixels heeft (zie hieronder bij blok <column>). Indien hier de waarde 0 wordt ingevoerd dan bepaalt OpenWave zelf de hoogte van het blok op grond van de gevulde regels.
  * tag **`<type>`**. Er zijn drie mogelijke waardes:
    * **doorlopend**. De elementen in het blok worden gedefinieerd in één of meer blokken <column>.
    * **getflexlist(parameterlist).** Dat betekent dat het blok wordt gevuld door de matrix van een lijstscherm (dus zonder header, maar met knoppen linksonder). De parameterlist geeft aan welk lijstscherm in het blok getoond moet worden. Bijvoorbeeld getFlexList(tblegesberekeningen,tblegessoort,%keypointer%) waarbij %keypointer% altijd wordt vervangen door de primary key van de tabel waar het detailscherm op gebaseerd is.
    * **{REST}(restfunctienaam).** Hiermee wordt aangegeven dat het resultaat van en REST-aanroep moet worden ingevoegd. Zie: [REST Flexfuncties](/openwave/1.29/applicatiebeheer/instellen_inrichten/rest_flexfuncties).
  * tags. Deze tag mag ook weggelaten worden. Indien de tag wel bestaat dan verwijst de inhoud naar een rij uit de tabel tbqueries (zie [Queries](/openwave/1.29/applicatiebeheer/instellen_inrichten/queries)). Bijvoorbeeld `<notvisibleif>%query(omgeving_blokhyperlink)%</notvisibleif>` verwijst naar de rij in tbqueries met dvcode = 'omgeving_blokhyperlink'. Het programma zal de bijbehorende query evalueren. De uitkomst van de geëvalueerde query moet 1 of 0 zijn. Indien verkeerde verwijzing, of het element is leeg, of indien error bij evaluatie, of de uitkomst is <> 1, dan is het blok WEL zichtbaar. Indien de uitkomst van de query de waarde 1 heeft dan is het blok NIET zichtbaar. Hiermee kan dus bepaalde scherminformatie verborgen blijven op grond van een zelf ingevoerde conditie. Zo kan de query waar bovenstaand voorbeeld naar verwijst bestaan uit het statement:

```sql
select case when (dlmappenhyperlink = 'F') then 1 else 0 end from tbrechten 
   where dnkey = (select dnkeyrechten from tbmedewerkers where trim(dvcode) = trim(:keyaccount))
```

Hetgeen wil zeggen dat indien de inlogger behoort tot een rechtengroep met dlmappenhyperlink = 'F', dat dan het blok waarin de tag `<notvisibleif>%query(omgeving_blokhyperlink)%</notvisibleif>` is opgenomen voor de betrokken inlogger NIET zichtbaar is.

Bij bloktype *doorlopend* worden binnen het `<blok>` evenzoveel blokken `<column>` gedefinieerd als er verschillende elementen in dat blok getoond moeten worden (kolommen en schermknoppen). De tags en attributen binnen een `<column>` zijn in onderstaande volgorde:

Een voorbeeld voor met niet-muteerbare editbox met fontcolor = red:

```xml
<column>
    <regel>2</regel>
    <tagnaam>dvstatus</tagnaam>
    <label>Status</label>
    <divwidth>130</divwidth>
    <divheight>30</divheight>
    <edit>false</edit>
    <showhint>false</showhint>
    <wavetype>string</wavetype>
    <source/>
    <filter/>
    <refresh>false</refresh>
    <backcolor/>
    <fontcolor>red</fontcolor>
    <nullable>true</nullable>
    <icoon/>
  </column>
```

Een voorbeeld voor editbox met dropdownlijst:

```xml
<column value="dnkeyportalcolumns">
     <regel>3</regel>
     <tagnaam>dvcolumnname</tagnaam>
     <label>Kolom</label>
     <divwidth>200</divwidth>
     <divheight>30</divheight>
     <edit>true</edit>
     <showhint>false</showhint>
     <wavetype>keuzelijst</wavetype>
     <source>GeneralWithoutEmptyLine</source>
     <filter>select dnkey id, dvname omschrijving 
             from tbportalcolumns where dnkeyportalnames = 
             (select dnkeyportalnames from vwfrmportaltiles where dnkey = %keypointer%)
     </filter>
     <refresh>false</refresh>
     <backcolor/>
     <fontcolor/>
     <nullable>true</nullable>
     <icoon/>
     <align/>
     <pretext/>
     <posttext/>
     <hint/>
     <action/>
  </column>
```

Dan een voorbeeld voor een schermknop voor een tekstballonnetje:

```xml
<column>
    <regel>1</regel>
    <tagnaam/>
    <label/>
    <divwidth>20</divwidth>
    <divheight>30</divheight>
    <edit>true</edit>
    <showhint>false</showhint>
    <wavetype>schermknop</wavetype>
    <source></source>
    <filter>enable</filter>
    <refresh>false</refresh>
    <backcolor/>
    <fontcolor/>
    <nullable>true</nullable>
    <pre><icoon></pre>28</icoon>
    <align/>
    <pretext/>
    <posttext/>
    <hint/>
    <action>getFlexBalloon(Hier alleen voorletters; zonder punt en spaties,P)</action>
  </column>
```

Dan een voorbeeld voor een schermknop voor een starten van een specifiek documentsjabloon:

```xml
<column>
    <regel>1</regel>
    <tagnaam/>
    <label/>
    <divwidth>20</divwidth>
    <divheight>30</divheight>
    <edit>true</edit>
    <showhint>false</showhint>
    <wavetype>schermknop</wavetype>
    <source></source>
    <filter>enable</filter>
    <refresh>false</refresh>
    <backcolor/>
    <fontcolor/>
    <nullable>true</nullable>
    <pre><icoon></pre>48</icoon>
    <align/>
    <pretext/>
    <posttext/>
    <pattern/>
    <hint/>
    <action>startWizard(maakDocument,2702,tbdocumenten;;tbomgvergunning;{id},W)</action>
    <textpattern/>
  </column>
```

Hieronder wordt duidelijk dat de tag *wavetype* eigenlijk bepalend is hoe de overige tags worden geïnterpreteerd:

  * attribuut **value** kan gevuld worden met een kolomnaam uit de tabel die uiteindelijk ten grondslag ligt aan het detailscherm. Indien een view als basis voor het scherm wordt gebruikt, gaat het hier om de (hoofd)tabel die weer ten grondslag ligt aan die view. Het attribuut `<value>` hoeft alleen gevuld te worden indien de tag ``<edit>`` de waarde true heeft. Het programma weet zo in welke database-veld de gewijzigde waarde opgeslagen moet worden. <adm information>Niet van toepassing in combinatie met de `<wavetypes>`: icoon, kleurbal, wizard, schermknop, space, datumro, picture en tekst.</adm>
  * tag **<regel>**. Altijd verplicht. Geeft aan op welke regel binnen het <blok> het element geplaatst moet worden. Een tweede `<column>` binnen eenzelfde blok met dezelfde regel wordt achter de vorige geplaatst op diezelfde regel. Indien een <column> 'niet meer past' in de opgegeven breedte van het scherm dan verschuift deze naar de volgende regel binnen het blok. Indien een regel niet meer past binnen de opgegeven hoogte van het blok, dan is deze niet meer zichtbaar. 
  * tag **<tagnaam>**. De waarde van de tagnaam is een kolomnaam uit de view of tabel dat aan het scherm ten grondslag ligt. <adm information>Niet van toepassing in combinatie met de `<wavetypes>`: wizard, schermknop, space en tekst.</adm>
  * tag **`<label>`** geeft het label boven het betreffende element in het scherm. De waarde mag leeg zijn. Het label (één string; één regel) heeft een vast hoogte die in de CSS is vastgelegd (15 pixels). Indien gevuld wordt het label boven het element geplaatst. <adm information>Niet van toepassing in combinatie met de `<wavetypes>`: icoon, kleurbal, wizard, memo, flexmemo, schermknop, space en picture: een eventueel gevulde </adm> `<label>` wordt beschouwd als leeg. Bij een leeg label schuift het element daaronder als het ware omhoog. Een labelwaarde kan opgebouwd worden met behulp van een query: zie kopje *Queries voor contextafhankelijke scherm-attributen* onder [Queries](/openwave/1.29/applicatiebeheer/instellen_inrichten/queries). Er zijn drie uitzonderingen m.b.t. de positionering van een label:
    * `<wavetype>` schermknop: normaliter wordt deze onder het (lege) label gepositioneerd. Alleen in het geval dat het label de waarde 'false' heeft, dan wordt zelfs het lege label niet uitgeschreven zodat de schermknop op de plaats van het label wordt geplaatst (omhoog schuift)
    * `<wavetype>` boolean. De enige situatie waarbij het attribuut label niet boven het vakje wordt geplaatst, maar erachter mits de <divwidth> van het label groot genoeg is gedefinieerd
    * `<wavetype>` tekst. In het `<label>` staat de inhoud van de tekst die in een editbox zichtbaar wordt, waarbij het label boven die tekst  uiteindelijk leeg blijft.
  * tag **<divwidth>**. Altijd verplicht. Deze tag geeft de breedte aan die het element moet innemen. Die breedte slaat niet op het bijbehorende label: dat wordt altijd volledig afgedrukt. De ruimte tussen de eerste linker kolom en de rechterrand van het blauwe blok vast in de CSS en niet in de API. De ruimte tussen de kolommen onderling op dezelfde regel ligt vast in de CSS en niet in de API. De ruimte tussen de kolommen op verschillende regels ligt vast in de CSS en niet in de API. Bij `<wavetype>` keuzelijst, combobox of datum slaat de `<divwidth>` op de inputbox zelf dus exclusief het dropdown/kalendericoontje. <adm information> Niet van toepassing in combinatie met de `<wavetypes>`: icoon, kleurbal, schermknop en picture</adm> er moet wel een waarde ingevuld worden, maar deze is niet van invloed op de breedte van het element.
  * tag **`<divheight>`**. Altijd verplicht. Deze tag bepaalt de hoogte van de hele element inclusief label. Of de tag `<label>` nu wel of niet is gevuld; de `<divheigt>` is de hoogte inclusief de vaste labelhoogte. De 'normale' elementen (`<wavetypes>` string, datum, float, integer, keuzelijst, combobox, timefloat) zullen - als het goed is- allemaal met dezelfde hoogte worden doorgegeven (standaard 30 pixels). Een kolom van het `<wavetype>` memo of flexmemo echter, kan een afwijkende veel grotere hoogte hebben. Het is aan de ontwerper om ervoor te zorgen dat elementen op dezelfde regel een gelijke `<divheigt>` hebben. <adm information>Niet van toepassing in combinatie met de `<wavetypes>`: icoon, kleurbal, schermknop en picture</adm> er moet wel een waarde ingevuld worden, maar deze is niet van invloed op de hoogte van het element.
  * tag **`<edit>`**. Heeft de waarde true of false (false is de default waarde). Kan ook gevuld zijn met een aanroep naar een evalueerbare query die true of false oplevert. Indien de waarde = true EN de [editschuif](/openwave/1.29/applicatiebeheer/instellen_inrichten/editschuif) AAN staat EN attribuut value is gevuld, dan is de kolom voor de gebruiker muteerbaar. In een klein aantal gevallen overruled de API deze instelling. <adm information>Niet van toepassing in combinatie met de `<wavetypes>`: icoon, kleurbal, wizard, schermknop, space, datumro, picture en tekst.</adm>
  * tag **`<showhint>`**. Kan de waarde true of false hebben. Indien dit attribuut niet bestaat dat is de defaultwaarde false. Indien true dan wordt bij een hover op de kolom de volledige inhoud als hint zichtbaar. Wordt gebruikt indien tag <divlength> bij element van wavetype `<string>` te klein is om de hele inhoud weer te geven.
  * tag **`<wavetype>`** zegt iets over de functie en type van de kolom in de view/tabel. De tag moet gevuld zijn met één van volgende waarden:
    * **string**. Betekent dat de kolom in de view/tabel een normaal karakterveld bevat. Indien het scherm editable is EN het attribuut value is gevuld en de tag `<edit>` heeft de waarde true, dan kan de kolom gewijzigd worden
    * **integer**. Betekent dat de kolom een geheel getal bevat. Indien het scherm editable is EN het attribuut value is gevuld en de tag `<edit>` heeft de waarde true, dan kan de kolom gewijzigd worden
    * **spinedit**. Wordt (nog) niet ondersteund
    * **float**. Betekent dat de kolom een rationeel getal bevat. Indien het scherm editable is EN het attribuut value is gevuld en de tag `<edit>` heeft de waarde true, dan kan de kolom gewijzigd worden
    * **memo**. Betekent dat de kolom in de view/tabel een normaal karakterveld bevat, dat echter meer karakters kan bevatten dan de breedte van de regel. Met de tag `<divheight>` kan een invoerbox gecreëerd worden die hoog genoeg is om de tekst te laten zien. Het label is niet zichtbaar. Indien het scherm editable is EN het attribuut value is gevuld en de tag `<edit>` heeft de waarde true, dan kan de kolom gewijzigd worden. Bij dit type reageert het programma op de F8 toets door op de plek van de cursor datum en medewerkerscode in te vullen.
    * **datum**. Betekent dat de kolom een datum bevat die wordt getoond als dd-mm-yyyy. Indien het scherm editable is EN het attribuut value is gevuld en de tag `<edit>` heeft de waarde true, dan kan de datum gewijzigd worden met een datepicker
    * **icoon**. Er zijn drie mogelijkheden:
    * indien de kolom een lege waarde heeft, dan wordt er niets afgedrukt
    * indien gevulde waarde EN attribuut *tagnaam* begint met 'dl' (de waarde zou een boolean T of F moeten zijn) dan:
      * indien die waarde = F dan wordt er niets afgedrukt
      * indien die waarde <> F dan wordt het icoon afgedrukt met het nummer uit de [iconenlijst](/openwave/1.29/applicatiebeheer/instellen_inrichten/schermdefinitie/iconenlijst) dat vermeld staat in de tag `<icoon>`.
    * indien gevulde waarde EN attribuut *tagnaam* begint NIET met 'dl' dan wordt het icoon afgedrukt met het nummer uit de iconenlijst dat vermeld staat in de tag `<icoon>`
    * **kleurbal**. Wordt (nog) niet gebruikt
    * **boolean**. Betekent dat de kolom een waarde T of F bevat. Indien T dan wordt de kolom getoond als ingevuld aanvinkvakje en anders als leeg aanvinkvakje. Indien het scherm editable is EN het attribuut value is gevuld en de tag `<edit>` heeft de waarde true, dan kan de kolom gewijzigd worden. Bij dit wavetype wordt het label achter het aanvinkvakje afgedrukt (mits de divwidth breed genoeg is gedefinieerd)
    * **boolean+** Betekent dat de kolom alleen de waardes T of F of N bevat, die zichtbaar gemaakt worden door drie horizontale radiobuttons, met het label: Ja, Nee en n.n.b. Indien het scherm editable is EN het attribuut value  is gevuld en de tag `<edit>` heeft de waarde true, dan kan de kolom gewijzigd worden
    * **boolean10**. Betekent dat de kolom een waarde 1 of 0 bevat (characterveld). Gedraagt zich gelijk aan boolean
    * **booleanV**. Betekent dat de kolom een waarde T of F bevat. Indien T dan wordt de kolom getoond als ingevuld aanvinkvakje en anders als leeg aanvinkvakje. Indien het scherm editable is EN het attribuut value is gevuld en de tag `<edit>` heeft de waarde true, dan kan de kolom gewijzigd worden. Bij dit wavetype wordt het label boven het aanvinkvakje afgedrukt
    * **keuzelijst**. Betekent dat de kolom gekoppeld is aan een dropdownlijst. Voor het gebruik van de dropdownlijst moet het scherm zelf editable zijn. Verder moet het attribuut value gevuld zijn en de tag `<edit>` moet de waarde true hebben. De eerste kolom van de gekozen regel van de keuzelijst is de waarde die opgeslagen wordt. De tag `<source>` verwijst of:
    * naar een vast geprogrammeerde dropdownlijst
    * of naar een zelf gedefinieerde query in tag `<filter>`. In dit laatste geval heeft de tag `<source>`: 
      * ofwel de waarde 'GeneralWithoutEmptyLine'
      * dan wel de waarde 'GeneralWithEmptyLine'.
    * **wizard**. Deprecated  
    * **radiobutton**. Werkt hetzelfde als *keuzelijst* behalve dat het dropdownlijstje als onder elkaar staande radiobuttons wordt getoond
    * **schermknop**. Betekent dat het element wordt afgedrukt als een in te drukken knop waaraan een actie is verbonden. Er is geen verwijzing naar een tagnaam. Of de knop enabled is, is afhankelijk van de waarde van de tag `<edit>` en het editable zijn van het scherm, behalve indien de tag `<filter>` de waarde *enable* heeft, dan is de schermknop altijd enabled ook als het scherm zelf niet in de editmodus staat. De tag `<source>` is leeg of bevat een integer-waarde waarmee in de API een icoon en actie zijn toegekend aan de knop. Indien de tag `<source>` leeg is dan moet de tag `<icoon>` een waarde uit de [Iconenlijst](/openwave/1.29/applicatiebeheer/instellen_inrichten/schermdefinitie/iconenlijst) bevatten en moet de tag `<action>` gevuld zijn met een actie. In de tag `<hint>` kan de schermknop in dat geval voorzien worden van een hint-tekst 
    * **space**. Betekent dat het element wordt gebruikt om <divwidth> lege pixels af te drukken. Waarmee kolommen van verschillende regels bijvoorbeeld nauw onder elkaar getoond kunnen worden. Geen <tagnaam>, geen `<label>`, niet editable
    * **datumro**. Betekent dat de kolom in de view/tabel een datum bevat die wordt getoond als dd-mm-yyyy, maar zonder datepicker-icoonte. De tag `<edit>` moet dus false zijn
    * **picture**. Wordt niet gebruikt. Is voor speciale toepassingen 
    * **tekst**. In de tag `<label>` staat de inhoud van de tekst die in een editbox getoond wordt, waarbij het label boven de tekst dus uiteindelijk leeg blijft. Geen `<tagnaam>`. `<edit>` is false. Indien de tag `<align>` wordt gevuld met 'T' (Top) dan positioneert de tekst zich op de hoogte van waar normaal het label zou worden uitgeschreven. Indien de tag `<align>` ontbreekt of wordt gevuld met 'B' (Bottom) dan positioneert de tekst zich op de hoogte van waar normaal de editbox zou worden uitgeschreven
    * **flexmemo**. Betekent dat de kolom in de view/tabel een normaal karakterveld bevat, dat echter meer karakters kan bevatten dan de breedte van de regel. Met de tag `<divheight>` kan een invoerbox gecreëerd worden die hoog genoeg is om de tekst te laten zien. Het label is niet zichtbaar. Indien het scherm editable is EN het attribuut value is gevuld en de tag `<edit>` heeft de waarde true, dan kan de kolom gewijzigd worden. Het bijzondere aan de flexmemo t.o.v. wavetype memo is:
    * wanneer de cursor in het flexmemoveld staat met F11 naar scherm vullend beeld getoggled kan worden
    * dat afhankelijk van de tag `<source>` de tekst van de memo zichtbaar geïnterpreteerd wordt als xml (XML), Json (JSON) sql (SQL) of tekst (TXT)
    * dat het programma reageert op de F8 toets door op de plek van de cursor datum en medewerkerscode in te vullen.
    * **timefloat**. Betekent dat de kolom in de view/tabel een float bevat die door de programmatuur dan getoond wordt als tijd. Default - de float is kleiner dan 100 - worden de decimalen omgezet in minuten en het gedeelte voor de decimaal als uren (HH:MM). Indien het scherm editable is EN het attribuut value is gevuld en de tag `<edit>` heeft de waarde true, dan kan de kolom gewijzigd worden
    * **combobox**. Betekent dat de kolom in de view/tabel een karakterveld is en te vullen met een dropdownlijst. Voor het gebruik van de dropdownlijst moet het scherm zelf editable zijn. Verder moet het attribuut value gevuld zijn en de tag `<edit>` moet de waarde true hebben. De tag `<source>` bevat de query voor de dropdownlijst waarbij de eerste kolom van de resultset 'omschrijving' moet zijn: dit is de waarde die overgenomen wordt. Het verschil met wavetype keuzelijst is dat de gebruiker niet hoeft te kiezen uit de dropdownlijst, maar ook zelf tekst kan intikken
    * **spinedit**. Alleen Chroom. Betekent dat de kolom in de view/tabel een integer is dat met spin-knopjes telkens met waarde 1 verhoogd/verlaagd kan worden
    * **datetime**. Geeft een database timestamp-field weer als een string *dd-mm-yyyy hh:mm:ss*. Ook invoer moet exact volgens dit masker.
    * **amountfloat**. Geeft een database veld integer of float weer in bedragvorm, bijvoorbeeld float waarde *23444,99* wordt getoond als *23.444,99* en integer waarde *87345* word getoond als *87.345,00*. De invoer moet voor een integer veld nog steeds een waarde zijn **zonder** decimalen (het is immers een integer), invoer voor float velden blijft zoals men gewend is maar men kan ook een punt gebruiken om duizendtal aan te geven. Handig om tag *refresh* op true te zetten.
  * tag **`<source>`** wordt in samenhang met verschillende wavetypes gebruikt:
    * indien `<wavetype>` de waarde *keuzelijst* of *radiobutton* heeft dan verwijst de waarde van de tag `<source>`:
    * naar een vast geprogrammeerde dropdownlijst
    * of naar een dropdownlijst op basis van een zelf gedefinieerde query in tag `<filter>`. In dit laatste geval heeft de tag `<source>`: 
      * ofwel de waarde 'GeneralWithoutEmptyLine'
      * dan wel de waarde 'GeneralWithEmptyLine'. In dit geval zal het programma zelf een lege regel aan de result set van de query in `<filter>` toevoegen, zodat de gebruiker een waarde leeg kan maken. In beide gevallen wordt de breedte van de dropdownkeuzelijst bepaald door de lengte van het breedte item.
    * indien `<wavetype>` de waarde *combobox* heeft dan bevat `<source>` de query voor de dropdownlijst waarbij de eerste (en enige) kolom van de result set 'omschrijving' moet zijn (dus bijv.: select dvloginnaam omschrijving from tbmedewerkers where ddvervaldatum is null)
    * indien `<wavetype>` de waarde *icoon* heeft dan kan de waarde van de tag `<source>` gevuld worden met 'extern'. Dat heeft als betekenis dat het icoonnummer uit de tag `<icoon>` niet uit de interne iconenlijst komt, maar uit een externe - maat gesneden - lijst van plaatjes. De waarde van de tag `<icoon>` verwijst in dat geval naar het naamdeel van een opgeslagen plaatje met extensie .jpg of .png op de webserver
    * indien `<wavetype>` = *schermknop* dan staat hier de id van de schermknop zoals die in de API is geprogrammeerd. Indien `<source>` leeg is dan wordt de schermknop gedefinieerd door de tags `<action>` , `<hint>`  en `<icoon>`
    * indien `<wavetype>` = *flexmemo* dan staat hier ofwel 'TXT'of "JSON'of 'SQL' of 'XML'. Met de F11 toets wordt de inhoud van de kolom in groot scherm getoond opgemaakt volgens bijbehorende opmaak.
  * tag **`<filter>`** kan een query bevatten indien `<wavetype>` = *keuzelijst of radiobutton* EN `<source>` = 'GeneralWithoutEmptyLine' of 'GeneralWithoutEmptyLine'. De eerste kolom van die result set moet 'id' heten en de tweede kolom 'omschrijving'. Bijvoorbeeld: select dnkey id, dvname omschrijving from tbportalcolumns where dnkeyportalnames = (select dnkeyportalnames from vwfrmportaltiles where dnkey = %keypointer%). De id-waarde is de kolom die overgenomen wordt bij een keuze uit de dropdownlist. De variabele %keypointer% wordt door het programma vervangen met de primary key van de basistabel die aan het scherm ten grondslag ligt. De variabele %module% - indien mogelijk - met de moduleletter. Bij< wavetype> schermknop kan deze tag `<filter>` de waarde *enable* bevatten. In dat geval is de schermknop altijd enabled ongeacht de stand van de editschuif.
  * tag **`<refresh>`** kan de waarde 'true' of 'false' bevatten. Indien true dan heeft dat tot gevolg dat nadat een kolom is gewijzigd en de focus op een andere kolom is gezet, het gehele scherm opnieuw wordt uitgeschreven. <adm information>Niet van toepassing in combinatie met de `<wavetypes>`: icoon, kleurbal, wizard, schermknop, space, datumro, picture en tekst.</adm>
  * tag **`<backcolor>`**. Met deze tag kan de standaard achtergrondkleur van een kolom worden overschreven. <backcolor> moet gevuld zijn met standaard html colorname ([https://www.w3schools.com/colors/colors_names.asp](https://www.w3schools.com/colors/colors_names.asp)). <adm information>Niet van toepassing in combinatie met de `<wavetypes>`: icoon, kleurbal, wizard, schermknop, space, picture en tekst.</adm>
  * tag **`<fontcolor>`**. Met deze tag kan de standaard tekst kleur van een kolom worden overschreven. <fontcolor> moet gevuld zijn met standaard html colorname ([https://www.w3schools.com/colors/colors_names.asp](https://www.w3schools.com/colors/colors_names.asp)). <adm information>Niet van toepassing in combinatie met de `<wavetypes>`: icoon, kleurbal, wizard, schermknop, space, picture en tekst.</adm>
  * tag **`<nullable>`** kan de waarde 'true' of 'false' bevatten. Indien false kan de kolom niet leeggemaakt worden. <adm information>Niet van toepassing in combinatie met de `<wavetypes>`: icoon, kleurbal, wizard, schermknop, space, datumro, picture en tekst.</adm>
  * tag **`<icoon>`**. Als op de kolom een plaatje afgedrukt moet worden dan moet de bijbehorende `<wavetype>` de waarde 'icoon' hebben (zie hierboven). De waarde van de tag `<icoon>` verwijst - indien deze anders is dan 999 - rechtstreeks naar een icoonnummer uit de [iconenlijst](/openwave/1.29/applicatiebeheer/instellen_inrichten/schermdefinitie/iconenlijst). Alleen wanneer de tag `<icoon>` de waarde 999 heeft dan wordt het icoonlijstnummer uit de kolomwaarde zelf gehaald. Zie ook nog even de uitzondering indien tag `<source>` de waarde 'extern' heeft.
  * tag **`<align>`** kan de waarde R hebben: Rechts (default is Links). De tekst in de kolom wordt links of rechts uitgelijnd. <adm information>Niet van toepassing in combinatie met de `<wavetypes>`: icoon, kleurbal, wizard, schermknop, space, picture.</adm> Indien `<wavetype>` de waarde 'tekst' heeft, dan kan `<align>` de waardes *top* of *bottom* hebben. Indien waarde is *top* dan positioneert de tekst zicht op de plek waar normaal het label wordt uitgeschreven. Indien `<align>` ontbreekt of de waarde *bottom* heeft, dan onder de plek waar normaal het label wordt uitgeschreven.
  * tag **`<pretext>`** kan een karakterreeks bevatten die direct vòòr de editbox van de kolom afgedrukt wordt, maar onder het label (de editbox schuift als het ware op). Bijvoorbeeld het euroteken bij een bedrag. <adm information>Niet van toepassing in combinatie met de `<wavetypes>`: icoon, kleurbal, wizard, schermknop, space, picture en tekst.</adm>
  * tag **`<posttext>`** kan een karakterreeks bevatten die direct nà de editbox van de kolom afgedrukt wordt. Bijvoorbeeld het procent teken bij een percentage. <adm information>Niet van toepassing in combinatie met de `<wavetypes>`: icoon, kleurbal, wizard, schermknop, space, picture en tekst.</adm>
  * tag **`<pattern>`** kan gevuld zijn met een reguliere expressie om invoer in een editbox te reguleren. Van toepassing bij wavetypes string, memo en timefloat. Voorbeeld van een pattern = ^(\w{1,10})$  om er voor te zorgen dat minimaal één, maar niet meer dan 10 alfanumerieke karakters worden geaccepteerd. Voor mogelijkheden van pattern zie o.a. [http://www.w3schools.com/jsref/jsref_obj_regexp.asp](http://www.w3schools.com/jsref/jsref_obj_regexp.asp) en een prettige testsite is [https://www.regextester.com/](https://www.regextester.com/). Voorbeelden zie: [Regexp voorbeelden pattern](/openwave/1.29/applicatiebeheer/instellen_inrichten/regexp_voorbeelden_pattern). In het geval van wavetype memo dient rekening gehouden te worden met verschil in interpretatie van enter(nieuwe regel) karakter in applicaties. Bij knippen en plakken van een tekst uit Word in een memo van OpenWave bijvoorbeeld worden de enters uit Word als twee tekens gezien, in Word maar als 1. Zo kan men over het max toegestane aantal tekens zitten in OpenWave maar niet in Word. Om dit te voorkomen zal in het pattern het max toegestane tekens lager gezet moeten worden zodat in OpenWave op tijd de gewenste foutmelding getoond wordt (uit tag `<textpattern>` ).
  * tag **`<hint>` **. Vooralsnog alleen van toepassing indien `<wavetype>` = schermknop EN tag `<source>` is leeg. `<hint>` kan een tekst bevatten die getoond wordt als hint bij het hoveren van de schermknop.
  * tag **`<action>` **. Vooralsnog alleen van toepassing indien `<wavetype>` = schermknop EN tag `<source>` is leeg. Een action kan opgebouwd worden met behulp van een query: zie kopje *Queries voor contextafhankelijke scherm-attributen* onder [Queries](/openwave/1.29/applicatiebeheer/instellen_inrichten/queries). Zie verder over het gebruik en mogelijkheden van actions: [Actions](/openwave/1.29/applicatiebeheer/instellen_inrichten/actions). 
  * tag **`<textpattern>`** de boodschap die getoond moet worden bij een invoer die niet aan het pattern voldoet.
  * tag **`<visible>` ** True of false. Indien false wordt de kolom NIET opgenomen in het scherm. Kan ook gevuld zijn met een aanroep naar een evalueerbare query die true of false oplevert.

De tags edit en visible moeten dus de waarde false of true hebben, maar die waarde kan ook door query aanroep worden geleverd. Een bijzondere aanroep bij deze tags is de verwijzing naar een bestaande systeemquery met dvcode = *geefWaardeRechtenkolom* die makkelijk toegang geeft tot het rechtensysteem van OpenWave. Voorbeeld is het zichtbaar zijn van de knop wijzig bevoegd gezag in het detailscherm van de omgevingszaak. In de schermkolomdefinitie is de tag visible als volgt:

```xml
<visible>%query(geefwaarderechtenkolom,'tbomgrechten.dlbomgbevgezedt')%</visible>
```

De query kijkt voor de betreffende inlogger naar de waarde van de kolom tbomgrechten.dlbomgbevgezedt.

