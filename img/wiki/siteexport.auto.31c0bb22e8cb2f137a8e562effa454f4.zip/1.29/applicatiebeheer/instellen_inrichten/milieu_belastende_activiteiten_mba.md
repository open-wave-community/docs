# Milieu  Belastende Activiteiten

[<img src="../../../applicatiebeheer/instellen_inrichten/mba.w.600_tok.633791.png?w=600&tok=633791" class="media" loading="lazy" alt="" width="600" />](/_detail/openwave/applicatiebeheer/instellen_inrichten/mba.png?id=openwave%3A1.29%3Aapplicatiebeheer%3Ainstellen_inrichten%3Amilieu_belastende_activiteiten_mba)

## Codetabel paragrafen en artikelen

In het beheerportaal *Inrichtingenbeheer* onder kolom *Registratie en Veiligheid*, tegel **MBA-coderingen** kan men de MBA-paragrafen definiëren die de gebruiker tegen kan komen.

De kolommen van tbmilcodemba:

  * dvcode is de Codering of paragraaf van milieubelastende activiteit
  * dvplicht is (G)een, (I)informatieplicht, (M)eldingsplicht of (V)ergunningsplicht of (Z)orgplicht
  * dvbron is (B)AL, omgevings(P)lan, omgevings(V)erordening of (W)aterschapverordening
  * dvbevoegdgezag is (G)emeente, (P)rovincie, (R)ijk of (W)aterschap
  * ddvervaldatum is Vervaldatum van codering. Vanaf die dag kan de betreffende MBA-paragraaf niet meer gekozen worden
  * dvsoortactiviteit is Leeg of gevuld met de letters (F)unctioneel ondersteundend, (M)agneetactiviteit, (B)edrijfsondersteindend of (K)ernactiviteit
  * dvidentificatie is de Informatiemodel Omgevinsgwet (IMOW)- code  (ambtsgebied-identificatie) van milieubelastende activiteit die I-Go gebruikt voor de Gelderse omgevingsdiensten. Mag leeg zijn. 

Via het detailscherm van de paragraaf kunnen één of meer artikelen gedefinieerd worden bij die betreffende paragraaf in de tabel tbmilartmba.

De kolommen:

  * dvartikelnr is het artikelnummer
  * dvartikeltekst is de omschrijving (maximaal 4000 tekens)
  * dvrisicocode is een vrije codering die ook aan de voorkant (bij de milieubelastende activiteiten per inrichting) zichtbaar is, indien aldaar en link met een artikel is opgegeven. Doel is om de zwaarte/risico van artikel te duiden. Op dit moment doet OpenWave hier nog niets mee 
  * dvbevoegdgezag is (G)emeente, (P)rovincie, (R)ijk of (W)aterschap (gaat boven de bevoegdgezagkeuze bij activiteit)
  * dvplicht is (G)een, (I)informatieplicht, (M)eldingsplicht of (V)ergunningsplicht of (Z)orgplicht (gaat boven de plichtkeuze bij activiteit).

## MBA's per inrichting

In het inrichtingenportaal onder de kolom *wat gebeurt er* (dit kan per implementatie anders geregeld zijn) is een tegel die de lijst opent van MBA's bij die inrichting. Dit is de lijst van tbmilmba.

De eerste kolom van de lijst is een kleurbolletje. Rood indien de vervaldatum van de codetabel tbmilcodemba is ingevuld en wit indien leeg.

Kijk-, edit, Insert-en delete-recht van de MBA's zijn op grond van dezelfde rechten als bij SBI (tbmilrechten.dlcmilinrsbi*vsb/edt/ins/del*).

De insertwizard verzorgt het invoegen van een nieuwe rij op basis van een keuze uit de codetabel tbmilcodemba.

Indien de instelling *Sectie: Inrichtingen en Item: ArtikelBijMBA* is aangevinkt, dan moet de gebruiker in een tweede pagina van de insertwizard een keuze maken uit een artikelnummer (tbmilartmba) op grond waarvan de paragraafkeuze is gemaakt bij dat bedrijf. De gebruiker kan alleen kiezen uit de artikelen die in het beheerportaal bij de betreffende paragraaf zijn gedefinieerd. Die keuze wordt opgeslagen in de kolom dnkeymilartmbakeuze.

Met het kiezen van de paragraaf worden de plichtcodering en bevoegd gezag overgenomen uit tbmilcodemba.Indien echter ook een artikelnummer is aangewezen dan worden de plichtcodering en bevoegd gezag overgenomen uit tbmilartmba.

Indien er maar één activiteit bij de inrichting is gedefinieerd is dat automatisch de hoofdactiviteit. Er kan maar één rij van activiteiten bij een inrichting de hoofdactiviteit zijn. Dit betekent dat indien een andere activiteit hiertoe aangevinkt wordt, automatisch deze eigenschap bij de overige rijen uitgevinkt wordt.

Met de kolommen ddstart en ddeind (begin en eind geldigheid) kan aangegeven worden of de betreffende activiteit nog uitgeoefend wordt. De vervaldatum slaat op de codetabel tbmilcodemba. Daarmee wordt aangegeven of het artikelnummer nog wel bestaat. 

